package com.chiyuri.player

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class Mp3Id3TagWriterTest {
    @Test
    fun writesUtf8Id3v24AndPreservesAudioBytes() {
        val dir = createTempDir(prefix = "chiyuri-id3-")
        try {
            val source = File(dir, "source.mp3")
            val target = File(dir, "target.mp3")
            val audio = byteArrayOf(0xff.toByte(), 0xfb.toByte(), 0x90.toByte(), 0x64) + ByteArray(128) { it.toByte() }
            source.writeBytes(audio)

            Mp3Id3TagWriter.rewrite(
                source,
                target,
                TrackMetadata(title = "Тестовая песня", artist = "Исполнитель", album = "Альбом", year = "2026")
            )

            val bytes = target.readBytes()
            assertEquals("ID3", String(bytes, 0, 3, Charsets.ISO_8859_1))
            assertEquals(4, bytes[3].toInt())
            val tagSize = decodeSynchsafe(bytes, 6)
            val body = bytes.copyOfRange(10, 10 + tagSize)
            assertTrue(containsFrame(body, "TIT2"))
            assertTrue(containsFrame(body, "TPE1"))
            assertTrue(containsFrame(body, "TALB"))
            assertTrue(containsFrame(body, "TDRC"))
            assertArrayEquals(audio, bytes.copyOfRange(10 + tagSize, bytes.size))
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun preservesUneditedFramesFromId3v23() {
        val dir = createTempDir(prefix = "chiyuri-id3-")
        try {
            val source = File(dir, "source.mp3")
            val target = File(dir, "target.mp3")
            val genrePayload = byteArrayOf(0) + "Rock".toByteArray(Charsets.ISO_8859_1)
            val genreFrame = "TCON".toByteArray(Charsets.ISO_8859_1) +
                int32(genrePayload.size) + byteArrayOf(0, 0) + genrePayload
            val header = byteArrayOf(73, 68, 51, 3, 0, 0) + synchsafe(genreFrame.size)
            val audio = byteArrayOf(0xff.toByte(), 0xfb.toByte(), 0x90.toByte(), 0x64, 1, 2, 3)
            source.writeBytes(header + genreFrame + audio)

            Mp3Id3TagWriter.rewrite(source, target, TrackMetadata(title = "New title"))

            val bytes = target.readBytes()
            val size = decodeSynchsafe(bytes, 6)
            assertTrue(containsFrame(bytes.copyOfRange(10, 10 + size), "TCON"))
            assertArrayEquals(audio, bytes.copyOfRange(10 + size, bytes.size))
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun rejectsUnsupportedTagFlagsWithoutProducingOutput() {
        val dir = createTempDir(prefix = "chiyuri-id3-")
        try {
            val source = File(dir, "source.mp3")
            val target = File(dir, "target.mp3")
            source.writeBytes(byteArrayOf(73, 68, 51, 4, 0, 0x40, 0, 0, 0, 0) +
                byteArrayOf(0xff.toByte(), 0xfb.toByte(), 0x90.toByte(), 0x64))

            val result = runCatching {
                Mp3Id3TagWriter.rewrite(source, target, TrackMetadata(title = "Must not write"))
            }

            assertTrue(result.isFailure)
            assertFalse(target.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun containsFrame(body: ByteArray, id: String): Boolean {
        val marker = id.toByteArray(Charsets.ISO_8859_1)
        return (0..body.size - marker.size).any { offset ->
            marker.indices.all { body[offset + it] == marker[it] }
        }
    }

    private fun decodeSynchsafe(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0x7f) shl 21) or
            ((bytes[offset + 1].toInt() and 0x7f) shl 14) or
            ((bytes[offset + 2].toInt() and 0x7f) shl 7) or
            (bytes[offset + 3].toInt() and 0x7f)

    private fun synchsafe(value: Int) = byteArrayOf(
        ((value shr 21) and 0x7f).toByte(),
        ((value shr 14) and 0x7f).toByte(),
        ((value shr 7) and 0x7f).toByte(),
        (value and 0x7f).toByte()
    )

    private fun int32(value: Int) = byteArrayOf(
        (value shr 24).toByte(), (value shr 16).toByte(),
        (value shr 8).toByte(), value.toByte()
    )
}
