package com.chiyuri.player

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class FlacMetadataWriterTest {
    @Test
    fun rewritesVorbisCommentsAndPreservesAudioAndUnknownBlocks() {
        val dir = createTempDir(prefix = "chiyuri-flac-")
        try {
            val source = File(dir, "source.flac")
            val target = File(dir, "target.flac")
            val audio = byteArrayOf(0xff.toByte(), 0xf8.toByte(), 0x12, 0x34, 5, 6, 7)
            val streamInfo = ByteArray(34) { it.toByte() }
            val application = byteArrayOf(0x43, 0x48, 0x59, 0x52, 1, 2, 3)
            val comments = vorbisComments(listOf("TITLE=Old", "GENRE=Ambient"))
            source.writeBytes(
                "fLaC".toByteArray(Charsets.ISO_8859_1) +
                    flacBlock(0, false, streamInfo) +
                    flacBlock(2, false, application) +
                    flacBlock(4, true, comments) +
                    audio
            )

            FlacMetadataWriter.rewrite(
                source, target,
                TrackMetadata(title = "Новая песня", artist = "Исполнитель", album = "Альбом", year = "2026",
                    plainLyrics = "Строка 1\nСтрока 2", syncedLyrics = "[00:01.00]Строка")
            )

            val result = target.readBytes()
            assertArrayEquals(audio, result.copyOfRange(result.size - audio.size, result.size))
            assertTrue(contains(result, "TITLE=Новая песня".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, "ARTIST=Исполнитель".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, "LYRICS_SYNCED=[00:01.00]Строка".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, "GENRE=Ambient".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, application))
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun rejectsInvalidStreamInfoWithoutWritingOutput() {
        val dir = createTempDir(prefix = "chiyuri-flac-")
        try {
            val source = File(dir, "source.flac")
            val target = File(dir, "target.flac")
            source.writeBytes("fLaC".toByteArray(Charsets.ISO_8859_1) + flacBlock(0, true, ByteArray(12)))
            val result = runCatching {
                FlacMetadataWriter.rewrite(source, target, TrackMetadata(title = "No write"))
            }
            assertTrue(result.isFailure)
            assertTrue(!target.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun flacBlock(type: Int, last: Boolean, data: ByteArray): ByteArray =
        byteArrayOf((type or (if (last) 0x80 else 0)).toByte(),
            (data.size ushr 16).toByte(), (data.size ushr 8).toByte(), data.size.toByte()) + data

    private fun vorbisComments(items: List<String>): ByteArray {
        val vendor = "test-vendor".toByteArray(Charsets.UTF_8)
        val out = java.io.ByteArrayOutputStream()
        writeLeInt(out, vendor.size)
        out.write(vendor)
        writeLeInt(out, items.size)
        items.forEach {
            val bytes = it.toByteArray(Charsets.UTF_8)
            writeLeInt(out, bytes.size)
            out.write(bytes)
        }
        return out.toByteArray()
    }

    private fun writeLeInt(out: java.io.ByteArrayOutputStream, value: Int) {
        out.write(value and 0xff); out.write((value ushr 8) and 0xff)
        out.write((value ushr 16) and 0xff); out.write((value ushr 24) and 0xff)
    }

    private fun contains(source: ByteArray, needle: ByteArray): Boolean =
        source.indices.any { start ->
            start + needle.size <= source.size &&
                needle.indices.all { source[start + it] == needle[it] }
        }
}

class Mp4MetadataWriterTest {
    @Test
    fun writesMetadataAndAdjustsChunkOffsetsWhenMoovPrecedesMdat() {
        val dir = createTempDir(prefix = "chiyuri-mp4-")
        try {
            val source = File(dir, "source.m4a")
            val target = File(dir, "target.m4a")
            val audio = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
            val ftyp = atom("ftyp", "M4A ".toByteArray(Charsets.ISO_8859_1) + ByteArray(8))
            val placeholderMoov = moovWithChunkOffset(0)
            val chunkOffset = ftyp.size + placeholderMoov.size + 8
            val moov = moovWithChunkOffset(chunkOffset)
            source.writeBytes(ftyp + moov + atom("mdat", audio))

            Mp4MetadataWriter.rewrite(
                source, target,
                TrackMetadata(title = "Новая песня", artist = "Исполнитель", album = "Альбом", year = "2026",
                    plainLyrics = "Текст песни", syncedLyrics = "[00:01.00]Текст")
            )

            val result = target.readBytes()
            assertTrue(contains(result, "Новая песня".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, "Исполнитель".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, "LYRICS_SYNCED".toByteArray(Charsets.UTF_8)))
            assertTrue(contains(result, audio))
            val oldMoovSize = moov.size
            val newMoovSize = readAtomSize(result, ftyp.size)
            val adjustedOffset = findStcoOffset(result)
            assertEquals((chunkOffset + newMoovSize - oldMoovSize).toLong(), adjustedOffset)
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun preservesMdatWhenMoovFollowsMediaData() {
        val dir = createTempDir(prefix = "chiyuri-mp4-")
        try {
            val source = File(dir, "source.m4a")
            val target = File(dir, "target.m4a")
            val audio = byteArrayOf(9, 8, 7, 6, 5)
            val ftyp = atom("ftyp", ByteArray(8))
            val moov = atom("moov", atom("trak", ByteArray(0)))
            source.writeBytes(ftyp + atom("mdat", audio) + moov)

            Mp4MetadataWriter.rewrite(source, target, TrackMetadata(title = "After mdat"))

            assertTrue(contains(target.readBytes(), audio))
            assertTrue(contains(target.readBytes(), "After mdat".toByteArray(Charsets.UTF_8)))
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun moovWithChunkOffset(offset: Int): ByteArray {
        val stcoPayload = ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN)
            .putInt(0).putInt(1).putInt(offset).array()
        val stco = atom("stco", stcoPayload)
        val stbl = atom("stbl", stco)
        val minf = atom("minf", stbl)
        val mdia = atom("mdia", minf)
        val trak = atom("trak", mdia)
        return atom("moov", trak)
    }

    private fun atom(type: String, payload: ByteArray): ByteArray =
        ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
            .putInt(payload.size + 8).put(type.toByteArray(Charsets.ISO_8859_1)).array() + payload

    private fun readAtomSize(bytes: ByteArray, offset: Int): Int =
        ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.BIG_ENDIAN).int

    private fun findStcoOffset(bytes: ByteArray): Long {
        val marker = "stco".toByteArray(Charsets.ISO_8859_1)
        val index = bytes.indices.first { start ->
            start + marker.size <= bytes.size && marker.indices.all { bytes[start + it] == marker[it] }
        }
        return ByteBuffer.wrap(bytes, index + 12, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xffffffffL
    }

    private fun contains(source: ByteArray, needle: ByteArray): Boolean =
        source.indices.any { start ->
            start + needle.size <= source.size &&
                needle.indices.all { source[start + it] == needle[it] }
        }
}
