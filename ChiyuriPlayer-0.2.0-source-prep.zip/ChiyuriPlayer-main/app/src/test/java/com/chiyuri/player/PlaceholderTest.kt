package com.chiyuri.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PlaylistNameTest {
    @Test
    fun trimsWhitespaceAroundPlaylistName() {
        assertEquals("Evening Mix", normalizePlaylistName("  Evening Mix  "))
    }

    @Test
    fun rejectsBlankPlaylistName() {
        assertNull(normalizePlaylistName("   "))
    }

    @Test
    fun rejectsNamesLongerThanEightyCharacters() {
        assertNull(normalizePlaylistName("a".repeat(81)))
    }

    @Test
    fun acceptsNameAtMaximumLength() {
        assertEquals("a".repeat(80), normalizePlaylistName("a".repeat(80)))
    }
}


class MediaLibrarySortingTest {
    private fun item(id: Long, title: String, artist: String?, duration: Long) =
        MediaSortKey(id, title, artist, duration)

    @Test
    fun sortsByTitleIgnoringCase() {
        val input = listOf(item(1, "zeta", null, 10), item(2, "Alpha", null, 20))
        assertEquals(listOf(2L, 1L), sortMediaKeys(input, MediaSortOrder.TITLE).map { it.id })
    }

    @Test
    fun sortsByArtistAndPlacesMissingArtistsFirst() {
        val input = listOf(
            item(1, "Song B", "Zen", 10),
            item(2, "Song A", null, 20),
            item(3, "Song C", "alpha", 30)
        )
        assertEquals(listOf(2L, 3L, 1L), sortMediaKeys(input, MediaSortOrder.ARTIST).map { it.id })
    }

    @Test
    fun sortsByDurationAndSupportsDescendingOrder() {
        val input = listOf(item(1, "Long", null, 3000), item(2, "Short", null, 1000))
        assertEquals(listOf(2L, 1L), sortMediaKeys(input, MediaSortOrder.DURATION).map { it.id })
        assertEquals(listOf(1L, 2L), sortMediaKeys(input, MediaSortOrder.DURATION, descending = true).map { it.id })
    }

    @Test
    fun doesNotMutateOriginalList() {
        val input = listOf(item(1, "B", null, 1), item(2, "A", null, 2))
        sortMediaKeys(input, MediaSortOrder.TITLE)
        assertEquals(listOf(1L, 2L), input.map { it.id })
    }
}

class M3uPlaylistCodecTest {
    @Test
    fun parsesExtendedInfoAndPreservesAbsoluteAndRelativeLocations() {
        val input = "\uFEFF#EXTM3U\r\n#EXTINF:245,Artist - Song\r\ncontent://media/external/audio/1\r\n#EXTINF:-1,Remote\r\nhttps://example.com/audio.mp3\r\nfolder/track.ogg"
        val entries = M3uPlaylistCodec.parse(input)

        assertEquals(3, entries.size)
        assertEquals("Artist - Song", entries[0].title)
        assertEquals(245L, entries[0].durationSeconds)
        assertEquals("content://media/external/audio/1", entries[0].location)
        assertEquals("Remote", entries[1].title)
        assertNull(entries[1].durationSeconds)
        assertEquals("track.ogg", entries[2].title)
        assertEquals("folder/track.ogg", entries[2].location)
    }

    @Test
    fun ignoresCommentsAndBlankLines() {
        val entries = M3uPlaylistCodec.parse(
            "#EXTM3U\n\n#PLAYLIST:Favorites\n#EXTVLCOPT:start-time=10\nhttps://example.com/a.mp3\n"
        )
        assertEquals(1, entries.size)
        assertEquals("a.mp3", entries.single().title)
    }

    @Test
    fun malformedExtinfDoesNotDropFollowingEntry() {
        val entries = M3uPlaylistCodec.parse("#EXTINF:not-a-number,Kept title\nrelative/song.mp3")
        assertEquals(1, entries.size)
        assertEquals("Kept title", entries.single().title)
        assertNull(entries.single().durationSeconds)
    }

    @Test
    fun parsesEmptyAndHeaderOnlyPlaylists() {
        assertEquals(emptyList<M3uEntry>(), M3uPlaylistCodec.parse(""))
        assertEquals(emptyList<M3uEntry>(), M3uPlaylistCodec.parse("#EXTM3U\n# comment"))
    }

    @Test
    fun formatsAndParsesPlaylistWithoutLosingMetadata() {
        val original = listOf(
            M3uEntry("content://media/audio/7", "A song, with comma", 183L),
            M3uEntry("https://example.com/b.mp3", "Unknown duration", null)
        )
        val parsed = M3uPlaylistCodec.parse(M3uPlaylistCodec.format(original))
        assertEquals(original, parsed)
    }

    @Test
    fun formatterSkipsEmptyOrMultilineLocations() {
        val formatted = M3uPlaylistCodec.format(
            listOf(
                M3uEntry("", "Empty", 1L),
                M3uEntry("content://valid/1\n#EXTM3U", "Invalid", 2L),
                M3uEntry("content://valid/2", "Valid", 3L)
            )
        )
        assertEquals(1, M3uPlaylistCodec.parse(formatted).size)
    }
}


class PlaybackTimeFormatterTest {
    @Test
    fun formatsMinutesAndSeconds() {
        assertEquals("0:00", formatPlaybackTime(0L))
        assertEquals("1:05", formatPlaybackTime(65_000L))
        assertEquals("59:59", formatPlaybackTime(3_599_000L))
    }

    @Test
    fun formatsHoursAndClampsNegativePositions() {
        assertEquals("1:00:01", formatPlaybackTime(3_601_000L))
        assertEquals("0:00", formatPlaybackTime(-5_000L))
    }
}


class AudioEffectsConfigTest {
    @Test
    fun clampsEqualizerBassAndVolumeValues() {
        val normalized = normalizeAudioEffectsConfig(
            AudioEffectsConfig(
                equalizerEnabled = true,
                bandsDb = listOf(-30f, -6f, 0f, 8f, 30f),
                bassBoostStrength = 1200f,
                playerVolume = 2.5f
            )
        )

        assertEquals(listOf(-12f, -6f, 0f, 8f, 12f), normalized.bandsDb)
        assertEquals(1000f, normalized.bassBoostStrength, 0f)
        assertEquals(2f, normalized.playerVolume, 0f)
        assertEquals(true, normalized.equalizerEnabled)
    }

    @Test
    fun fillsMissingBandsAndReplacesNonFiniteValues() {
        val normalized = normalizeAudioEffectsConfig(
            AudioEffectsConfig(
                bandsDb = listOf(Float.NaN, Float.POSITIVE_INFINITY),
                bassBoostStrength = Float.NaN,
                playerVolume = Float.NEGATIVE_INFINITY
            )
        )

        assertEquals(listOf(0f, 0f, 0f, 0f, 0f), normalized.bandsDb)
        assertEquals(0f, normalized.bassBoostStrength, 0f)
        assertEquals(1f, normalized.playerVolume, 0f)
    }

    @Test
    fun oldAppOnlyVolumeBelowOneBecomesNeutralBoost() {
        val normalized = normalizeAudioEffectsConfig(
            AudioEffectsConfig(playerVolume = 0.35f)
        )
        assertEquals(1f, normalized.playerVolume, 0f)
    }

    @Test
    fun boostIsClampedToOneHundredPercentAboveAndroidVolume() {
        val normalized = normalizeAudioEffectsConfig(
            AudioEffectsConfig(playerVolume = 3f)
        )
        assertEquals(2f, normalized.playerVolume, 0f)
    }
}
