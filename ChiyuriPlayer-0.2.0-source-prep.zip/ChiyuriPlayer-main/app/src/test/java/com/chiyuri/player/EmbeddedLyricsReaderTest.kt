package com.chiyuri.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class EmbeddedLyricsReaderTest {
    @Test
    fun readsPlainAndCustomSyncedLyricsFromId3v24() {
        val uslt = byteArrayOf(3, 'e'.code.toByte(), 'n'.code.toByte(), 'g'.code.toByte(), 0) +
            "Plain lyrics".toByteArray(Charsets.UTF_8)
        val txxx = byteArrayOf(3) + "LYRICS_SYNCED".toByteArray(Charsets.UTF_8) + byteArrayOf(0) +
            "[00:01.00]Line".toByteArray(Charsets.UTF_8)
        val tag = id3Frame("USLT", uslt) + id3Frame("TXXX", txxx)
        val bytes = "ID3".toByteArray(Charsets.ISO_8859_1) + byteArrayOf(4, 0, 0) +
            synchsafe(tag.size) + tag + byteArrayOf(1, 2, 3)
        val result = EmbeddedLyricsReader.read(bytes)
        assertEquals("Plain lyrics", result?.plainLyrics)
        assertEquals("[00:01.00]Line", result?.syncedLyrics)
    }

    @Test
    fun convertsStandardId3SyltMillisecondTimestampsToLrc() {
        val syltPayload = byteArrayOf(
            3, 'e'.code.toByte(), 'n'.code.toByte(), 'g'.code.toByte(),
            2, 1, 0
        ) + "Timed line".toByteArray(Charsets.UTF_8) + byteArrayOf(0) +
            byteArrayOf(0, 0, 0x05, 0xdc.toByte())
        val tag = id3Frame("SYLT", syltPayload)
        val bytes = "ID3".toByteArray(Charsets.ISO_8859_1) + byteArrayOf(4, 0, 0) +
            synchsafe(tag.size) + tag
        val result = EmbeddedLyricsReader.read(bytes)
        assertEquals("[00:01.50]Timed line", result?.syncedLyrics)
    }

    @Test
    fun readsVorbisCommentLyricsFromFlac() {
        val comments = vorbisComments(listOf("TITLE=Track", "LYRICS=First line", "LYRICS_SYNCED=[00:02.00]Second"))
        val bytes = "fLaC".toByteArray(Charsets.ISO_8859_1) +
            flacBlock(0, false, ByteArray(34)) +
            flacBlock(4, true, comments) +
            byteArrayOf(0xff.toByte(), 0xf8.toByte(), 0x10)
        val result = EmbeddedLyricsReader.read(bytes)
        assertEquals("First line", result?.plainLyrics)
        assertEquals("[00:02.00]Second", result?.syncedLyrics)
    }

    @Test
    fun readsAppleM4aLyricsAndSyncedFreeformLyrics() {
        val plain = atom("©lyr", atom("data", dataPayload("M4A lyrics")))
        val mean = atom("mean", ByteArray(4) + "com.apple.iTunes".toByteArray(Charsets.UTF_8))
        val name = atom("name", ByteArray(4) + "LYRICS_SYNCED".toByteArray(Charsets.UTF_8))
        val synced = atom("----", mean + name + atom("data", dataPayload("[00:03.00]Timed")))
        val ilst = atom("ilst", plain + synced)
        val meta = atom("meta", ByteArray(4) + atom("hdlr", ByteArray(24)) + ilst)
        val bytes = atom("ftyp", ByteArray(8)) + atom("moov", atom("udta", meta))
        val result = EmbeddedLyricsReader.read(bytes)
        assertEquals("M4A lyrics", result?.plainLyrics)
        assertEquals("[00:03.00]Timed", result?.syncedLyrics)
    }

    @Test
    fun malformedInputReturnsNullWithoutThrowing() {
        assertNull(EmbeddedLyricsReader.read(byteArrayOf(1, 2, 3, 4, 5)))
        assertNull(EmbeddedLyricsReader.read("ID3".toByteArray() + byteArrayOf(4, 0, 0, 0x7f, 0x7f, 0x7f, 0x7f)))
    }

    private fun id3Frame(id: String, payload: ByteArray): ByteArray =
        id.toByteArray(Charsets.ISO_8859_1) + synchsafe(payload.size) + byteArrayOf(0, 0) + payload

    private fun synchsafe(value: Int): ByteArray = byteArrayOf(
        ((value ushr 21) and 0x7f).toByte(),
        ((value ushr 14) and 0x7f).toByte(),
        ((value ushr 7) and 0x7f).toByte(),
        (value and 0x7f).toByte()
    )

    private fun flacBlock(type: Int, last: Boolean, data: ByteArray): ByteArray =
        byteArrayOf((type or (if (last) 0x80 else 0)).toByte(),
            (data.size ushr 16).toByte(), (data.size ushr 8).toByte(), data.size.toByte()) + data

    private fun vorbisComments(items: List<String>): ByteArray {
        val output = ByteArrayOutputStream()
        fun writeLe(value: Int) {
            output.write(value and 0xff); output.write((value ushr 8) and 0xff)
            output.write((value ushr 16) and 0xff); output.write((value ushr 24) and 0xff)
        }
        val vendor = "test".toByteArray()
        writeLe(vendor.size); output.write(vendor); writeLe(items.size)
        items.forEach { item ->
            val data = item.toByteArray(Charsets.UTF_8)
            writeLe(data.size); output.write(data)
        }
        return output.toByteArray()
    }

    private fun dataPayload(value: String): ByteArray =
        ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putInt(1).putInt(0).array() +
            value.toByteArray(Charsets.UTF_8)

    private fun atom(type: String, payload: ByteArray): ByteArray =
        ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putInt(payload.size + 8)
            .put(type.toByteArray(Charsets.ISO_8859_1)).array() + payload
}
