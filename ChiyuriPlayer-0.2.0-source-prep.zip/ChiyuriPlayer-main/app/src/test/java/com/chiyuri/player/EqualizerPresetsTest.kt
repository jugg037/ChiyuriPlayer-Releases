package com.chiyuri.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EqualizerPresetsTest {
    @Test
    fun applyingPresetEnablesEqualizerAndSetsFiveBands() {
        val initial = AudioEffectsConfig(equalizerEnabled = false, bandsDb = List(5) { 0f })
        val preset = EqualizerPresets.all.first { it.id == "rock" }
        val updated = EqualizerPresets.apply(initial, preset)
        assertTrue(updated.equalizerEnabled)
        assertEquals(preset.bandsDb, updated.bandsDb)
        assertEquals("rock", EqualizerPresets.selectedPreset(updated))
    }

    @Test
    fun customBandChangeClearsPresetSelection() {
        val config = EqualizerPresets.apply(AudioEffectsConfig(), EqualizerPresets.all.first { it.id == "pop" })
        val custom = config.copy(bandsDb = config.bandsDb.toMutableList().also { it[2] = 11f })
        assertFalse(EqualizerPresets.selectedPreset(custom) == "pop")
    }

    @Test
    fun presetValuesStayWithinSupportedBandRange() {
        EqualizerPresets.all.forEach { preset ->
            assertEquals(5, preset.bandsDb.size)
            assertTrue(preset.bandsDb.all { it in -12f..12f })
        }
    }
}
