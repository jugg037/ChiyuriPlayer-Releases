package com.chiyuri.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricsSearchMatchingTest {
    @Test
    fun titleVariantsRemoveFeaturingAndPromotionalSuffixes() {
        assertEquals(
            listOf("Song (feat. Guest)", "Song"),
            lyricsTitleVariants("Song (feat. Guest)")
        )
        assertEquals(
            "Song",
            lyricsTitleVariants("Song - Official Video").last()
        )
    }

    @Test
    fun artistVariantsKeepMainPerformer() {
        assertEquals(
            listOf("Main Artist feat. Guest", "Main Artist"),
            lyricsArtistVariants("Main Artist feat. Guest")
        )
    }

    @Test
    fun similarityIgnoresPunctuationAndCase() {
        assertEquals(1.0, lyricsTextSimilarity("HELLO—WORLD!", "hello world"), 0.0)
    }

    @Test
    fun parsesMultipleLrcTimestampsAndCentiseconds() {
        assertEquals(
            listOf(TimedLyricLine(12_340L, "Line"), TimedLyricLine(15_000L, "Line")),
            parseLrcLyrics("[00:12.34][00:15.0]Line")
        )
    }

    @Test
    fun similarityRecognizesCloseTitlesButRejectsUnrelatedOnes() {
        assertTrue(lyricsTextSimilarity("Never Gonna Give You Up", "Never Gonna Give You Up (Remastered)") > 0.65)
        assertTrue(lyricsTextSimilarity("Never Gonna Give You Up", "Blue Monday") < 0.3)
    }
}
