package com.chiyuri.player

import org.junit.Assert.assertEquals
import org.junit.Test

class AppearanceAndVisualizerSettingsTest {
    @Test
    fun unknownThemeModeFallsBackToSystem() {
        assertEquals(AppThemeMode.SYSTEM, AppThemeMode.fromStorage("unknown"))
        assertEquals(AppThemeMode.SYSTEM, AppThemeMode.fromStorage(null))
    }

    @Test
    fun allThemeModesRoundTripThroughStorageValues() {
        AppThemeMode.entries.forEach { mode ->
            assertEquals(mode, AppThemeMode.fromStorage(mode.storageValue))
        }
    }

    @Test
    fun unknownVisualizerModeFallsBackToBars() {
        assertEquals(VisualizerMode.BARS, VisualizerMode.from("invalid"))
        assertEquals(VisualizerMode.BARS, VisualizerMode.from(null))
    }

    @Test
    fun allVisualizerModesRoundTripThroughStorageValues() {
        VisualizerMode.entries.forEach { mode ->
            assertEquals(mode, VisualizerMode.from(mode.storageValue))
        }
    }
}

class LrcLyricsParserTest {
    @Test
    fun parsesCentisecondsAndSortsLines() {
        val lines = parseLrcLyrics("[00:02.50]Second\n[00:01.25]First")
        assertEquals(listOf(1_250L, 2_500L), lines.map { it.timeMs })
        assertEquals(listOf("First", "Second"), lines.map { it.text })
    }

    @Test
    fun expandsMultipleTimestampsAndHandlesEmptyLineText() {
        val lines = parseLrcLyrics("[01:02.3][01:03.45]♪")
        assertEquals(listOf(62_300L, 63_450L), lines.map { it.timeMs })
        assertEquals(listOf("♪", "♪"), lines.map { it.text })
    }

    @Test
    fun ignoresMalformedAndOutOfRangeSeconds() {
        val lines = parseLrcLyrics("[00:99.00]Bad\n[not-a-time]Ignored\n[00:04]Good")
        assertEquals(1, lines.size)
        assertEquals(4_000L, lines.single().timeMs)
        assertEquals("Good", lines.single().text)
    }
}


class LyricsTextFormatterTest {
    @Test
    fun preservesExistingLinesAndAddsStanzaBreaks() {
        val source = "line one\nline two\nline three\nline four\nline five"
        assertEquals("line one\nline two\nline three\nline four\n\nline five", LyricsTextFormatter.format(source))
    }

    @Test
    fun splitsSingleParagraphIntoReadableLines() {
        val formatted = LyricsTextFormatter.format(
            "First sentence. Second sentence! Third sentence? Fourth sentence."
        )
        assertEquals(
            "First sentence.\nSecond sentence!\nThird sentence?\nFourth sentence.",
            formatted
        )
    }
}
