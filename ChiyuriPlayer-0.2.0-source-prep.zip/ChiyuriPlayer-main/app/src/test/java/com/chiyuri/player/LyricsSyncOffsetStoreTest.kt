package com.chiyuri.player

import org.junit.Assert.assertEquals
import org.junit.Test

class LyricsSyncOffsetStoreTest {
    @Test
    fun keepsOffsetsInsideTenSecondSafetyRange() {
        assertEquals(-10_000, LyricsSyncOffsetStore.normalize(-50_000L))
        assertEquals(10_000, LyricsSyncOffsetStore.normalize(50_000L))
    }

    @Test
    fun preservesValidOffsets() {
        assertEquals(-1_250, LyricsSyncOffsetStore.normalize(-1_250L))
        assertEquals(0, LyricsSyncOffsetStore.normalize(0L))
        assertEquals(3_400, LyricsSyncOffsetStore.normalize(3_400L))
    }
}
