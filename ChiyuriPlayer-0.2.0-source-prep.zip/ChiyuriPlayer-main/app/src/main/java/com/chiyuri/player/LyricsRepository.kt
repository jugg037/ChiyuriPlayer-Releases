package com.chiyuri.player

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class TimedLyricLine(val timeMs: Long, val text: String)

data class LyricsResult(
    val plainLyrics: String?,
    val syncedLyrics: String?
)

private data class LyricsCandidate(
    val result: LyricsResult,
    val title: String,
    val artist: String,
    val durationSeconds: Long
)

object LyricsRepository {
    suspend fun search(artist: String, title: String, durationMs: Long): LyricsResult? =
        withContext(Dispatchers.IO) {
            val cleanTitle = title.trim()
            if (cleanTitle.isBlank()) return@withContext null
            val cleanArtist = artist.trim()
            val durationSeconds = (durationMs / 1000L).takeIf { it > 0L }

            val titleVariants = lyricsTitleVariants(cleanTitle)
            val artistVariants = lyricsArtistVariants(cleanArtist)
            val candidates = linkedMapOf<String, LyricsCandidate>()

            // Try LRCLIB's exact endpoint first, including common title/artist variants.
            for (titleVariant in titleVariants.take(3)) {
                val artistAttempts = (artistVariants.take(2) + "").distinct()
                for (artistVariant in artistAttempts) {
                    val path = buildString {
                        append("/api/get?track_name=").append(encode(titleVariant))
                        if (artistVariant.isNotBlank()) append("&artist_name=").append(encode(artistVariant))
                        if (durationSeconds != null) append("&duration=").append(durationSeconds)
                    }
                    val raw = request(path) ?: continue
                    val candidate = runCatching { parseCandidate(JSONObject(raw)) }.getOrNull() ?: continue
                    val key = candidateKey(candidate)
                    candidates.putIfAbsent(key, candidate)
                    if (isStrongMatch(candidate, cleanTitle, cleanArtist, durationSeconds)) {
                        return@withContext candidate.result
                    }
                }
            }

            // Broaden search progressively: title + artist, title only, then a free-text query.
            for (titleVariant in titleVariants) {
                for (artistVariant in (artistVariants.take(2) + "").distinct()) {
                    val path = buildString {
                        append("/api/search?track_name=").append(encode(titleVariant))
                        if (artistVariant.isNotBlank()) append("&artist_name=").append(encode(artistVariant))
                    }
                    addSearchResults(request(path), candidates)
                }
            }
            val freeText = listOf(cleanArtist, cleanTitle).filter { it.isNotBlank() }.joinToString(" ")
            if (freeText.isNotBlank()) {
                addSearchResults(request("/api/search?q=" + encode(freeText)), candidates)
            }

            candidates.values
                .map { it to lyricsCandidateScore(it, cleanTitle, cleanArtist, durationSeconds) }
                .filter { (_, score) -> score >= 0.50 }
                .maxByOrNull { it.second }
                ?.first?.result
        }

    private fun addSearchResults(raw: String?, target: MutableMap<String, LyricsCandidate>) {
        if (raw.isNullOrBlank()) return
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val candidate = parseCandidate(item) ?: continue
            target.putIfAbsent(candidateKey(candidate), candidate)
        }
    }

    private fun request(path: String): String? {
        val connection = (URL("https://lrclib.net$path").openConnection() as HttpURLConnection)
        return try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 7_000
            connection.readTimeout = 7_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "ChiyuriPlayer/0.2")
            if (connection.responseCode !in 200..299) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun parseCandidate(json: JSONObject): LyricsCandidate? {
        val plain = json.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
        val synced = json.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
        if (plain == null && synced == null) return null
        return LyricsCandidate(
            LyricsResult(plain, synced),
            json.optString("trackName"),
            json.optString("artistName"),
            json.optLong("duration").takeIf { it > 0L } ?: 0L
        )
    }

    private fun candidateKey(candidate: LyricsCandidate): String =
        "${normalizeLyricsText(candidate.title)}|${normalizeLyricsText(candidate.artist)}"

    private fun isStrongMatch(
        candidate: LyricsCandidate,
        title: String,
        artist: String,
        duration: Long?
    ): Boolean = lyricsCandidateScore(candidate, title, artist, duration) >= 0.88

    private fun lyricsCandidateScore(
        candidate: LyricsCandidate,
        title: String,
        artist: String,
        duration: Long?
    ): Double {
        val titleScore = lyricsTextSimilarity(title, candidate.title)
        val artistScore = if (artist.isBlank()) 0.65 else lyricsTextSimilarity(artist, candidate.artist)
        val durationScore = if (duration == null || candidate.durationSeconds <= 0L) 0.5 else {
            val difference = kotlin.math.abs(duration - candidate.durationSeconds).toDouble()
            (1.0 - difference / maxOf(duration.toDouble(), candidate.durationSeconds.toDouble(), 1.0)).coerceIn(0.0, 1.0)
        }
        return titleScore * 0.68 + artistScore * 0.24 + durationScore * 0.08
    }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())
}

internal fun lyricsTitleVariants(title: String): List<String> {
    val original = title.trim()
    val withoutFeatures = original.replace(
        Regex("(?i)\\s*\\((feat\\.?|ft\\.?|featuring)[^)]*\\)|\\s*\\[(feat\\.?|ft\\.?|featuring)[^]]*]"),
        ""
    ).trim()
    val withoutVersion = withoutFeatures.replace(
        Regex("(?i)\\s*[-–—]\\s*(official video|official audio|lyrics video|lyric video|visualizer|remastered|radio edit)$"),
        ""
    ).trim()
    return listOf(original, withoutFeatures, withoutVersion)
        .filter { it.isNotBlank() }
        .distinctBy(::normalizeLyricsText)
}

internal fun lyricsArtistVariants(artist: String): List<String> {
    val original = artist.trim()
    val primary = original.split(Regex("(?i)\\s+(?:feat\\.?|ft\\.?|featuring)\\s+|,|;| & | and "))
        .firstOrNull().orEmpty().trim()
    return listOf(original, primary).filter { it.isNotBlank() }.distinctBy(::normalizeLyricsText)
}

internal fun normalizeLyricsText(value: String): String =
    value.lowercase(Locale.ROOT)
        .replace("&", " and ")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

internal fun lyricsTextSimilarity(first: String, second: String): Double {
    val a = normalizeLyricsText(first)
    val b = normalizeLyricsText(second)
    if (a.isBlank() || b.isBlank()) return 0.0
    if (a == b) return 1.0
    if (a.contains(b) || b.contains(a)) return minOf(a.length, b.length).toDouble() / maxOf(a.length, b.length)
    val aTokens = a.split(' ').toSet()
    val bTokens = b.split(' ').toSet()
    val union = (aTokens + bTokens).size
    val tokenScore = if (union == 0) 0.0 else aTokens.intersect(bTokens).size.toDouble() / union
    val distance = levenshteinDistance(a, b)
    val editScore = 1.0 - distance.toDouble() / maxOf(a.length, b.length)
    return (tokenScore * 0.65 + editScore * 0.35).coerceIn(0.0, 1.0)
}

private fun levenshteinDistance(a: String, b: String): Int {
    var previous = IntArray(b.length + 1) { it }
    for (i in a.indices) {
        val current = IntArray(b.length + 1)
        current[0] = i + 1
        for (j in b.indices) {
            val substitution = previous[j] + if (a[i] == b[j]) 0 else 1
            current[j + 1] = minOf(previous[j + 1] + 1, current[j] + 1, substitution)
        }
        previous = current
    }
    return previous[b.length]
}

fun parseLrcLyrics(content: String): List<TimedLyricLine> {
    val timestampPattern = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")
    val result = mutableListOf<TimedLyricLine>()
    content.lineSequence().forEach lineLoop@{ raw ->
        val matches = timestampPattern.findAll(raw).toList()
        if (matches.isEmpty()) return@lineLoop
        val text = timestampPattern.replace(raw, "").trim()
        matches.forEach matchLoop@{ match ->
            val minutes = match.groupValues[1].toLongOrNull() ?: return@matchLoop
            val seconds = match.groupValues[2].toLongOrNull() ?: return@matchLoop
            val fraction = match.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            if (seconds < 60L) {
                result += TimedLyricLine(minutes * 60_000L + seconds * 1_000L + fraction, text)
            }
        }
    }
    return result.sortedBy { it.timeMs }
}
