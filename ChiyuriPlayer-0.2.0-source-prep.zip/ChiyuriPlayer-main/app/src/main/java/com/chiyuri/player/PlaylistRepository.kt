package com.chiyuri.player

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri

data class Playlist(
    val id: Long,
    val name: String,
    val trackCount: Int
)

data class PlaylistTrack(
    val id: Long,
    val playlistId: Long,
    val title: String,
    val artist: String?,
    val uri: String,
    val durationMs: Long,
    val mimeType: String?
)

fun normalizePlaylistName(value: String): String? {
    val normalized = value.trim()
    return normalized.takeIf { it.isNotEmpty() && it.length <= 80 }
}

class PlaylistRepository(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE playlists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE playlist_tracks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                playlist_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                artist TEXT,
                uri TEXT NOT NULL,
                duration_ms INTEGER NOT NULL DEFAULT 0,
                mime_type TEXT,
                added_at INTEGER NOT NULL,
                FOREIGN KEY(playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
                UNIQUE(playlist_id, uri)
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE INDEX index_playlist_tracks_playlist_id ON playlist_tracks(playlist_id, added_at)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Schema migrations are added here when the database version changes.
    }

    fun getPlaylists(): List<Playlist> {
        val result = mutableListOf<Playlist>()
        readableDatabase.rawQuery(
            """
            SELECT p.id, p.name, COUNT(t.id) AS track_count
            FROM playlists p
            LEFT JOIN playlist_tracks t ON t.playlist_id = p.id
            GROUP BY p.id, p.name
            ORDER BY p.name COLLATE NOCASE ASC
            """.trimIndent(),
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += Playlist(
                    id = cursor.getLong(0),
                    name = cursor.getString(1),
                    trackCount = cursor.getInt(2)
                )
            }
        }
        return result
    }

    fun getTracks(playlistId: Long): List<PlaylistTrack> {
        val result = mutableListOf<PlaylistTrack>()
        readableDatabase.query(
            "playlist_tracks",
            arrayOf("id", "playlist_id", "title", "artist", "uri", "duration_ms", "mime_type"),
            "playlist_id = ?",
            arrayOf(playlistId.toString()),
            null,
            null,
            "added_at ASC, id ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += PlaylistTrack(
                    id = cursor.getLong(0),
                    playlistId = cursor.getLong(1),
                    title = cursor.getString(2),
                    artist = cursor.getString(3),
                    uri = cursor.getString(4),
                    durationMs = cursor.getLong(5),
                    mimeType = cursor.getString(6)
                )
            }
        }
        return result
    }

    fun createPlaylist(rawName: String): Long? {
        val name = normalizePlaylistName(rawName) ?: return null
        val values = ContentValues().apply {
            put("name", name)
            put("created_at", System.currentTimeMillis())
        }
        val id = writableDatabase.insertWithOnConflict(
            "playlists",
            null,
            values,
            SQLiteDatabase.CONFLICT_IGNORE
        )
        return id.takeIf { it > 0L }
    }

    fun renamePlaylist(playlistId: Long, rawName: String): Boolean {
        val name = normalizePlaylistName(rawName) ?: return false
        val values = ContentValues().apply { put("name", name) }
        return try {
            writableDatabase.update(
                "playlists",
                values,
                "id = ?",
                arrayOf(playlistId.toString())
            ) > 0
        } catch (_: SQLiteConstraintException) {
            false
        }
    }

    fun deletePlaylist(playlistId: Long): Boolean =
        writableDatabase.delete(
            "playlists",
            "id = ?",
            arrayOf(playlistId.toString())
        ) > 0

    fun addTrack(
        playlistId: Long,
        uri: Uri,
        title: String,
        artist: String?,
        durationMs: Long,
        mimeType: String?
    ): Boolean {
        val values = ContentValues().apply {
            put("playlist_id", playlistId)
            put("title", title.ifBlank { "Без названия" })
            put("artist", artist)
            put("uri", uri.toString())
            put("duration_ms", durationMs.coerceAtLeast(0L))
            put("mime_type", mimeType)
            put("added_at", System.currentTimeMillis())
        }
        return writableDatabase.insertWithOnConflict(
            "playlist_tracks",
            null,
            values,
            SQLiteDatabase.CONFLICT_IGNORE
        ) > 0L
    }

    fun removeTrack(trackId: Long): Boolean =
        writableDatabase.delete(
            "playlist_tracks",
            "id = ?",
            arrayOf(trackId.toString())
        ) > 0

    companion object {
        private const val DATABASE_NAME = "chiyuri_library.db"
        private const val DATABASE_VERSION = 1
    }
}
