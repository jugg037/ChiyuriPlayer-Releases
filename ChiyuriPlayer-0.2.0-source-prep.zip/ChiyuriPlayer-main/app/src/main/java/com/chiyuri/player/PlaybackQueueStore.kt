package com.chiyuri.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists the current playback queue between app/service restarts.
 * URI permissions for document-provider files are retained by MainActivity.
 */
object PlaybackQueueStore {
    private const val PREFS = "playback_queue"
    private const val ITEMS = "items"
    private const val CURRENT_INDEX = "current_index"
    private const val POSITION = "position_ms"

    fun save(context: Context, player: Player) {
        val array = JSONArray()
        for (index in 0 until player.mediaItemCount) {
            val item = player.getMediaItemAt(index)
            val uri = item.localConfiguration?.uri?.toString() ?: continue
            val metadata = item.mediaMetadata
            array.put(
                JSONObject()
                    .put("uri", uri)
                    .put("title", metadata.title?.toString() ?: JSONObject.NULL)
                    .put("artist", metadata.artist?.toString() ?: JSONObject.NULL)
                    .put("mime_type", item.localConfiguration?.mimeType ?: JSONObject.NULL)
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(ITEMS, array.toString())
            .putInt(CURRENT_INDEX, player.currentMediaItemIndex)
            .putLong(POSITION, player.currentPosition.coerceAtLeast(0L))
            .apply()
    }

    /** Restores a saved queue without starting playback automatically. */
    fun restore(context: Context, player: Player) {
        if (player.mediaItemCount > 0) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(ITEMS, null) ?: return

        try {
            val array = JSONArray(raw)
            val items = buildList {
                for (index in 0 until array.length()) {
                    val entry = array.optJSONObject(index) ?: continue
                    val uri = entry.optString("uri").takeIf { it.isNotBlank() } ?: continue
                    val metadata = MediaMetadata.Builder()
                        .setTitle(entry.nullableText("title"))
                        .setArtist(entry.nullableText("artist"))
                        .build()
                    add(
                        MediaItem.Builder()
                            .setUri(Uri.parse(uri))
                            .setMimeType(entry.nullableText("mime_type"))
                            .setMediaMetadata(metadata)
                            .build()
                    )
                }
            }
            if (items.isEmpty()) return

            val savedIndex = prefs.getInt(CURRENT_INDEX, 0)
                .coerceIn(0, items.lastIndex)
            val savedPosition = prefs.getLong(POSITION, 0L).coerceAtLeast(0L)
            player.setMediaItems(items, savedIndex, savedPosition)
            player.prepare()
            player.pause()
        } catch (_: Exception) {
            // A malformed or obsolete cache must not prevent the player from starting.
        }
    }

    private fun JSONObject.nullableText(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).takeIf { it.isNotBlank() }
    }
}
