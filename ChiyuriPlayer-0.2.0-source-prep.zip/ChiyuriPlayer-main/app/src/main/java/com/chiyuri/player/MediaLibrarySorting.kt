package com.chiyuri.player

enum class MediaSortOrder {
    TITLE,
    ARTIST,
    DURATION
}

/** Android-independent values used by the media sorting comparator and its unit tests. */
data class MediaSortKey(
    val id: Long,
    val title: String,
    val artist: String?,
    val durationMs: Long
)

fun sortMediaKeys(
    items: List<MediaSortKey>,
    order: MediaSortOrder,
    descending: Boolean = false
): List<MediaSortKey> {
    val comparator = when (order) {
        MediaSortOrder.TITLE -> compareBy<MediaSortKey> { it.title.lowercase() }
            .thenBy { it.id }
        MediaSortOrder.ARTIST -> compareBy<MediaSortKey> { it.artist.orEmpty().lowercase() }
            .thenBy { it.title.lowercase() }
            .thenBy { it.id }
        MediaSortOrder.DURATION -> compareBy<MediaSortKey> { it.durationMs }
            .thenBy { it.title.lowercase() }
            .thenBy { it.id }
    }
    val sorted = items.sortedWith(comparator)
    return if (descending) sorted.asReversed() else sorted
}

fun sortLocalMedia(
    items: List<LocalMedia>,
    order: MediaSortOrder,
    descending: Boolean = false
): List<LocalMedia> {
    val byId = items.associateBy { it.id }
    return sortMediaKeys(
        items.map { MediaSortKey(it.id, it.title, it.artist, it.durationMs) },
        order,
        descending
    ).mapNotNull { byId[it.id] }
}
