package com.chiyuri.player

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

internal data class TrackPalette(
    val primary: Color,
    val secondary: Color,
    val background: Color,
    val surface: Color
) {
    companion object {
        val Default = TrackPalette(
            primary = Color(0xFFB7A0FF),
            secondary = Color(0xFF82D8C8),
            background = Color(0xFF101116),
            surface = Color(0xFF1C1E27)
        )
    }
}

internal object TrackPaletteStore {
    private const val PREFS = "track_palette"
    fun load(context: android.content.Context): TrackPalette {
        val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        return TrackPalette(
            primary = Color(prefs.getInt("primary", TrackPalette.Default.primary.toArgb())),
            secondary = Color(prefs.getInt("secondary", TrackPalette.Default.secondary.toArgb())),
            background = Color(prefs.getInt("background", TrackPalette.Default.background.toArgb())),
            surface = Color(prefs.getInt("surface", TrackPalette.Default.surface.toArgb()))
        )
    }
    fun save(context: android.content.Context, palette: TrackPalette) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit()
            .putInt("primary", palette.primary.toArgb())
            .putInt("secondary", palette.secondary.toArgb())
            .putInt("background", palette.background.toArgb())
            .putInt("surface", palette.surface.toArgb())
            .apply()
    }
    fun reset(context: android.content.Context) = save(context, TrackPalette.Default)
}

@Composable
internal fun TrackArtworkBackdrop(player: Player, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var currentItem by remember(player) { mutableStateOf(player.currentMediaItem) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentItem = mediaItem
            }
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                currentItem = player.currentMediaItem
            }
            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                currentItem = player.currentMediaItem
            }
        }
        player.addListener(listener)
        currentItem = player.currentMediaItem
        onDispose { player.removeListener(listener) }
    }

    val uri = currentItem?.localConfiguration?.uri
    val metadata = currentItem?.mediaMetadata
    val artworkUri = metadata?.artworkUri
    val artworkData = metadata?.artworkData
    var bitmap by remember(uri, artworkUri, artworkData?.contentHashCode()) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(uri, artworkUri, artworkData?.contentHashCode(), currentItem?.mediaId) {
        bitmap = null
        val bytes = withContext(Dispatchers.IO) {
            val embedded = artworkData ?: uri?.let { TrackMetadataRepository.loadEmbeddedArtwork(context, it) }
            if (embedded != null) return@withContext embedded

            val savedArtworkUrl = uri?.let { TrackMetadataRepository.loadOverride(context, it)?.artworkUrl }
            val remoteUrl = savedArtworkUrl?.takeIf { it.startsWith("https://") }
                ?: artworkUri?.toString()?.takeIf { it.startsWith("https://") }
            remoteUrl?.let { url ->
                runCatching {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.connectTimeout = 7000
                    connection.readTimeout = 10000
                    connection.instanceFollowRedirects = true
                    try {
                        if (connection.responseCode in 200..299) {
                            connection.inputStream.use { input ->
                                val output = java.io.ByteArrayOutputStream()
                                val buffer = ByteArray(8192)
                                var total = 0
                                while (total < 12 * 1024 * 1024) {
                                    val count = input.read(buffer, 0, minOf(buffer.size, 12 * 1024 * 1024 - total))
                                    if (count <= 0) break
                                    output.write(buffer, 0, count)
                                    total += count
                                }
                                output.toByteArray()
                            }
                        } else null
                    } finally {
                        connection.disconnect()
                    }
                }.getOrNull()
            }
        }
        bitmap = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        TrackPaletteStore.save(context, bitmap?.let(::extractTrackPalette) ?: TrackPalette.Default)
    }

    val image = bitmap
    Box(modifier.fillMaxSize().background(androidx.compose.material3.MaterialTheme.colorScheme.background)) {
        if (image != null) {
            Image(
                bitmap = image.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(38.dp).alpha(0.42f)
            )
        }
        val colors = androidx.compose.material3.MaterialTheme.colorScheme
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        colors.background.copy(alpha = 0.62f),
                        colors.surface.copy(alpha = 0.76f),
                        colors.background.copy(alpha = 0.90f)
                    )
                )
            )
        )
    }
}

private fun extractTrackPalette(source: Bitmap): TrackPalette {
    val sample = Bitmap.createScaledBitmap(source, 40, 40, true)
    val hueWeights = FloatArray(24)
    val hueRed = FloatArray(24)
    val hueGreen = FloatArray(24)
    val hueBlue = FloatArray(24)
    val hueCount = IntArray(24)

    for (y in 0 until sample.height) {
        for (x in 0 until sample.width) {
            val pixel = sample.getPixel(x, y)
            val r = android.graphics.Color.red(pixel)
            val g = android.graphics.Color.green(pixel)
            val b = android.graphics.Color.blue(pixel)
            val hsv = FloatArray(3)
            android.graphics.Color.RGBToHSV(r, g, b, hsv)
            if (hsv[2] < 0.12f || hsv[2] > 0.96f || hsv[1] < 0.18f) continue
            val bucket = ((hsv[0] / 360f) * hueWeights.size).toInt().coerceIn(0, hueWeights.lastIndex)
            val weight = hsv[1] * (0.35f + hsv[2] * 0.65f)
            hueWeights[bucket] += weight
            hueRed[bucket] += r * weight
            hueGreen[bucket] += g * weight
            hueBlue[bucket] += b * weight
            hueCount[bucket]++
        }
    }
    if (sample !== source) sample.recycle()
    val dominant = hueWeights.indices.maxByOrNull { hueWeights[it] } ?: return TrackPalette.Default
    if (hueWeights[dominant] <= 0f || hueCount[dominant] == 0) return TrackPalette.Default

    val base = FloatArray(3)
    android.graphics.Color.RGBToHSV(
        (hueRed[dominant] / hueWeights[dominant]).toInt(),
        (hueGreen[dominant] / hueWeights[dominant]).toInt(),
        (hueBlue[dominant] / hueWeights[dominant]).toInt(),
        base
    )
    val primaryHsv = base.clone()
    primaryHsv[1] = max(0.52f, min(0.88f, primaryHsv[1] * 1.35f))
    primaryHsv[2] = 0.94f
    val secondaryHsv = primaryHsv.clone()
    secondaryHsv[0] = (secondaryHsv[0] + 34f) % 360f
    secondaryHsv[1] = (secondaryHsv[1] * 0.78f).coerceIn(0.35f, 0.75f)

    val backgroundHsv = primaryHsv.clone().apply { this[1] = 0.34f; this[2] = 0.075f }
    val surfaceHsv = primaryHsv.clone().apply { this[1] = 0.28f; this[2] = 0.14f }
    return TrackPalette(
        primary = Color(android.graphics.Color.HSVToColor(primaryHsv)),
        secondary = Color(android.graphics.Color.HSVToColor(secondaryHsv)),
        background = Color(android.graphics.Color.HSVToColor(backgroundHsv)),
        surface = Color(android.graphics.Color.HSVToColor(surfaceHsv))
    )
}
