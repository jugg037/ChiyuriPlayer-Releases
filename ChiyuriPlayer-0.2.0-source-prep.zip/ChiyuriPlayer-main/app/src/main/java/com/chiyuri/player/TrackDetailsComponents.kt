package com.chiyuri.player

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

@Composable
internal fun TrackArtwork(uri: Uri?, artworkUrl: String?, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(uri, artworkUrl) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri, artworkUrl) {
        bitmap = withContext(Dispatchers.IO) {
            val embedded = uri?.let { TrackMetadataRepository.loadEmbeddedArtwork(context, it) }
            val bytes = embedded ?: if (artworkUrl?.startsWith("https://") == true) {
                runCatching { URL(artworkUrl).openStream().use { it.readBytes() } }.getOrNull()
            } else null
            bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        }
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Обложка альбома",
                modifier = Modifier.size(112.dp),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(
                Icons.Default.Album,
                contentDescription = "Обложка отсутствует",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(30.dp).size(52.dp)
            )
        }
    }
}

@Composable
internal fun TrackLyricsPreview(player: Player) {
    val context = LocalContext.current
    val item = player.currentMediaItem
    val uri = item?.localConfiguration?.uri
    val title = item?.mediaMetadata?.title?.toString().orEmpty()
    val artist = item?.mediaMetadata?.artist?.toString().orEmpty()
    var lyrics by remember(uri) { mutableStateOf<TrackMetadata?>(uri?.let { TrackMetadataRepository.loadOverride(context, it) }) }
    LaunchedEffect(uri) {
        if (uri != null && lyrics?.plainLyrics.isNullOrBlank() && lyrics?.syncedLyrics.isNullOrBlank()) {
            val embedded = withContext(Dispatchers.IO) { TrackMetadataRepository.readEmbeddedLyrics(context, uri) }
            if (!embedded.isNullOrBlank()) {
                val base = lyrics ?: TrackMetadata(title = title, artist = artist)
                lyrics = base.copy(plainLyrics = embedded)
            }
        }
    }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Текст песни", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
        val text = lyrics?.syncedLyrics?.takeIf { it.isNotBlank() }
            ?: lyrics?.plainLyrics?.takeIf { it.isNotBlank() }
        if (!text.isNullOrBlank()) {
            Text(
                text = text,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 7
            )
        } else {
            Text("Текст ещё не добавлен.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        TextButton(
            enabled = !loading && title.isNotBlank(),
            onClick = {
                scope.launch {
                    loading = true
                    val found = LyricsRepository.search(artist, title, player.duration)
                    if (found != null && uri != null) {
                        val base = lyrics ?: TrackMetadata(title = title, artist = artist)
                        val updated = base.copy(
                            plainLyrics = found.plainLyrics.orEmpty(),
                            syncedLyrics = found.syncedLyrics.orEmpty()
                        )
                        TrackMetadataRepository.saveOverride(context, uri, updated)
                        lyrics = updated
                    }
                    loading = false
                }
            }
        ) {
            if (loading) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            else Text("Найти текст песни")
        }
    }
}

@Composable
internal fun TrackMetadataEditorDialog(
    player: Player,
    onDismiss: () -> Unit,
    onApply: (TrackMetadata) -> Unit
) {
    val context = LocalContext.current
    val uri = player.currentMediaItem?.localConfiguration?.uri
    val initial = remember(uri) {
        uri?.let { TrackMetadataRepository.loadOverride(context, it) } ?: TrackMetadata(
            title = player.currentMediaItem?.mediaMetadata?.title?.toString().orEmpty(),
            artist = player.currentMediaItem?.mediaMetadata?.artist?.toString().orEmpty(),
            album = player.currentMediaItem?.mediaMetadata?.albumTitle?.toString().orEmpty()
        )
    }
    var title by remember(uri) { mutableStateOf(initial.title) }
    var artist by remember(uri) { mutableStateOf(initial.artist) }
    var album by remember(uri) { mutableStateOf(initial.album) }
    var year by remember(uri) { mutableStateOf(initial.year) }
    var artworkUrl by remember(uri) { mutableStateOf(initial.artworkUrl) }
    var plainLyrics by remember(uri) { mutableStateOf(initial.plainLyrics) }
    var syncedLyrics by remember(uri) { mutableStateOf(initial.syncedLyrics) }
    var loading by remember { mutableStateOf(false) }
    var writingToFile by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Музыкальная информация") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Найди сведения в интернете, затем проверь и отредактируй их перед сохранением.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(artist, { artist = it }, label = { Text("Исполнитель") }, singleLine = true)
                OutlinedTextField(album, { album = it }, label = { Text("Альбом") }, singleLine = true)
                OutlinedTextField(year, { year = it }, label = { Text("Год") }, singleLine = true)
                OutlinedTextField(artworkUrl, { artworkUrl = it }, label = { Text("Ссылка на обложку") }, singleLine = true)
                OutlinedTextField(plainLyrics, { plainLyrics = it }, label = { Text("Текст песни") }, minLines = 3)
                OutlinedTextField(syncedLyrics, { syncedLyrics = it }, label = { Text("Синхронизированный текст (LRC)") }, minLines = 3)
                OutlinedButton(
                    enabled = uri != null && !loading && !writingToFile && title.isNotBlank(),
                    onClick = {
                        val edited = TrackMetadata(
                            title.trim(), artist.trim(), album.trim(), year.trim(),
                            artworkUrl.trim(), plainLyrics, syncedLyrics
                        )
                        scope.launch {
                            writingToFile = true
                            message = "Записываем метаданные в исходный файл…"
                            val error = TrackMetadataRepository.writeMetadataToFile(context, uri!!, edited)
                            writingToFile = false
                            if (error == null) {
                                Toast.makeText(context, "Метаданные записаны в файл", Toast.LENGTH_LONG).show()
                                onApply(edited)
                            } else {
                                message = error
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (writingToFile) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("Записать теги в файл")
                }
                message?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
                Button(
                    enabled = !loading && title.isNotBlank(),
                    onClick = {
                        scope.launch {
                            loading = true
                            message = "Ищем название, исполнителя, альбом и обложку…"
                            val found = TrackMetadataRepository.search(title, artist)
                            if (found != null) {
                                title = found.title
                                artist = found.artist
                                album = found.album
                                year = found.year
                                artworkUrl = found.artworkUrl
                                val foundLyrics = LyricsRepository.search(found.artist, found.title, player.duration)
                                plainLyrics = foundLyrics?.plainLyrics.orEmpty()
                                syncedLyrics = foundLyrics?.syncedLyrics.orEmpty()
                                message = "Результат найден. Проверь поля и нажми «Сохранить»."
                            } else {
                                message = "Ничего не найдено. Измени запрос или заполни сведения вручную."
                            }
                            loading = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (loading) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("Найти информацию и текст")
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    onApply(TrackMetadata(title.trim(), artist.trim(), album.trim(), year.trim(), artworkUrl.trim(), plainLyrics, syncedLyrics))
                }
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
