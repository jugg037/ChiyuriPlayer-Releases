package com.chiyuri.player

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

@Composable
internal fun NetworkStreamCard(player: Player) {
    var address by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Сетевое воспроизведение", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
            Text(
                "Открой прямую ссылку на аудио, видео, интернет-радио или HLS-поток (.m3u8).",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = address,
                onValueChange = {
                    address = it
                    error = null
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("URL потока") },
                placeholder = { Text("https://example.com/stream.m3u8") }
            )
            Button(
                onClick = {
                    val uri = runCatching { Uri.parse(address.trim()) }.getOrNull()
                    if (uri == null || uri.host.isNullOrBlank() || uri.scheme != "https") {
                        error = "Для сетевого воспроизведения нужна корректная HTTPS-ссылка."
                    } else {
                        runCatching {
                            player.setMediaItem(MediaItem.fromUri(uri))
                            player.prepare()
                            player.play()
                            error = null
                        }.onFailure {
                            error = "Не удалось открыть поток: ${it.localizedMessage ?: "неизвестная ошибка"}"
                        }
                    }
                },
                enabled = address.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Воспроизвести ссылку")
            }
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
