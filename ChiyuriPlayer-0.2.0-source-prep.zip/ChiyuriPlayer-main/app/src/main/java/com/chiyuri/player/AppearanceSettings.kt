package com.chiyuri.player

import android.content.Context
import android.content.SharedPreferences

enum class AppThemeMode(val storageValue: String, val label: String) {
    SYSTEM("system", "Как в системе"),
    DARK("dark", "Тёмная"),
    LIGHT("light", "Светлая");

    companion object {
        fun fromStorage(value: String?): AppThemeMode =
            entries.firstOrNull { it.storageValue == value } ?: SYSTEM
    }
}

data class AppearanceConfig(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val dynamicColors: Boolean = true
)

object AppearanceSettings {
    private const val PREFS = "appearance_settings"
    private const val KEY_THEME_MODE = "theme_mode"
    private const val KEY_DYNAMIC_COLORS = "dynamic_colors"

    fun load(context: Context): AppearanceConfig = load(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    )

    internal fun load(preferences: SharedPreferences): AppearanceConfig =
        AppearanceConfig(
            themeMode = AppThemeMode.fromStorage(preferences.getString(KEY_THEME_MODE, "system")),
            dynamicColors = preferences.getBoolean(KEY_DYNAMIC_COLORS, true)
        )

    fun save(context: Context, config: AppearanceConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_THEME_MODE, config.themeMode.storageValue)
            .putBoolean(KEY_DYNAMIC_COLORS, config.dynamicColors)
            .apply()
    }
}
