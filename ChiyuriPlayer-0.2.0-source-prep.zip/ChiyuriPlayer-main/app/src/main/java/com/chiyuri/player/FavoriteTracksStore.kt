package com.chiyuri.player

import android.content.Context
import android.net.Uri

internal object FavoriteTracksStore {
    private const val PREFS = "favorite_tracks"
    private const val KEY_URIS = "uris"

    fun load(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_URIS, emptySet())
            ?.toSet()
            .orEmpty()

    fun toggle(context: Context, uri: Uri): Set<String> {
        val updated = load(context).toMutableSet()
        val key = uri.toString()
        if (!updated.add(key)) updated.remove(key)
        val snapshot = updated.toSet()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_URIS, snapshot)
            .apply()
        return snapshot
    }

    fun contains(context: Context, uri: Uri): Boolean = uri.toString() in load(context)
}
