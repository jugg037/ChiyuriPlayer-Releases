package com.chiyuri.player

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Conservative FLAC metadata writer. Audio frames are copied byte-for-byte.
 * STREAMINFO and unknown metadata blocks are retained; only Vorbis comments
 * and (when supplied) the front-cover picture block are replaced.
 */
internal object FlacMetadataWriter {
    private const val MAX_METADATA_SIZE = 64 * 1024 * 1024
    private const val VENDOR = "ChiyuriPlayer"

    private data class Block(val type: Int, val data: ByteArray)

    fun rewrite(source: File, destination: File, metadata: TrackMetadata, artwork: ByteArray? = null) {
        require(source.isFile && source.canRead()) { "Исходный FLAC-файл недоступен для чтения." }
        require(source.canonicalFile != destination.canonicalFile) { "Для безопасной записи нужен отдельный временный файл." }
        require(source.length() >= 42L) { "Файл слишком короткий и не похож на FLAC." }

        RandomAccessFile(source, "r").use { input ->
            val signature = ByteArray(4)
            input.readFully(signature)
            require(signature.contentEquals(byteArrayOf(0x66, 0x4c, 0x61, 0x43))) {
                "Файл не начинается с сигнатуры FLAC. Файлы с внешним ID3-заголовком пока не поддерживаются."
            }

            val blocks = mutableListOf<Block>()
            var metadataBytes = 0L
            var last = false
            while (!last) {
                require(input.filePointer + 4 <= input.length()) { "Повреждён заголовок FLAC metadata block." }
                val header = input.readUnsignedByte()
                last = (header and 0x80) != 0
                val type = header and 0x7f
                val length = (input.readUnsignedByte() shl 16) or
                    (input.readUnsignedByte() shl 8) or input.readUnsignedByte()
                require(type != 127) { "FLAC содержит зарезервированный тип metadata block." }
                require(length >= 0 && input.filePointer + length <= input.length()) {
                    "Повреждён FLAC metadata block."
                }
                metadataBytes += length + 4L
                require(metadataBytes <= MAX_METADATA_SIZE) { "FLAC metadata превышает безопасный лимит 64 МБ." }
                val data = ByteArray(length)
                input.readFully(data)
                blocks += Block(type, data)
                require(blocks.size <= 1024) { "Слишком много FLAC metadata blocks." }
            }

            require(blocks.isNotEmpty() && blocks.first().type == 0 && blocks.first().data.size == 34) {
                "FLAC не содержит корректный обязательный STREAMINFO block."
            }
            require(blocks.count { it.type == 0 } == 1) { "FLAC содержит несколько STREAMINFO blocks." }

            val oldComments = blocks.filter { it.type == 4 }.flatMap { decodeComments(it.data) }
            val preserved = oldComments.filterNot { it.substringBefore('=').uppercase() in REPLACED_KEYS }
            val updated = preserved.toMutableList()
            addComment(updated, "TITLE", metadata.title)
            addComment(updated, "ARTIST", metadata.artist)
            addComment(updated, "ALBUM", metadata.album)
            addComment(updated, "DATE", metadata.year)
            addComment(updated, "LYRICS", metadata.plainLyrics)
            addComment(updated, "LYRICS_SYNCED", metadata.syncedLyrics)

            val outputBlocks = mutableListOf<Block>()
            outputBlocks += blocks.first()
            outputBlocks += blocks.drop(1).filterNot { it.type == 4 || (artwork != null && it.type == 6) }
            outputBlocks += Block(4, encodeComments(updated))
            if (artwork != null) outputBlocks += Block(6, encodePicture(artwork))
            require(outputBlocks.sumOf { it.data.size.toLong() + 4L } <= MAX_METADATA_SIZE) {
                "Итоговый FLAC metadata превышает безопасный лимит 64 МБ."
            }

            destination.parentFile?.mkdirs()
            RandomAccessFile(destination, "rw").use { output ->
                output.setLength(0)
                output.write(signature)
                outputBlocks.forEachIndexed { index, block ->
                    val isLast = index == outputBlocks.lastIndex
                    require(block.data.size <= 0x00ffffff) { "Слишком большой FLAC metadata block." }
                    output.write(block.type or (if (isLast) 0x80 else 0))
                    output.write((block.data.size ushr 16) and 0xff)
                    output.write((block.data.size ushr 8) and 0xff)
                    output.write(block.data.size and 0xff)
                    output.write(block.data)
                }
                val audioStart = input.filePointer
                input.seek(audioStart)
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }
    }

    private fun decodeComments(data: ByteArray): List<String> {
        require(data.size >= 8) { "Повреждён Vorbis Comment block." }
        val buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val vendorLength = readLength(buffer)
        require(vendorLength <= buffer.remaining()) { "Повреждён vendor string Vorbis Comment." }
        buffer.position(buffer.position() + vendorLength)
        require(buffer.remaining() >= 4) { "Повреждён список Vorbis comments." }
        val count = buffer.int
        require(count in 0..100_000) { "Недопустимое количество Vorbis comments." }
        val result = ArrayList<String>(count)
        repeat(count) {
            val length = readLength(buffer)
            require(length <= buffer.remaining()) { "Повреждена запись Vorbis Comment." }
            val bytes = ByteArray(length)
            buffer.get(bytes)
            val value = String(bytes, Charsets.UTF_8)
            require(value.contains('=')) { "Некорректная запись Vorbis Comment." }
            result += value
        }
        require(!buffer.hasRemaining()) { "Vorbis Comment содержит лишние или повреждённые данные." }
        return result
    }

    private fun encodeComments(comments: List<String>): ByteArray {
        val vendor = VENDOR.toByteArray(Charsets.UTF_8)
        val output = java.io.ByteArrayOutputStream()
        writeLeInt(output, vendor.size)
        output.write(vendor)
        writeLeInt(output, comments.size)
        comments.forEach { comment ->
            val bytes = comment.toByteArray(Charsets.UTF_8)
            writeLeInt(output, bytes.size)
            output.write(bytes)
        }
        return output.toByteArray()
    }

    private fun encodePicture(bytes: ByteArray): ByteArray {
        val mime = when {
            bytes.size >= 8 && bytes.copyOfRange(0, 8).contentEquals(
                byteArrayOf(0x89.toByte(), 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)
            ) -> "image/png"
            bytes.size >= 3 && bytes[0] == 0xff.toByte() && bytes[1] == 0xd8.toByte() && bytes[2] == 0xff.toByte() ->
                "image/jpeg"
            else -> throw IllegalArgumentException("Обложка FLAC должна быть изображением JPEG или PNG.")
        }
        val mimeBytes = mime.toByteArray(Charsets.UTF_8)
        val description = "Cover".toByteArray(Charsets.UTF_8)
        val output = java.io.ByteArrayOutputStream()
        writeBeInt(output, 3) // Cover (front)
        writeBeInt(output, mimeBytes.size)
        output.write(mimeBytes)
        writeBeInt(output, description.size)
        output.write(description)
        repeat(4) { writeBeInt(output, 0) } // width, height, color depth, indexed colors
        writeBeInt(output, bytes.size)
        output.write(bytes)
        return output.toByteArray()
    }

    private fun addComment(target: MutableList<String>, key: String, value: String) {
        if (value.isNotBlank()) target += "$key=$value"
    }

    private fun readLength(buffer: ByteBuffer): Int {
        require(buffer.remaining() >= 4) { "Повреждён размер Vorbis Comment." }
        val value = buffer.int
        require(value >= 0) { "Недопустимый размер Vorbis Comment." }
        return value
    }

    private fun writeLeInt(output: java.io.ByteArrayOutputStream, value: Int) {
        output.write(value and 0xff)
        output.write((value ushr 8) and 0xff)
        output.write((value ushr 16) and 0xff)
        output.write((value ushr 24) and 0xff)
    }

    private fun writeBeInt(output: java.io.ByteArrayOutputStream, value: Int) {
        output.write((value ushr 24) and 0xff)
        output.write((value ushr 16) and 0xff)
        output.write((value ushr 8) and 0xff)
        output.write(value and 0xff)
    }

    private val REPLACED_KEYS = setOf("TITLE", "ARTIST", "ALBUM", "DATE", "YEAR", "LYRICS", "UNSYNCEDLYRICS", "LYRICS_SYNCED")
}
