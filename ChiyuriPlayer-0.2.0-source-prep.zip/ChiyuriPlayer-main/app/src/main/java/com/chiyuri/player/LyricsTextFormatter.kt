package com.chiyuri.player

object LyricsTextFormatter {
    fun format(source: String): String {
        val normalized = source
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.isNotEmpty() }
        if (normalized.isEmpty()) return ""

        val lines = if (normalized.size > 1) {
            normalized.flatMap { line ->
                if (line.length > 150) splitLongLine(line) else listOf(line)
            }
        } else {
            val single = normalized.first()
            val sentences = single.split(Regex("(?<=[.!?…])\\s+")).filter { it.isNotBlank() }
            if (sentences.size > 1) sentences.flatMap(::splitLongLine) else splitLongLine(single)
        }

        return buildString {
            lines.forEachIndexed { index, line ->
                if (index > 0) {
                    if (index % 4 == 0) append("\n\n") else append('\n')
                }
                append(line)
            }
        }.trim()
    }

    private fun splitLongLine(line: String): List<String> {
        if (line.length <= 110) return listOf(line)
        val sentences = line.split(Regex("(?<=[,;.!?…])\\s+")).filter { it.isNotBlank() }
        if (sentences.size > 1 && sentences.any { it.length <= 110 }) {
            return sentences.flatMap { part ->
                if (part.length <= 110) listOf(part) else splitWords(part)
            }
        }
        return splitWords(line)
    }

    private fun splitWords(line: String): List<String> {
        val words = line.split(Regex("\\s+")).filter { it.isNotBlank() }
        return words.chunked(9).map { it.joinToString(" ") }
    }
}
