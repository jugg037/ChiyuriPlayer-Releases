package com.chiyuri.player

data class EqualizerPreset(
    val id: String,
    val title: String,
    val bandsDb: List<Float>
) {
    init {
        require(bandsDb.size == 5)
    }
}

object EqualizerPresets {
    val all = listOf(
        EqualizerPreset("flat", "Ровный", listOf(0f, 0f, 0f, 0f, 0f)),
        EqualizerPreset("bass", "Басы", listOf(8f, 5f, 0f, -1f, 0f)),
        EqualizerPreset("pop", "Поп", listOf(-1f, 2f, 5f, 3f, -1f)),
        EqualizerPreset("rock", "Рок", listOf(5f, 3f, -1f, 4f, 6f)),
        EqualizerPreset("classical", "Классика", listOf(4f, 2f, -1f, 3f, 5f)),
        EqualizerPreset("jazz", "Джаз", listOf(4f, 2f, -2f, 2f, 4f)),
        EqualizerPreset("vocal", "Вокал", listOf(-3f, 0f, 5f, 4f, 1f))
    )

    fun apply(config: AudioEffectsConfig, preset: EqualizerPreset): AudioEffectsConfig =
        normalizeAudioEffectsConfig(config.copy(equalizerEnabled = true, bandsDb = preset.bandsDb))

    fun selectedPreset(config: AudioEffectsConfig): String? =
        all.firstOrNull { preset ->
            preset.bandsDb.indices.all { index ->
                kotlin.math.abs(config.bandsDb.getOrElse(index) { 0f } - preset.bandsDb[index]) < 0.05f
            }
        }?.id
}
