package com.chiyuri.player

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.Player
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Applies Android's session-based audio effects to the ExoPlayer audio session.
 * Effects are optional because some device audio drivers do not expose them.
 */
class AudioEffectsController(
    context: Context,
    private val player: ExoPlayer
) : SharedPreferences.OnSharedPreferenceChangeListener {

    private val preferences = context.getSharedPreferences(
        AudioEffectsSettings.PREFERENCES_NAME,
        Context.MODE_PRIVATE
    )

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var attachedSessionId: Int = 0

    private val audioListener = object : Player.Listener {
        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            attachToSession(audioSessionId)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            attachToSession(player.audioSessionId)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) attachToSession(player.audioSessionId)
        }
    }

    init {
        preferences.registerOnSharedPreferenceChangeListener(this)
        player.addListener(audioListener)
        attachToSession(player.audioSessionId)
        applySettings()
    }

    override fun onSharedPreferenceChanged(
        sharedPreferences: SharedPreferences?,
        key: String?
    ) {
        applySettings()
    }

    private fun attachToSession(audioSessionId: Int) {
        if (audioSessionId <= 0 || audioSessionId == attachedSessionId) return
        releaseEffects()
        attachedSessionId = audioSessionId

        equalizer = runCatching { Equalizer(0, audioSessionId) }.getOrNull()
        bassBoost = runCatching { BassBoost(0, audioSessionId) }.getOrNull()
        loudnessEnhancer = runCatching { LoudnessEnhancer(audioSessionId) }.getOrNull()
        applySettings()
    }

    private fun applySettings() {
        val config = AudioEffectsSettings.load(preferences)
        // The base level is controlled by Android's STREAM_MUSIC volume.
        player.volume = 1f
        loudnessEnhancer?.let { effect ->
            runCatching {
                val extraGainMb = if (config.playerVolume > 1f) {
                    (2000f * kotlin.math.log10(config.playerVolume)).roundToInt().coerceIn(0, 602)
                } else {
                    0
                }
                effect.setTargetGain(extraGainMb)
                effect.enabled = extraGainMb > 0
            }
        }

        equalizer?.let { effect ->
            runCatching {
                val bandCount = effect.numberOfBands.toInt().coerceAtLeast(0)
                val range = effect.bandLevelRange
                if (range.size >= 2) {
                    for (band in 0 until bandCount) {
                        val centerHz = effect.getCenterFreq(band.toShort())
                            .toFloat()
                            .div(1000f)
                            .coerceAtLeast(1f)
                        val controlIndex = CONTROL_CENTERS_HZ.indices.minByOrNull { index ->
                            abs(ln(centerHz / CONTROL_CENTERS_HZ[index]))
                        } ?: 2
                        val level = (config.bandsDb[controlIndex] * 100f)
                            .roundToInt()
                            .coerceIn(range[0].toInt(), range[1].toInt())
                            .toShort()
                        effect.setBandLevel(band.toShort(), level)
                    }
                }
                effect.enabled = config.equalizerEnabled
            }
        }

        bassBoost?.let { effect ->
            runCatching {
                effect.setStrength(config.bassBoostStrength.roundToInt().coerceIn(0, 1000).toShort())
                effect.enabled = config.bassBoostStrength > 0f
            }
        }
    }

    private fun releaseEffects() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        loudnessEnhancer = null
    }

    fun release() {
        preferences.unregisterOnSharedPreferenceChangeListener(this)
        player.removeListener(audioListener)
        releaseEffects()
        attachedSessionId = 0
    }

    private companion object {
        val CONTROL_CENTERS_HZ = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
    }
}
