package com.chiyuri.player

data class M3uEntry(
    val location: String,
    val title: String,
    val durationSeconds: Long?
)

/**
 * Small UTF-8 M3U/M3U8 codec. Locations are kept verbatim so callers can
 * explicitly decide whether Android can access a content URI or remote URL.
 */
object M3uPlaylistCodec {
    fun parse(content: String): List<M3uEntry> {
        val entries = mutableListOf<M3uEntry>()
        var pendingTitle: String? = null
        var pendingDuration: Long? = null

        content.removePrefix("\uFEFF").lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            if (line.isEmpty()) return@forEach

            when {
                line.startsWith("#EXTINF:", ignoreCase = true) -> {
                    val metadata = line.substringAfter(':', "")
                    val comma = metadata.indexOf(',')
                    if (comma >= 0) {
                        pendingDuration = metadata.substring(0, comma)
                            .trim()
                            .toLongOrNull()
                            ?.takeIf { it >= 0L }
                        pendingTitle = metadata.substring(comma + 1)
                            .trim()
                            .takeIf { it.isNotEmpty() }
                    } else {
                        pendingDuration = null
                        pendingTitle = null
                    }
                }
                line.startsWith("#") -> Unit
                else -> {
                    val fallbackTitle = line.substringAfterLast('/')
                        .substringAfterLast('\\')
                        .ifBlank { "Медиафайл" }
                    entries += M3uEntry(
                        location = line,
                        title = pendingTitle ?: fallbackTitle,
                        durationSeconds = pendingDuration
                    )
                    pendingTitle = null
                    pendingDuration = null
                }
            }
        }
        return entries
    }

    fun format(entries: List<M3uEntry>): String = buildString {
        append("#EXTM3U\n")
        entries.forEach { entry ->
            val location = entry.location.trim()
            if (location.isEmpty() || location.contains('\n') || location.contains('\r')) {
                return@forEach
            }
            val title = entry.title
                .replace('\n', ' ')
                .replace('\r', ' ')
                .ifBlank { "Медиафайл" }
            val duration = entry.durationSeconds?.takeIf { it >= 0L } ?: -1L
            append("#EXTINF:")
                .append(duration)
                .append(',')
                .append(title)
                .append('\n')
                .append(location)
                .append('\n')
        }
    }
}
