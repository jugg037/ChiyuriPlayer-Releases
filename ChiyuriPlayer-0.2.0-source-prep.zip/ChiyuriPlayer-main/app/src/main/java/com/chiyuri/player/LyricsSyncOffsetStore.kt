package com.chiyuri.player

import android.content.Context
import android.net.Uri

object LyricsSyncOffsetStore {
    const val MIN_OFFSET_MS = -10_000
    const val MAX_OFFSET_MS = 10_000

    private const val PREFERENCES = "lyrics_sync_offsets"
    private const val KEY_PREFIX = "uri:"

    fun normalize(offsetMs: Long): Int = offsetMs.coerceIn(
        MIN_OFFSET_MS.toLong(),
        MAX_OFFSET_MS.toLong()
    ).toInt()

    fun load(context: Context, uri: Uri?): Int {
        if (uri == null) return 0
        return normalize(
            context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                .getInt(KEY_PREFIX + uri.toString(), 0).toLong()
        )
    }

    fun save(context: Context, uri: Uri?, offsetMs: Long) {
        if (uri == null) return
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PREFIX + uri.toString(), normalize(offsetMs))
            .apply()
    }
}
