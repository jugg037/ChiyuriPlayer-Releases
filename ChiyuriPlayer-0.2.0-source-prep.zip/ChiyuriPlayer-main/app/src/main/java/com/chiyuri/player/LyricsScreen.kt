package com.chiyuri.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun LyricsScreen(player: Player, modifier: Modifier = Modifier) {
    val currentItem = player.currentMediaItem
    val context = androidx.compose.ui.platform.LocalContext.current
    val currentUri = currentItem?.localConfiguration?.uri
    val detectedTitle = currentItem?.mediaMetadata?.title?.toString()
        ?.takeIf { it.isNotBlank() }
        ?: currentUri?.let { TrackMetadataRepository.displayName(context, it) }
        ?: ""
    val detectedArtist = currentItem?.mediaMetadata?.artist?.toString().orEmpty()
    var title by remember { mutableStateOf(detectedTitle) }
    var artist by remember { mutableStateOf(detectedArtist) }
    var lyrics by remember(currentUri) { mutableStateOf<LyricsResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var syncOffsetMs by remember(currentUri) {
        mutableLongStateOf(LyricsSyncOffsetStore.load(context, currentUri).toLong())
    }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(detectedTitle, detectedArtist, player.currentMediaItemIndex, currentUri) {
        title = detectedTitle
        artist = detectedArtist
        lyrics = null
        message = null
        val saved = currentUri?.let { uri ->
            withContext(Dispatchers.IO) { TrackMetadataRepository.loadOverride(context, uri) }
        }
        if (saved != null && (saved.plainLyrics.isNotBlank() || saved.syncedLyrics.isNotBlank())) {
            lyrics = LyricsResult(
                saved.plainLyrics.takeIf { it.isNotBlank() },
                saved.syncedLyrics.takeIf { it.isNotBlank() }
            )
            message = "Загружен сохранённый текст. Он доступен без интернета."
        } else if (currentUri != null) {
            val embedded = withContext(Dispatchers.IO) {
                TrackMetadataRepository.readEmbeddedLyricsResult(context, currentUri)
            }
            if (embedded != null) {
                lyrics = LyricsResult(
                    embedded.plainLyrics?.let(LyricsTextFormatter::format),
                    embedded.syncedLyrics
                )
                message = "Текст автоматически загружен из тегов аудиофайла."
            }
        }
    }
    LaunchedEffect(player) {
        while (true) {
            positionMs = player.currentPosition.coerceAtLeast(0L)
            delay(250L)
        }
    }

    val timedLines = remember(lyrics) { lyrics?.syncedLyrics?.let(::parseLrcLyrics).orEmpty() }
    val plainLines = remember(lyrics) {
        if (timedLines.isEmpty()) lyrics?.plainLyrics?.lines().orEmpty() else emptyList()
    }
    val activeLine = timedLines.indexOfLast { it.timeMs + syncOffsetMs <= positionMs }
    LaunchedEffect(activeLine) {
        if (activeLine >= 0 && timedLines.isNotEmpty()) {
            listState.animateScrollToItem(activeLine.coerceAtMost(timedLines.lastIndex))
        }
    }

    fun saveLyrics(found: LyricsResult, sourceMessage: String) {
        val formatted = found.plainLyrics?.let(LyricsTextFormatter::format)
        lyrics = found.copy(plainLyrics = formatted)
        val uri = currentUri
        if (uri != null) {
            scope.launch {
                val base = withContext(Dispatchers.IO) { TrackMetadataRepository.readLocal(context, uri) }
                TrackMetadataRepository.saveOverride(
                    context,
                    uri,
                    base.copy(
                        plainLyrics = formatted.orEmpty(),
                        syncedLyrics = found.syncedLyrics.orEmpty()
                    )
                )
            }
        }
        message = sourceMessage
    }

    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Текст песни",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Название") }
        )
        OutlinedTextField(
            value = artist,
            onValueChange = { artist = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Исполнитель (необязательно)") }
        )
        Button(
            onClick = {
                scope.launch {
                    loading = true
                    message = null
                    try {
                        val found = LyricsRepository.search(artist, title, player.duration)
                        if (found != null) saveLyrics(found, "Текст найден. Результат сохранён для этой композиции.")
                        else message = "Текст не найден. Попробуй другое написание названия или исполнителя."
                    } catch (_: Exception) {
                        message = "Не удалось выполнить поиск. Проверь подключение к интернету и попробуй снова."
                    } finally {
                        loading = false
                    }
                }
            },
            enabled = !loading && title.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.height(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(Modifier.width(8.dp))
                Text("Ищем текст…")
            } else Text("Найти текст в интернете")
        }
        Button(
            onClick = {
                scope.launch {
                    loading = true
                    message = "Проверяем встроенный текст и онлайн-базу…"
                    try {
                        val embedded = withContext(Dispatchers.IO) {
                            currentUri?.let { TrackMetadataRepository.readEmbeddedLyricsResult(context, it) }
                        }
                        val hasEmbedded = !embedded?.plainLyrics.isNullOrBlank() ||
                            !embedded?.syncedLyrics.isNullOrBlank()
                        val found = if (hasEmbedded) {
                            LyricsResult(
                                embedded?.plainLyrics?.let(LyricsTextFormatter::format),
                                embedded?.syncedLyrics
                            )
                        } else {
                            LyricsRepository.search(artist, title, player.duration)
                        }
                        if (found != null) {
                            val note = if (hasEmbedded) {
                                "Текст извлечён из встроенных тегов аудиофайла и сохранён."
                            } else {
                                "Текст найден в онлайн-базе и сохранён."
                            }
                            saveLyrics(found, note)
                        } else {
                            message = "Во встроенных тегах и LRCLIB текст не найден. Попробуй изменить название или исполнителя."
                        }
                    } catch (_: Exception) {
                        message = "Не удалось прочитать файл или выполнить онлайн-поиск."
                    } finally {
                        loading = false
                    }
                }
            },
            enabled = !loading && title.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.height(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(Modifier.width(8.dp))
                Text("Проверяем…")
            } else Text("Найти и сохранить текст")
        }
        Text(
            "Поиск использует точное совпадение, альтернативные варианты названия и исполнителя, а затем расширенный запрос. Аудиофайл никуда не отправляется.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
        message?.let {
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        if (timedLines.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Синхронизация текста", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        String.format(java.util.Locale.ROOT, "%+d мс", syncOffsetMs),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = (syncOffsetMs / 1000f).coerceIn(-10f, 10f),
                    onValueChange = { value ->
                        syncOffsetMs = (value * 1000f).toLong()
                        LyricsSyncOffsetStore.save(context, currentUri, syncOffsetMs)
                    },
                    valueRange = -10f..10f,
                    steps = 199
                )
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().background(
                    MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(14.dp)
                ).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(timedLines) { index, line ->
                    Text(
                        line.text.ifBlank { "♪" },
                        color = if (index == activeLine) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = if (index == activeLine) MaterialTheme.typography.titleMedium
                        else MaterialTheme.typography.bodyLarge
                    )
                }
            }
        } else if (plainLines.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(
                    MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(14.dp)
                ).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(plainLines) { _, line ->
                    Text(line.ifBlank { " " }, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                }
            }
        } else if (!loading && message == null) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Запусти композицию или введи название и исполнителя, затем нажми «Найти текст». Синхронизированные тексты будут прокручиваться вместе с воспроизведением.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}
