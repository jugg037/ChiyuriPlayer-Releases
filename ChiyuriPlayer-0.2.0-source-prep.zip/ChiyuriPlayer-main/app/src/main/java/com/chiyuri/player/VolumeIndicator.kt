package com.chiyuri.player

import android.content.Context
import android.media.AudioManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
internal fun VolumeIndicator() {
    val context = LocalContext.current
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    val maxVolume = remember(audioManager) {
        audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    }
    var systemPercent by remember(audioManager) {
        mutableIntStateOf(
            (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / maxVolume)
                .roundToInt().coerceIn(0, 100)
        )
    }
    var boostPercent by remember(context) {
        mutableIntStateOf(
            ((AudioEffectsSettings.load(context).playerVolume - 1f) * 100f)
                .roundToInt().coerceIn(0, 100)
        )
    }

    DisposableEffect(context) {
        val preferences = context.getSharedPreferences(
            AudioEffectsSettings.PREFERENCES_NAME,
            Context.MODE_PRIVATE
        )
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            boostPercent = ((AudioEffectsSettings.load(context).playerVolume - 1f) * 100f)
                .roundToInt().coerceIn(0, 100)
        }
        preferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose { preferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    LaunchedEffect(audioManager) {
        while (true) {
            systemPercent = (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / maxVolume)
                .roundToInt().coerceIn(0, 100)
            delay(300L)
        }
    }

    androidx.compose.foundation.layout.Column(
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 2.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Система $systemPercent%", color = Color.LightGray, fontSize = 10.sp)
            Text("Усиление +$boostPercent%", color = Color(0xFFB7A0FF), fontSize = 10.sp)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
                modifier = Modifier.weight(1f).height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFF343641))
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth(systemPercent / 100f).fillMaxHeight()
                        .background(Color(0xFF82D8C8))
                )
            }
            Box(
                modifier = Modifier.weight(1f).height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFF343641))
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth(boostPercent / 100f).fillMaxHeight()
                        .background(Color(0xFFB7A0FF))
                )
            }
        }
    }
}
