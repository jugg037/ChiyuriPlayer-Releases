package com.chiyuri.player

import java.nio.ByteBuffer
import java.nio.ByteOrder

data class EmbeddedLyrics(
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null
)

/**
 * Bounded, read-only extraction of lyrics from common audio containers.
 * This parser never modifies the supplied media bytes.
 */
object EmbeddedLyricsReader {
    private const val MAX_TAG_BYTES = 16 * 1024 * 1024
    private val latin1 = Charsets.ISO_8859_1

    fun read(bytes: ByteArray): EmbeddedLyrics? {
        if (bytes.isEmpty()) return null
        val parsed = when {
            hasId3(bytes) -> readId3(bytes)
            startsWith(bytes, "fLaC") -> readFlac(bytes)
            else -> readMp4(bytes)
        }
        return parsed?.takeIf { !it.plainLyrics.isNullOrBlank() || !it.syncedLyrics.isNullOrBlank() }
    }

    private fun hasId3(bytes: ByteArray) =
        bytes.size >= 10 && bytes[0] == 0x49.toByte() && bytes[1] == 0x44.toByte() && bytes[2] == 0x33.toByte()

    private fun readId3(bytes: ByteArray): EmbeddedLyrics? {
        val version = bytes[3].toInt() and 0xff
        if (version !in 2..4) return null
        val tagSize = synchsafe(bytes, 6) ?: return null
        if (tagSize > MAX_TAG_BYTES || tagSize > bytes.size - 10) return null
        val end = 10 + tagSize
        var offset = 10
        val flags = bytes[5].toInt() and 0xff
        if ((flags and 0x40) != 0) {
            if (version == 2) return null
            if (offset + 4 > end) return null
            val extendedSize = if (version == 4) synchsafe(bytes, offset) else uint32(bytes, offset)
            if (extendedSize == null || extendedSize < 0 || extendedSize > end - offset) return null
            offset += if (version == 3) extendedSize + 4 else extendedSize
        }

        var plain: String? = null
        var synced: String? = null
        val frameHeader = if (version == 2) 6 else 10
        val idLength = if (version == 2) 3 else 4
        while (offset + frameHeader <= end) {
            val id = String(bytes, offset, idLength, latin1)
            if (id.all { it == '\u0000' }) break
            if (!id.all { it.isLetterOrDigit() }) break
            val size = when (version) {
                2 -> ((bytes[offset + 3].toInt() and 0xff) shl 16) or
                    ((bytes[offset + 4].toInt() and 0xff) shl 8) or (bytes[offset + 5].toInt() and 0xff)
                4 -> synchsafe(bytes, offset + 4) ?: break
                else -> uint32(bytes, offset + 4) ?: break
            }
            if (size <= 0 || size > end - offset - frameHeader) break
            val payloadStart = offset + frameHeader
            val payloadEnd = payloadStart + size
            val frameFlags = if (version == 2) 0 else
                ((bytes[offset + 8].toInt() and 0xff) shl 8) or (bytes[offset + 9].toInt() and 0xff)
            val unsupported = if (version == 4) (frameFlags and 0x000c) != 0
                else (frameFlags and 0x00c0) != 0
            if (!unsupported) {
                when (id) {
                    "USLT", "ULT" -> plain = plain ?: decodeUnsynced(bytes, payloadStart, payloadEnd)
                    "SYLT", "SLT" -> synced = synced ?: decodeSynced(bytes, payloadStart, payloadEnd)
                    "TXXX" -> {
                        val custom = decodeUserText(bytes, payloadStart, payloadEnd)
                        if (custom?.first.equals("LYRICS_SYNCED", true)) synced = custom?.second
                        if (custom?.first.equals("LYRICS", true) || custom?.first.equals("UNSYNCEDLYRICS", true)) {
                            plain = plain ?: custom?.second
                        }
                    }
                }
            }
            offset = payloadEnd
        }
        return EmbeddedLyrics(plain?.takeIf { it.isNotBlank() }, synced?.takeIf { it.isNotBlank() })
    }

    private fun decodeUnsynced(bytes: ByteArray, start: Int, end: Int): String? {
        if (end - start < 4) return null
        val encoding = bytes[start].toInt() and 0xff
        val charset = charsetFor(encoding) ?: return null
        val descriptorStart = start + 4
        val textStart = findTerminator(bytes, descriptorStart, end, encoding == 1 || encoding == 2) ?: return null
        return decodeText(bytes, textStart, end, charset)
    }

    /** Converts standard ID3 SYLT timestamps (milliseconds) into LRC lines. */
    private fun decodeSynced(bytes: ByteArray, start: Int, end: Int): String? {
        if (end - start < 7) return null
        val encoding = bytes[start].toInt() and 0xff
        val charset = charsetFor(encoding) ?: return null
        val timestampFormat = bytes[start + 4].toInt() and 0xff
        if (timestampFormat != 2) return null // MPEG-frame timestamps need the encoded audio frame rate.
        val descriptorStart = start + 6
        var position = findTerminator(bytes, descriptorStart, end, encoding == 1 || encoding == 2) ?: return null
        val lines = mutableListOf<String>()
        while (position < end) {
            val textStart = position
            val afterText = findTerminator(bytes, textStart, end, encoding == 1 || encoding == 2) ?: break
            val textEnd = afterText - if (encoding == 1 || encoding == 2) 2 else 1
            if (afterText + 4 > end) break
            val timestamp = ((bytes[afterText].toLong() and 0xff) shl 24) or
                ((bytes[afterText + 1].toLong() and 0xff) shl 16) or
                ((bytes[afterText + 2].toLong() and 0xff) shl 8) or
                (bytes[afterText + 3].toLong() and 0xff)
            val text = decodeText(bytes, textStart, textEnd, charset).orEmpty()
                .trim('\u0000', '\uFEFF', ' ', '\r', '\n')
            if (text.isNotBlank()) {
                val minutes = timestamp / 60_000L
                val seconds = (timestamp / 1_000L) % 60L
                val centiseconds = (timestamp % 1_000L) / 10L
                lines += "[${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centiseconds.toString().padStart(2, '0')}]$text"
            }
            position = afterText + 4
        }
        return lines.takeIf { it.isNotEmpty() }?.joinToString("\n")
    }

    private fun decodeUserText(bytes: ByteArray, start: Int, end: Int): Pair<String, String>? {
        if (end - start < 2) return null
        val encoding = bytes[start].toInt() and 0xff
        val charset = charsetFor(encoding) ?: return null
        val descriptionStart = start + 1
        val valueStart = findTerminator(bytes, descriptionStart, end, encoding == 1 || encoding == 2) ?: return null
        val description = decodeText(bytes, descriptionStart, valueStart - if (encoding == 1 || encoding == 2) 2 else 1, charset)
            .orEmpty().trim('\u0000', '\uFEFF', ' ')
        val value = decodeText(bytes, valueStart, end, charset).orEmpty().trim('\u0000', '\uFEFF', ' ', '\r', '\n')
        return description to value
    }

    private fun findTerminator(bytes: ByteArray, start: Int, end: Int, wide: Boolean): Int? {
        var index = start
        if (wide) {
            while (index + 1 < end) {
                if (bytes[index] == 0.toByte() && bytes[index + 1] == 0.toByte()) return index + 2
                index += 2
            }
        } else {
            while (index < end) {
                if (bytes[index] == 0.toByte()) return index + 1
                index++
            }
        }
        return null
    }

    private fun readFlac(bytes: ByteArray): EmbeddedLyrics? {
        var offset = 4
        var isLast = false
        var plain: String? = null
        var synced: String? = null
        var blocks = 0
        while (!isLast) {
            if (offset + 4 > bytes.size) return null
            val header = bytes[offset].toInt() and 0xff
            isLast = (header and 0x80) != 0
            val type = header and 0x7f
            val length = ((bytes[offset + 1].toInt() and 0xff) shl 16) or
                ((bytes[offset + 2].toInt() and 0xff) shl 8) or (bytes[offset + 3].toInt() and 0xff)
            offset += 4
            if (length > bytes.size - offset) return null
            if (type == 4) {
                val comments = parseVorbisComments(bytes, offset, length) ?: return null
                plain = comments.firstOrNull { it.substringBefore('=').equals("LYRICS", true) ||
                    it.substringBefore('=').equals("UNSYNCEDLYRICS", true) }
                    ?.substringAfter('=')
                synced = comments.firstOrNull { it.substringBefore('=').equals("LYRICS_SYNCED", true) }
                    ?.substringAfter('=')
            }
            offset += length
            blocks++
            if (blocks > 1024) return null
        }
        return EmbeddedLyrics(plain, synced)
    }

    private fun parseVorbisComments(bytes: ByteArray, offset: Int, length: Int): List<String>? {
        return runCatching {
            val buffer = ByteBuffer.wrap(bytes, offset, length).slice().order(ByteOrder.LITTLE_ENDIAN)
            val vendorLength = buffer.int
            require(vendorLength >= 0 && vendorLength <= buffer.remaining())
            buffer.position(buffer.position() + vendorLength)
            require(buffer.remaining() >= 4)
            val count = buffer.int
            require(count in 0..100_000)
            buildList {
                repeat(count) {
                    require(buffer.remaining() >= 4)
                    val itemLength = buffer.int
                    require(itemLength >= 0 && itemLength <= buffer.remaining())
                    val item = ByteArray(itemLength)
                    buffer.get(item)
                    add(String(item, Charsets.UTF_8))
                }
            }
        }.getOrNull()
    }

    private fun readMp4(bytes: ByteArray): EmbeddedLyrics? {
        val top = parseBoxes(bytes, 0, bytes.size, false) ?: return null
        val metadataItems = mutableListOf<Pair<String, String>>()
        fun walk(boxes: List<Mp4Box>, insideIlst: Boolean = false) {
            for (box in boxes) {
                if (insideIlst) {
                    if (box.type == "©lyr") {
                        box.children?.firstOrNull { it.type == "data" }?.let { data ->
                            decodeMp4Data(bytes, data)?.let { metadataItems += "LYRICS" to it }
                        }
                    } else if (box.type == "----") {
                        val name = box.children?.firstOrNull { it.type == "name" }?.let { decodeMp4Raw(bytes, it) }
                        val value = box.children?.firstOrNull { it.type == "data" }?.let { decodeMp4Data(bytes, it) }
                        if (name != null && value != null) metadataItems += name to value
                    }
                }
                if (box.type == "ilst") walk(box.children.orEmpty(), true)
                else if (box.type in MP4_CONTAINERS) walk(box.children.orEmpty(), false)
            }
        }
        walk(top)
        return EmbeddedLyrics(
            plainLyrics = metadataItems.firstOrNull { it.first.equals("LYRICS", true) }?.second,
            syncedLyrics = metadataItems.firstOrNull { it.first.equals("LYRICS_SYNCED", true) }?.second
        )
    }

    private data class Mp4Box(val type: String, val payloadStart: Int, val payloadEnd: Int, val children: List<Mp4Box>?)

    private fun parseBoxes(bytes: ByteArray, start: Int, end: Int, insideIlst: Boolean): List<Mp4Box>? {
        val result = mutableListOf<Mp4Box>()
        var offset = start
        while (offset < end) {
            if (end - offset < 8) return null
            val size32 = uint32Long(bytes, offset) ?: return null
            val type = String(bytes, offset + 4, 4, latin1)
            val header = if (size32 == 1L) 16 else 8
            val size = if (size32 == 0L) (end - offset).toLong()
                else if (size32 == 1L) {
                    if (end - offset < 16) return null
                    ByteBuffer.wrap(bytes, offset + 8, 8).order(ByteOrder.BIG_ENDIAN).long
                } else size32
            if (size < header || size > end - offset || size > Int.MAX_VALUE) return null
            val payloadStart = offset + header
            val payloadEnd = offset + size.toInt()
            val container = type in MP4_CONTAINERS || type == "----" || (insideIlst && type != "data")
            val prefix = if (type == "meta") 4 else 0
            val children = if (container) {
                if (payloadEnd - payloadStart < prefix) return null
                parseBoxes(bytes, payloadStart + prefix, payloadEnd, type == "ilst") ?: return null
            } else null
            result += Mp4Box(type, payloadStart, payloadEnd, children)
            offset = payloadEnd
            if (result.size > 100_000) return null
        }
        return result
    }

    private fun decodeMp4Data(bytes: ByteArray, box: Mp4Box): String? {
        if (box.payloadEnd - box.payloadStart < 8) return null
        return String(bytes, box.payloadStart + 8, box.payloadEnd - box.payloadStart - 8, Charsets.UTF_8)
            .trim('\u0000', '\uFEFF', ' ', '\r', '\n')
            .takeIf { it.isNotBlank() }
    }

    private fun decodeMp4Raw(bytes: ByteArray, box: Mp4Box): String? {
        if (box.payloadEnd - box.payloadStart < 4) return null
        return String(bytes, box.payloadStart + 4, box.payloadEnd - box.payloadStart - 4, Charsets.UTF_8)
            .trim('\u0000', ' ')
            .takeIf { it.isNotBlank() }
    }

    private fun charsetFor(encoding: Int) = when (encoding) {
        0 -> Charsets.ISO_8859_1
        1 -> Charsets.UTF_16
        2 -> Charsets.UTF_16BE
        3 -> Charsets.UTF_8
        else -> null
    }

    private fun decodeText(bytes: ByteArray, start: Int, end: Int, charset: java.nio.charset.Charset): String? {
        if (start < 0 || end < start || end > bytes.size) return null
        return runCatching { String(bytes, start, end - start, charset) }.getOrNull()
    }

    private fun synchsafe(bytes: ByteArray, offset: Int): Int? {
        if (offset < 0 || offset + 4 > bytes.size) return null
        val values = (0..3).map { bytes[offset + it].toInt() and 0xff }
        if (values.any { it and 0x80 != 0 }) return null
        return (values[0] shl 21) or (values[1] shl 14) or (values[2] shl 7) or values[3]
    }

    private fun uint32(bytes: ByteArray, offset: Int): Int? {
        if (offset < 0 || offset + 4 > bytes.size) return null
        return ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.BIG_ENDIAN).int
    }

    private fun uint32Long(bytes: ByteArray, offset: Int): Long? {
        if (offset < 0 || offset + 4 > bytes.size) return null
        return ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xffffffffL
    }

    private fun startsWith(bytes: ByteArray, signature: String): Boolean =
        bytes.size >= signature.length && signature.indices.all { bytes[it] == signature[it].code.toByte() }

    private val MP4_CONTAINERS = setOf("moov", "udta", "meta", "ilst")
}
