package com.chiyuri.player

import android.content.ContentUris
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import android.net.Uri
import android.provider.MediaStore

/**
 * Reads media already indexed by Android MediaStore.
 * SAF remains available for files that are not exposed by MediaStore.
 */
data class LocalMedia(
    val id: Long,
    val title: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val uri: Uri,
    val mimeType: String?,
    val isVideo: Boolean,
    val relativePath: String? = null
)

object LocalMediaRepository {
    fun loadAudio(context: Context): List<LocalMedia> =
        query(
            context = context,
            collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.MediaColumns.RELATIVE_PATH
            ),
            isVideo = false
        )

    fun loadVideos(context: Context): List<LocalMedia> =
        query(
            context = context,
            collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.MIME_TYPE,
                MediaStore.MediaColumns.RELATIVE_PATH
            ),
            isVideo = true
        )


    private const val CACHE_PREFS = "local_media_scan_cache"
    private const val CACHE_MAX_AGE_MS = 6L * 60L * 60L * 1000L

    private fun cacheKey(isVideo: Boolean) = if (isVideo) "videos" else "audio"
    private fun scanTimeKey(isVideo: Boolean) = "${cacheKey(isVideo)}_last_scan"

    fun loadCached(context: Context, isVideo: Boolean): List<LocalMedia> {
        val raw = context.getSharedPreferences(CACHE_PREFS, Context.MODE_PRIVATE)
            .getString(cacheKey(isVideo), null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val id = item.optLong("id", -1L)
                    val uri = item.optString("uri").takeIf { it.isNotBlank() } ?: continue
                    if (id < 0L) continue
                    add(LocalMedia(
                        id = id,
                        title = item.optString("title").ifBlank { if (isVideo) "Видео $id" else "Аудио $id" },
                        artist = item.optNullableString("artist"),
                        album = item.optNullableString("album"),
                        durationMs = item.optLong("durationMs", 0L),
                        uri = Uri.parse(uri),
                        mimeType = item.optNullableString("mimeType"),
                        isVideo = isVideo,
                        relativePath = item.optNullableString("relativePath")
                    ))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Saves results and scan time, including a legitimately empty library. */
    fun saveScan(context: Context, isVideo: Boolean, items: List<LocalMedia>) {
        val array = JSONArray()
        items.forEach { media ->
            array.put(JSONObject()
                .put("id", media.id)
                .put("title", media.title)
                .put("artist", media.artist ?: JSONObject.NULL)
                .put("album", media.album ?: JSONObject.NULL)
                .put("durationMs", media.durationMs)
                .put("uri", media.uri.toString())
                .put("mimeType", media.mimeType ?: JSONObject.NULL)
                .put("relativePath", media.relativePath ?: JSONObject.NULL))
        }
        context.getSharedPreferences(CACHE_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(cacheKey(isVideo), array.toString())
            .putLong(scanTimeKey(isVideo), System.currentTimeMillis())
            .apply()
    }

    /** First use scans automatically; cached libraries refresh after six hours. */
    fun shouldAutoScan(context: Context, isVideo: Boolean): Boolean {
        val lastScan = context.getSharedPreferences(CACHE_PREFS, Context.MODE_PRIVATE)
            .getLong(scanTimeKey(isVideo), 0L)
        return lastScan == 0L || System.currentTimeMillis() - lastScan >= CACHE_MAX_AGE_MS
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).takeIf { it.isNotBlank() }
    }

    private fun query(
        context: Context,
        collection: Uri,
        projection: Array<String>,
        isVideo: Boolean
    ): List<LocalMedia> {
        val result = mutableListOf<LocalMedia>()
        val sortOrder = if (isVideo) {
            MediaStore.Video.Media.TITLE + " COLLATE NOCASE ASC"
        } else {
            MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC"
        }

        return try {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.TITLE)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
                val mimeColumn = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
                val artistColumn = if (isVideo) -1 else cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumColumn = if (isVideo) -1 else cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val relativePathColumn = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn)?.takeIf { it.isNotBlank() }
                        ?: if (isVideo) "Видео $id" else "Аудио $id"
                    val itemUri = ContentUris.withAppendedId(collection, id)
                    result += LocalMedia(
                        id = id,
                        title = title,
                        artist = if (artistColumn >= 0) cursor.getString(artistColumn) else null,
                        album = if (albumColumn >= 0) cursor.getString(albumColumn) else null,
                        durationMs = cursor.getLong(durationColumn),
                        uri = itemUri,
                        mimeType = if (mimeColumn >= 0) cursor.getString(mimeColumn) else null,
                        isVideo = isVideo,
                        relativePath = if (relativePathColumn >= 0) cursor.getString(relativePathColumn) else null
                    )
                }
                result
            } ?: emptyList()
        } catch (_: SecurityException) {
            emptyList()
        } catch (_: IllegalArgumentException) {
            emptyList()
        }
    }
}
