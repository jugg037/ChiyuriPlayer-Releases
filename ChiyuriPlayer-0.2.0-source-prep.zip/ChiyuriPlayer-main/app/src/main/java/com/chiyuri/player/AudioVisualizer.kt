package com.chiyuri.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class VisualizerMode(val label: String, val storageValue: String) {
    WAVE("Волна", "wave"),
    SPECTRUM("Спектр", "spectrum"),
    BARS("Столбцы", "bars"),
    CIRCLE("Круг", "circle");

    companion object {
        fun from(value: String?): VisualizerMode =
            entries.firstOrNull { it.storageValue == value } ?: BARS
    }
}

object VisualizerSettings {
    private const val PREFS = "visualizer_settings"
    fun isEnabled(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()
    }
    fun mode(context: Context): VisualizerMode =
        VisualizerMode.from(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("mode", "bars"))
    fun setMode(context: Context, mode: VisualizerMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("mode", mode.storageValue).apply()
    }
}

/**
 * The MediaController shown in Compose does not expose ExoPlayer.audioSessionId.
 * The service owns the real ExoPlayer and publishes its live audio-session data here.
 */
internal object AudioVisualizerBridge {
    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var appContext: Context? = null
    private var activeController: AudioVisualizerController? = null
    private var preferencesListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    private val mutableSessionId = MutableStateFlow(0)
    private val mutableStatus = MutableStateFlow("Ожидание воспроизведения")
    private val mutableWaveform = MutableStateFlow(List(64) { 0f })
    private val mutableSpectrum = MutableStateFlow(List(64) { 0f })
    val sessionId: StateFlow<Int> = mutableSessionId
    val status: StateFlow<String> = mutableStatus
    val waveform: StateFlow<List<Float>> = mutableWaveform
    val spectrum: StateFlow<List<Float>> = mutableSpectrum

    private val poller = object : Runnable {
        override fun run() {
            val current = player
            if (current != null) {
                updateSession(current.audioSessionId)
                refresh()
                handler.postDelayed(this, 400L)
            }
        }
    }

    fun bind(context: Context, exoPlayer: ExoPlayer) {
        unbind()
        appContext = context.applicationContext
        player = exoPlayer
        val prefs = appContext!!.getSharedPreferences("visualizer_settings", Context.MODE_PRIVATE)
        preferencesListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }
        prefs.registerOnSharedPreferenceChangeListener(preferencesListener)
        exoPlayer.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                updateSession(audioSessionId)
                refresh()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { refresh() }
            override fun onPlaybackStateChanged(playbackState: Int) { refresh() }
        })
        updateSession(exoPlayer.audioSessionId)
        refresh()
        handler.removeCallbacks(poller)
        handler.post(poller)
    }

    fun unbind() {
        handler.removeCallbacks(poller)
        activeController?.stop()
        activeController = null
        val prefs = appContext?.getSharedPreferences("visualizer_settings", Context.MODE_PRIVATE)
        preferencesListener?.let { prefs?.unregisterOnSharedPreferenceChangeListener(it) }
        preferencesListener = null
        player = null
        appContext = null
        mutableSessionId.value = 0
        mutableStatus.value = "Ожидание воспроизведения"
    }

    fun refresh(context: Context? = appContext) {
        if (context != null && appContext == null) appContext = context.applicationContext
        val ctx = appContext ?: return
        val currentPlayer = player
        val session = currentPlayer?.audioSessionId ?: 0
        updateSession(session)
        val permitted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val enabled = VisualizerSettings.isEnabled(ctx)
        if (!enabled) {
            activeController?.stop()
            activeController = null
            mutableStatus.value = "Визуализатор выключен"
            return
        }
        if (!permitted) {
            activeController?.stop()
            activeController = null
            mutableStatus.value = "Нужно разрешение на анализ аудио"
            return
        }
        if (currentPlayer?.isPlaying != true) {
            activeController?.stop()
            activeController = null
            mutableStatus.value = if (session > 0) "Запусти воспроизведение" else "Ожидание аудиосессии"
            return
        }
        if (session <= 0) {
            activeController?.stop()
            activeController = null
            mutableStatus.value = "ExoPlayer ещё не создал аудиосессию"
            return
        }
        if (activeController?.audioSessionId != session) {
            activeController?.stop()
            activeController = AudioVisualizerController(
                session,
                onWaveform = { mutableWaveform.value = it },
                onSpectrum = { mutableSpectrum.value = it },
                onStatus = { mutableStatus.value = it }
            )
        }
        if (activeController?.isRunning != true) activeController?.start()
    }

    private fun updateSession(id: Int) {
        mutableSessionId.value = id.coerceAtLeast(0)
    }
}

internal class AudioVisualizerController(
    val audioSessionId: Int,
    private val onWaveform: (List<Float>) -> Unit,
    private val onSpectrum: (List<Float>) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private var effect: Visualizer? = null
    val isRunning: Boolean get() = effect?.enabled == true

    fun start() {
        if (effect != null || audioSessionId <= 0) return
        try {
            val visualizer = Visualizer(audioSessionId)
            val range = Visualizer.getCaptureSizeRange()
            visualizer.captureSize = range[1].coerceAtMost(1024)
            val rate = Visualizer.getMaxCaptureRate().coerceAtMost(20_000)
            val result = visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer, waveform: ByteArray, samplingRate: Int) {
                    val step = (waveform.size / 64).coerceAtLeast(1)
                    onWaveform(List(64) { index ->
                        val value = waveform[(index * step).coerceAtMost(waveform.lastIndex)].toInt() and 0xFF
                        ((value - 128) / 128f).coerceIn(-1f, 1f)
                    })
                }
                override fun onFftDataCapture(visualizer: Visualizer, fft: ByteArray, samplingRate: Int) {
                    val bins = (fft.size / 2).coerceAtLeast(1)
                    onSpectrum(List(64) { index ->
                        val bin = (1 + index * (bins - 1) / 64).coerceIn(1, bins - 1)
                        val real = fft.getOrElse(bin * 2) { 0 }.toInt()
                        val imaginary = fft.getOrElse(bin * 2 + 1) { 0 }.toInt()
                        (sqrt((real * real + imaginary * imaginary).toFloat()) / 90f).coerceIn(0f, 1f)
                    })
                    onStatus("Визуализатор подключён")
                }
            }, rate, true, true)
            if (result != Visualizer.SUCCESS) {
                visualizer.release()
                onStatus("Android не разрешил захват аудио (код $result)")
                return
            }
            effect = visualizer
            val enabledResult = runCatching { visualizer.enabled = true }.exceptionOrNull()
            if (enabledResult != null) {
                visualizer.release()
                effect = null
                onStatus("Не удалось включить визуализатор: ${enabledResult.message ?: "ошибка Android"}")
            } else {
                onStatus("Подключено к аудиосессии $audioSessionId")
            }
        } catch (error: Exception) {
            onStatus("Визуализатор недоступен: ${error.message ?: error.javaClass.simpleName}")
            stop()
        }
    }

    fun stop() {
        runCatching {
            effect?.enabled = false
            effect?.release()
        }
        effect = null
    }
}

@Composable
internal fun AudioVisualizerScreen(player: Player) {
    val context = LocalContext.current
    var enabled by remember(context) { mutableStateOf(VisualizerSettings.isEnabled(context)) }
    var mode by remember(context) { mutableStateOf(VisualizerSettings.mode(context)) }
    var hasPermission by remember(context) {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var pendingEnable by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted && pendingEnable) {
            enabled = true
            VisualizerSettings.setEnabled(context, true)
        }
        pendingEnable = false
        AudioVisualizerBridge.refresh(context)
    }
    val status by AudioVisualizerBridge.status.collectAsState()
    val waveform by AudioVisualizerBridge.waveform.collectAsState()
    val spectrum by AudioVisualizerBridge.spectrum.collectAsState()
    val frames = if (mode == VisualizerMode.WAVE) waveform else spectrum

    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Аудиовизуализатор", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                    Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { checked ->
                        if (!checked) {
                            enabled = false
                            pendingEnable = false
                            VisualizerSettings.setEnabled(context, false)
                            AudioVisualizerBridge.refresh(context)
                        } else if (hasPermission) {
                            enabled = true
                            VisualizerSettings.setEnabled(context, true)
                            AudioVisualizerBridge.refresh(context)
                        } else {
                            pendingEnable = true
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                )
            }
            if (!hasPermission) {
                Text("Для анализа звука требуется разрешение RECORD_AUDIO. Звук не записывается и не сохраняется.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                    Text("Разрешить доступ к аудио")
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VisualizerMode.entries.forEach { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = mode == item,
                            onClick = { mode = item; VisualizerSettings.setMode(context, item) }
                        )
                        Text(item.label, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
                    }
                }
            }
            VisualizerGraph(frames, mode, Modifier.fillMaxWidth().height(116.dp))
        }
    }
}

@Composable
internal fun AudioVisualizerMiniDisplay(player: Player, modifier: Modifier = Modifier.height(54.dp)) {
    val context = LocalContext.current
    var enabled by remember(context) { mutableStateOf(VisualizerSettings.isEnabled(context)) }
    var mode by remember(context) { mutableStateOf(VisualizerSettings.mode(context)) }
    androidx.compose.runtime.DisposableEffect(context) {
        val prefs = context.getSharedPreferences("visualizer_settings", Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            enabled = VisualizerSettings.isEnabled(context)
            mode = VisualizerSettings.mode(context)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    val frames by (if (mode == VisualizerMode.WAVE) AudioVisualizerBridge.waveform else AudioVisualizerBridge.spectrum).collectAsState()
    if (enabled) VisualizerGraph(frames, mode, modifier.fillMaxWidth())
}

@Composable
private fun VisualizerGraph(frames: List<Float>, mode: VisualizerMode, modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    val background = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier.clip(RoundedCornerShape(12.dp)).background(background)) {
        val centerY = size.height / 2f
        when (mode) {
            VisualizerMode.WAVE -> {
                val stepX = size.width / (frames.size - 1).coerceAtLeast(1)
                for (i in 0 until frames.lastIndex) {
                    drawLine(
                        color = accent,
                        start = androidx.compose.ui.geometry.Offset(i * stepX, centerY + frames[i] * centerY * 0.85f),
                        end = androidx.compose.ui.geometry.Offset((i + 1) * stepX, centerY + frames[i + 1] * centerY * 0.85f),
                        strokeWidth = 2.5f
                    )
                }
            }
            VisualizerMode.SPECTRUM, VisualizerMode.BARS -> {
                val count = if (mode == VisualizerMode.SPECTRUM) 48 else 24
                val gap = 3.dp.toPx()
                val barWidth = (size.width - gap * (count - 1)) / count
                repeat(count) { index ->
                    val magnitude = frames.getOrElse(index * frames.size / count) { 0f }.coerceIn(0f, 1f)
                    val height = (size.height * (0.04f + magnitude * 0.94f)).coerceAtLeast(3f)
                    drawRoundRect(
                        color = accent.copy(alpha = 0.4f + magnitude * 0.6f),
                        topLeft = androidx.compose.ui.geometry.Offset(index * (barWidth + gap), size.height - height),
                        size = androidx.compose.ui.geometry.Size(barWidth, height),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2f)
                    )
                }
            }
            VisualizerMode.CIRCLE -> {
                val radius = size.minDimension * 0.27f
                val center = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
                drawCircle(color = accent.copy(alpha = 0.35f), radius = radius, center = center, style = Stroke(width = 2.dp.toPx()))
                repeat(64) { index ->
                    val angle = (2.0 * PI * index / 64.0).toFloat()
                    val magnitude = frames.getOrElse(index) { 0f }.coerceIn(0f, 1f)
                    val outer = radius + 5.dp.toPx() + magnitude * 24.dp.toPx()
                    drawLine(
                        color = accent,
                        start = androidx.compose.ui.geometry.Offset(center.x + cos(angle) * radius, center.y + sin(angle) * radius),
                        end = androidx.compose.ui.geometry.Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }
        }
    }
}
