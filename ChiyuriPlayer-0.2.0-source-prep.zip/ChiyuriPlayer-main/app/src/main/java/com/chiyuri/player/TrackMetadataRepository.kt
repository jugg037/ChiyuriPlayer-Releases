package com.chiyuri.player

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class TrackMetadata(
    val title: String,
    val artist: String = "",
    val album: String = "",
    val year: String = "",
    val artworkUrl: String = "",
    val plainLyrics: String = "",
    val syncedLyrics: String = ""
)

object TrackMetadataRepository {
    private const val PREFS = "track_metadata_overrides"

    fun readLocal(context: Context, uri: Uri): TrackMetadata {
        val override = loadOverride(context, uri)
        val retriever = MediaMetadataRetriever()
        var embedded = TrackMetadata(title = displayName(context, uri))
        try {
            retriever.setDataSource(context, uri)
            embedded = TrackMetadata(
                title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?.takeIf { it.isNotBlank() } ?: embedded.title,
                artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty(),
                year = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR).orEmpty()
            )
        } catch (_: Exception) {
            // Some SAF providers do not expose retrievable metadata; use the display name.
        } finally {
            runCatching { retriever.release() }
        }
        return override ?: embedded
    }

    fun readEmbeddedLyrics(context: Context, uri: Uri): String? =
        readEmbeddedLyricsResult(context, uri)?.plainLyrics

    fun readEmbeddedLyricsResult(context: Context, uri: Uri): EmbeddedLyrics? {
        val bytes = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (total < 16 * 1024 * 1024) {
                    val count = input.read(buffer, 0, minOf(buffer.size, 16 * 1024 * 1024 - total))
                    if (count < 0) break
                    if (count == 0) continue
                    output.write(buffer, 0, count)
                    total += count
                }
                output.toByteArray()
            }
        }.getOrNull() ?: return null
        return EmbeddedLyricsReader.read(bytes)
    }

    private fun synchsafeInt(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0x7F) shl 21) or
            ((data[offset + 1].toInt() and 0x7F) shl 14) or
            ((data[offset + 2].toInt() and 0x7F) shl 7) or
            (data[offset + 3].toInt() and 0x7F)

    fun loadEmbeddedArtwork(context: Context, uri: Uri): ByteArray? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.embeddedPicture
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        var name = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.').orEmpty()
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index)?.substringBeforeLast('.') ?: name
                }
            }
        }
        return name.trim().ifBlank { "Неизвестная композиция" }
    }

    suspend fun search(title: String, artist: String): TrackMetadata? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            if (title.isBlank()) return@withContext null
            val term = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" ")
            val encoded = URLEncoder.encode(term, Charsets.UTF_8.name())
            val connection = (URL("https://itunes.apple.com/search?term=$encoded&entity=song&limit=12").openConnection() as HttpURLConnection)
            try {
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.setRequestProperty("Accept", "application/json")
                if (connection.responseCode !in 200..299) return@withContext null
                val json = JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                val results = json.optJSONArray("results") ?: return@withContext null
                if (results.length() == 0) return@withContext null
                val candidates = (0 until results.length()).mapNotNull { results.optJSONObject(it) }
                val best = candidates.maxByOrNull { item ->
                    val candidateTitle = item.optString("trackName")
                    val candidateArtist = item.optString("artistName")
                    (if (candidateTitle.equals(title, true)) 4 else if (candidateTitle.contains(title, true)) 2 else 0) +
                        (if (artist.isNotBlank() && candidateArtist.equals(artist, true)) 3 else 0)
                } ?: return@withContext null
                TrackMetadata(
                    title = best.optString("trackName", title),
                    artist = best.optString("artistName", artist),
                    album = best.optString("collectionName"),
                    year = best.optString("releaseDate").take(4),
                    artworkUrl = best.optString("artworkUrl100").replace("100x100bb", "600x600bb")
                )
            } catch (_: Exception) {
                null
            } finally {
                connection.disconnect()
            }
        }

    /**
     * Writes metadata into the selected MP3, FLAC, or M4A/MP4 audio file.
     * Returns null on success and a user-readable error on failure.
     */
    suspend fun writeMetadataToFile(context: Context, uri: Uri, metadata: TrackMetadata): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val mime = runCatching { context.contentResolver.getType(uri).orEmpty().lowercase() }.getOrDefault("")
            val displayFileName = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index >= 0) cursor.getString(index).orEmpty() else ""
                    } else ""
                }.orEmpty()
            }.getOrDefault("")
            val pathName = uri.lastPathSegment.orEmpty()
            val extension = (displayFileName.ifBlank { pathName }).substringAfterLast('.', "").lowercase()
            val format = when {
                mime == "audio/mpeg" || extension == "mp3" -> "mp3"
                mime == "audio/flac" || mime == "audio/x-flac" || extension == "flac" -> "flac"
                mime == "audio/mp4" || mime == "audio/x-m4a" || mime == "video/mp4" ||
                    extension == "m4a" || extension == "mp4" -> "m4a"
                else -> return@withContext "Запись тегов поддерживается для MP3, FLAC и M4A. Этот формат пока не поддерживается."
            }

            val workDir = java.io.File(context.cacheDir, "media-tag-write").apply { mkdirs() }
            val original: java.io.File
            try {
                original = java.io.File.createTempFile("original-", ".$format", workDir)
            } catch (error: Exception) {
                return@withContext error.message?.takeIf { it.isNotBlank() }
                    ?: "Не удалось создать временную копию исходного файла."
            }
            val rewritten: java.io.File
            try {
                rewritten = java.io.File.createTempFile("rewritten-", ".$format", workDir)
            } catch (error: Exception) {
                original.delete()
                return@withContext error.message?.takeIf { it.isNotBlank() }
                    ?: "Не удалось создать временный файл для записи."
            }
            try {
                val source = context.contentResolver.openInputStream(uri)
                    ?: return@withContext "Не удалось открыть исходный файл."
                source.use { input -> original.outputStream().use { output -> input.copyTo(output) } }

                val artwork = downloadArtwork(metadata.artworkUrl)
                when (format) {
                    "mp3" -> Mp3Id3TagWriter.rewrite(original, rewritten, metadata, artwork)
                    "flac" -> FlacMetadataWriter.rewrite(original, rewritten, metadata, artwork)
                    "m4a" -> Mp4MetadataWriter.rewrite(original, rewritten, metadata, artwork)
                }

                try {
                    val destination = context.contentResolver.openOutputStream(uri, "rwt")
                        ?: throw java.io.IOException("Поставщик файлов не разрешил запись.")
                    destination.use { output ->
                        rewritten.inputStream().use { input -> input.copyTo(output) }
                        output.flush()
                    }
                    require(contentMatches(context, uri, rewritten)) {
                        "Проверка записанного файла не пройдена: содержимое отличается от подготовленной версии."
                    }
                } catch (writeError: Exception) {
                    val rollback = runCatching {
                        val destination = context.contentResolver.openOutputStream(uri, "rwt")
                            ?: throw java.io.IOException("Поставщик файлов не разрешил восстановление.")
                        destination.use { output ->
                            original.inputStream().use { input -> input.copyTo(output) }
                            output.flush()
                        }
                        require(contentMatches(context, uri, original)) {
                            "Содержимое после восстановления не совпадает с оригиналом."
                        }
                    }
                    if (rollback.isFailure) {
                        throw java.io.IOException(
                            "Ошибка записи, и автоматическое восстановление не удалось. Не изменяйте файл и проверьте его вручную.",
                            writeError
                        )
                    }
                    throw java.io.IOException(
                        "Запись не прошла проверку. Исходный файл восстановлен.",
                        writeError
                    )
                }
                null
            } catch (error: Exception) {
                error.message?.takeIf { it.isNotBlank() } ?: "Не удалось записать метаданные в файл."
            } finally {
                original.delete()
                rewritten.delete()
            }
        }

    /** Backward-compatible entry point retained for existing callers. */
    suspend fun writeMp3Tags(context: Context, uri: Uri, metadata: TrackMetadata): String? =
        writeMetadataToFile(context, uri, metadata)

    private fun downloadArtwork(artworkUrl: String): ByteArray? {
        if (artworkUrl.isBlank()) return null
        require(artworkUrl.startsWith("https://", ignoreCase = true)) {
            "Для обложки разрешены только HTTPS-ссылки."
        }
        val connection = (URL(artworkUrl).openConnection() as HttpURLConnection)
        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 10000
            connection.instanceFollowRedirects = true
            require(connection.responseCode in 200..299) { "Не удалось загрузить обложку." }
            require(connection.url.protocol.equals("https", ignoreCase = true)) {
                "Ссылка на обложку перенаправила на небезопасное HTTP-соединение."
            }
            require(connection.contentLengthLong <= 10L * 1024 * 1024 || connection.contentLengthLong < 0) {
                "Файл обложки превышает 10 МБ."
            }
            return connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= 10 * 1024 * 1024) { "Файл обложки превышает 10 МБ." }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun contentMatches(context: Context, uri: Uri, expected: java.io.File): Boolean {
        val actual = context.contentResolver.openInputStream(uri) ?: return false
        return actual.use { actualInput ->
            expected.inputStream().use { expectedInput ->
                val actualBuffer = ByteArray(64 * 1024)
                val expectedBuffer = ByteArray(64 * 1024)
                var matches = true
                var finished = false
                while (!finished) {
                    val actualCount = actualInput.read(actualBuffer)
                    val expectedCount = expectedInput.read(expectedBuffer)
                    if (actualCount != expectedCount) {
                        matches = false
                        finished = true
                    } else if (actualCount < 0) {
                        finished = true
                    } else {
                        for (index in 0 until actualCount) {
                            if (actualBuffer[index] != expectedBuffer[index]) {
                                matches = false
                                finished = true
                                break
                            }
                        }
                    }
                }
                matches
            }
        }
    }

    fun saveOverride(context: Context, uri: Uri, metadata: TrackMetadata) {
        val key = uri.toString()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val all = runCatching { JSONObject(prefs.getString("items", "{}") ?: "{}") }.getOrDefault(JSONObject())
        all.put(key, JSONObject()
            .put("title", metadata.title)
            .put("artist", metadata.artist)
            .put("album", metadata.album)
            .put("year", metadata.year)
            .put("artworkUrl", metadata.artworkUrl)
            .put("plainLyrics", metadata.plainLyrics)
            .put("syncedLyrics", metadata.syncedLyrics))
        prefs.edit().putString("items", all.toString()).apply()
    }

    fun loadOverride(context: Context, uri: Uri): TrackMetadata? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("items", null) ?: return null
        val item = runCatching { JSONObject(raw).optJSONObject(uri.toString()) }.getOrNull() ?: return null
        return TrackMetadata(
            title = item.optString("title").ifBlank { displayName(context, uri) },
            artist = item.optString("artist"),
            album = item.optString("album"),
            year = item.optString("year"),
            artworkUrl = item.optString("artworkUrl"),
            plainLyrics = item.optString("plainLyrics"),
            syncedLyrics = item.optString("syncedLyrics")
        )
    }

    fun toMediaItem(uri: Uri, metadata: TrackMetadata): MediaItem {
        val builder = MediaMetadata.Builder()
            .setTitle(metadata.title)
            .setArtist(metadata.artist.takeIf { it.isNotBlank() })
            .setAlbumTitle(metadata.album.takeIf { it.isNotBlank() })
            .setReleaseYear(metadata.year.toIntOrNull())
        if (metadata.artworkUrl.startsWith("https://")) {
            builder.setArtworkUri(Uri.parse(metadata.artworkUrl))
        }
        return MediaItem.Builder().setUri(uri).setMediaMetadata(builder.build()).build()
    }
}
