package com.chiyuri.player

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Conservative ISO-BMFF metadata writer for M4A/AAC. */
internal object Mp4MetadataWriter {
    private const val MAX_MOOV_SIZE = 64 * 1024 * 1024
    private val latin1 = Charsets.ISO_8859_1

    private data class Box(
        val type: String,
        var payload: ByteArray = ByteArray(0),
        var prefix: ByteArray = ByteArray(0),
        var children: MutableList<Box>? = null
    )
    private data class TopBox(val type: String, val offset: Long, val size: Long)

    fun rewrite(source: File, destination: File, metadata: TrackMetadata, artwork: ByteArray? = null) {
        require(source.isFile && source.canRead()) { "Исходный M4A-файл недоступен для чтения." }
        require(source.canonicalFile != destination.canonicalFile) { "Для безопасной записи нужен отдельный временный файл." }
        require(source.length() >= 16L) { "Файл слишком короткий и не похож на MP4/M4A." }
        RandomAccessFile(source, "r").use { input ->
            val top = mutableListOf<TopBox>()
            var position = 0L
            while (position < input.length()) {
                require(input.length() - position >= 8L) { "Повреждён заголовок MP4 atom." }
                input.seek(position)
                val size32 = input.readInt().toLong() and 0xffffffffL
                val type = String(ByteArray(4).also(input::readFully), latin1)
                val size = when (size32) {
                    0L -> input.length() - position
                    1L -> input.readLong().also { require(it >= 16L) { "Недопустимый extended-size atom." } }
                    else -> size32
                }
                require(size >= 8L && size <= input.length() - position) { "Некорректный размер MP4 atom: " + type }
                top += TopBox(type, position, size)
                position += size
                require(top.size <= 100_000) { "Слишком много MP4 atoms." }
            }

            require(top.none { it.type == "moof" || it.type == "sidx" || it.type == "mfra" }) {
                "Фрагментированные MP4-файлы пока не поддерживаются: их временные смещения нельзя безопасно обновить этим редактором."
            }
            val moovList = top.filter { it.type == "moov" }
            require(moovList.size == 1) { "Файл должен содержать ровно один moov atom." }
            val moov = moovList.single()
            require(moov.size <= MAX_MOOV_SIZE) { "moov atom превышает безопасный лимит 64 МБ." }
            val originalMoov = ByteArray(moov.size.toInt())
            input.seek(moov.offset)
            input.readFully(originalMoov)
            val root = parseSingleBox(originalMoov)
            require(root.type == "moov" && root.children != null) { "Повреждена структура moov atom." }
            require(root.children!!.none { it.type == "cmov" || it.type == "mvex" }) {
                "Сжатые и фрагментированные MP4-контейнеры пока не поддерживаются безопасной перезаписью."
            }

            writeMetadata(root, metadata, artwork)
            var rewrittenMoov = serializeBox(root)
            require(rewrittenMoov.size <= MAX_MOOV_SIZE) { "Обновлённый moov atom превышает лимит 64 МБ." }

            val firstMdat = top.firstOrNull { it.type == "mdat" }
            if (firstMdat != null && moov.offset < firstMdat.offset) {
                val delta = rewrittenMoov.size.toLong() - moov.size
                if (delta != 0L) {
                    adjustChunkOffsets(root, moov.offset + moov.size, delta)
                    rewrittenMoov = serializeBox(root)
                    require(rewrittenMoov.size.toLong() - moov.size == delta) {
                        "Размер moov изменился при коррекции chunk offsets; запись отменена."
                    }
                }
            }

            destination.parentFile?.mkdirs()
            RandomAccessFile(destination, "rw").use { output ->
                output.setLength(0)
                val buffer = ByteArray(64 * 1024)
                var cursor = 0L
                for (atom in top) {
                    if (atom.offset > cursor) copyRange(input, output, cursor, atom.offset - cursor, buffer)
                    if (atom.type == "moov") output.write(rewrittenMoov)
                    else copyRange(input, output, atom.offset, atom.size, buffer)
                    cursor = atom.offset + atom.size
                }
                if (cursor < input.length()) copyRange(input, output, cursor, input.length() - cursor, buffer)
                output.fd.sync()
            }
        }
    }

    private fun writeMetadata(moov: Box, metadata: TrackMetadata, artwork: ByteArray?) {
        val moovChildren = requireNotNull(moov.children)
        var udta = moovChildren.firstOrNull { it.type == "udta" }
        if (udta == null) {
            udta = Box("udta", children = mutableListOf())
            moovChildren += udta
        }
        val udtaChildren = requireNotNull(udta.children)
        var meta = udtaChildren.firstOrNull { it.type == "meta" }
        if (meta == null) {
            meta = Box("meta", prefix = ByteArray(4), children = mutableListOf())
            udtaChildren += meta
        }
        val metaChildren = requireNotNull(meta.children)
        if (metaChildren.none { it.type == "hdlr" }) metaChildren.add(0, makeHandlerBox())
        var ilst = metaChildren.firstOrNull { it.type == "ilst" }
        if (ilst == null) {
            ilst = Box("ilst", children = mutableListOf())
            metaChildren += ilst
        }
        val items = requireNotNull(ilst.children)
        val replaced = mutableSetOf("©nam", "©ART", "©alb", "©day", "©lyr")
        if (artwork != null) replaced += "covr"
        items.removeAll { it.type in replaced || (it.type == "----" && isSyncedLyricsItem(it)) }
        addTextItem(items, "©nam", metadata.title)
        addTextItem(items, "©ART", metadata.artist)
        addTextItem(items, "©alb", metadata.album)
        addTextItem(items, "©day", metadata.year)
        addTextItem(items, "©lyr", metadata.plainLyrics)
        if (metadata.syncedLyrics.isNotBlank()) items += makeFreeformLyrics(metadata.syncedLyrics)
        if (artwork != null) items += makeArtworkItem(artwork)
    }

    private fun makeHandlerBox(): Box {
        val output = java.io.ByteArrayOutputStream()
        output.write(ByteArray(8))
        output.write("mdir".toByteArray(latin1))
        output.write(ByteArray(12))
        output.write("appl".toByteArray(latin1))
        output.write(0)
        return Box("hdlr", payload = output.toByteArray())
    }

    private fun addTextItem(items: MutableList<Box>, type: String, value: String) {
        if (value.isNotBlank()) items += Box(type, children = mutableListOf(makeDataBox(1, value.toByteArray(Charsets.UTF_8))))
    }

    private fun makeArtworkItem(bytes: ByteArray): Box {
        val kind = when {
            bytes.size >= 3 && bytes[0] == 0xff.toByte() && bytes[1] == 0xd8.toByte() && bytes[2] == 0xff.toByte() -> 13
            bytes.size >= 8 && bytes.copyOfRange(0, 8).contentEquals(
                byteArrayOf(0x89.toByte(), 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)
            ) -> 14
            else -> throw IllegalArgumentException("Обложка M4A должна быть изображением JPEG или PNG.")
        }
        return Box("covr", children = mutableListOf(makeDataBox(kind, bytes)))
    }

    private fun makeFreeformLyrics(value: String): Box {
        val mean = Box("mean", payload = ByteArray(4) + "com.apple.iTunes".toByteArray(Charsets.UTF_8))
        val name = Box("name", payload = ByteArray(4) + "LYRICS_SYNCED".toByteArray(Charsets.UTF_8))
        return Box("----", children = mutableListOf(mean, name, makeDataBox(1, value.toByteArray(Charsets.UTF_8))))
    }

    private fun isSyncedLyricsItem(item: Box): Boolean =
        item.children?.any { child ->
            child.type == "name" && child.payload.size >= 4 &&
                String(child.payload, 4, child.payload.size - 4, Charsets.UTF_8) == "LYRICS_SYNCED"
        } == true

    private fun makeDataBox(kind: Int, bytes: ByteArray): Box {
        val header = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putInt(kind).putInt(0).array()
        return Box("data", payload = header + bytes)
    }

    private fun adjustChunkOffsets(box: Box, oldMoovEnd: Long, delta: Long) {
        val children = box.children
        if (children != null) {
            children.forEach { adjustChunkOffsets(it, oldMoovEnd, delta) }
            return
        }
        if (box.type != "stco" && box.type != "co64") return
        val data = box.payload
        require(data.size >= 8) { "Повреждён " + box.type + " atom." }
        val count = ByteBuffer.wrap(data, 4, 4).order(ByteOrder.BIG_ENDIAN).int
        val width = if (box.type == "stco") 4 else 8
        require(count >= 0 && 8L + count.toLong() * width == data.size.toLong()) {
            "Некорректный список chunk offsets (" + box.type + ")."
        }
        val buffer = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN)
        buffer.position(8)
        repeat(count) {
            if (width == 4) {
                val old = buffer.int.toLong() and 0xffffffffL
                val updated = if (old >= oldMoovEnd) old + delta else old
                require(updated in 0..0xffffffffL) {
                    "Chunk offset не помещается в stco после изменения metadata; файл оставлен без изменений."
                }
                buffer.putInt(buffer.position() - 4, updated.toInt())
            } else {
                val old = buffer.long
                val updated = if (old >= oldMoovEnd) Math.addExact(old, delta) else old
                require(updated >= 0L) { "Недопустимый chunk offset в co64." }
                buffer.putLong(buffer.position() - 8, updated)
            }
        }
    }

    private fun parseSingleBox(bytes: ByteArray): Box {
        val boxes = parseBoxes(bytes, 0, bytes.size, false)
        require(boxes.size == 1) { "Некорректный корневой MP4 atom." }
        return boxes.single()
    }

    private fun parseBoxes(bytes: ByteArray, start: Int, end: Int, forceContainer: Boolean): MutableList<Box> {
        val result = mutableListOf<Box>()
        var offset = start
        while (offset < end) {
            require(end - offset >= 8) { "Повреждён вложенный MP4 atom." }
            val size32 = readUInt32(bytes, offset)
            val type = String(bytes, offset + 4, 4, latin1)
            val headerSize: Int
            val size: Long
            when (size32) {
                0L -> { headerSize = 8; size = (end - offset).toLong() }
                1L -> {
                    require(end - offset >= 16) { "Повреждён extended-size MP4 atom." }
                    headerSize = 16
                    size = ByteBuffer.wrap(bytes, offset + 8, 8).order(ByteOrder.BIG_ENDIAN).long
                    require(size >= 0L) { "MP4 atom превышает поддерживаемый размер." }
                }
                else -> { headerSize = 8; size = size32 }
            }
            require(size >= headerSize && size <= (end - offset).toLong()) { "Некорректный размер atom " + type + "." }
            val payloadStart = offset + headerSize
            val atomEnd = offset + size.toInt()
            val rawPayload = bytes.copyOfRange(payloadStart, atomEnd)
            val isContainer = forceContainer || type in CONTAINER_TYPES
            val box = if (isContainer) {
                val prefixSize = if (type == "meta") 4 else 0
                require(rawPayload.size >= prefixSize) { "Повреждён контейнер " + type + "." }
                Box(
                    type = type,
                    prefix = rawPayload.copyOfRange(0, prefixSize),
                    children = parseBoxes(rawPayload, prefixSize, rawPayload.size, type == "ilst")
                )
            } else Box(type = type, payload = rawPayload)
            result += box
            offset = atomEnd
            require(result.size <= 100_000) { "Слишком много вложенных MP4 atoms." }
        }
        require(offset == end) { "Неполная структура MP4 atom." }
        return result
    }

    private fun serializeBox(box: Box): ByteArray {
        val body = if (box.children != null) {
            val output = java.io.ByteArrayOutputStream()
            output.write(box.prefix)
            box.children!!.forEach { output.write(serializeBox(it)) }
            output.toByteArray()
        } else box.payload
        val size = body.size.toLong() + 8L
        require(size <= 0xffffffffL) { "Atom " + box.type + " слишком велик для 32-битного размера." }
        val header = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
            .putInt(size.toInt()).put(box.type.toByteArray(latin1)).array()
        return header + body
    }

    private fun readUInt32(bytes: ByteArray, offset: Int): Long =
        ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xffffffffL

    private fun copyRange(input: RandomAccessFile, output: RandomAccessFile, offset: Long, length: Long, buffer: ByteArray) {
        input.seek(offset)
        var remaining = length
        while (remaining > 0L) {
            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            require(count > 0) { "Неожиданный конец MP4-файла при копировании." }
            output.write(buffer, 0, count)
            remaining -= count
        }
    }

    private val CONTAINER_TYPES = setOf(
        "moov", "trak", "mdia", "minf", "stbl", "edts", "dinf", "udta", "meta",
        "ilst", "----", "mvex", "moof", "traf", "mfra", "tref", "ipro", "sinf", "schi", "wave"
    )
}
