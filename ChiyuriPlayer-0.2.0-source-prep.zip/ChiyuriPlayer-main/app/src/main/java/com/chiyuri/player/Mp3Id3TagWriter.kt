package com.chiyuri.player

import java.io.File
import java.io.RandomAccessFile
import java.nio.charset.Charset

/**
 * Minimal, conservative ID3v2 writer for MP3 files.
 *
 * Audio frames are copied byte-for-byte. Existing ID3 frames not edited by this
 * application are retained. Files with unsupported tag-level flags or malformed
 * frame layouts are rejected rather than rewritten speculatively.
 */
internal object Mp3Id3TagWriter {
    private const val HEADER_SIZE = 10
    private const val MAX_TAG_SIZE = 64 * 1024 * 1024
    private val latin1: Charset = Charsets.ISO_8859_1

    fun rewrite(source: File, destination: File, metadata: TrackMetadata, artwork: ByteArray? = null) {
        require(source.isFile && source.canRead()) { "Исходный MP3-файл недоступен для чтения." }
        require(source.length() >= 4L) { "Файл слишком короткий и не похож на MP3." }
        require(source.canonicalFile != destination.canonicalFile) {
            "Для безопасной записи нужен отдельный временный файл."
        }

        RandomAccessFile(source, "r").use { input ->
            val prefix = ByteArray(3)
            input.readFully(prefix)
            var audioOffset = 0L
            val preserved = mutableListOf<Pair<String, ByteArray>>()

            if (prefix.contentEquals(byteArrayOf('I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte()))) {
                require(input.length() >= HEADER_SIZE.toLong()) { "Заголовок ID3 повреждён." }
                val header = ByteArray(HEADER_SIZE)
                input.seek(0)
                input.readFully(header)
                val major = header[3].toInt() and 0xff
                val flags = header[5].toInt() and 0xff
                require(major == 3 || major == 4) { "Поддерживаются ID3v2.3 и ID3v2.4." }
                require(flags == 0) { "ID3 содержит расширенные флаги; безопасная перезапись невозможна." }
                val tagSize = synchsafe(header, 6)
                require(tagSize in 0..MAX_TAG_SIZE && HEADER_SIZE.toLong() + tagSize <= input.length()) {
                    "Размер ID3-тега повреждён или превышает допустимый."
                }
                val tag = ByteArray(tagSize)
                input.seek(HEADER_SIZE.toLong())
                input.readFully(tag)
                preserved += parseFrames(tag, major)
                audioOffset = HEADER_SIZE.toLong() + tagSize
            }

            // Confirm that the first bytes after the optional ID3 tag look like an MPEG frame.
            input.seek(audioOffset)
            val b1 = input.read()
            val b2 = input.read()
            require(b1 == 0xff && b2 >= 0 && (b2 and 0xe0) == 0xe0) {
                "После ID3-тега не обнаружен MPEG-аудиопоток. Файл не изменён."
            }

            val frames = preserved.filterNot { (id, payload) ->
                (id in REPLACED_FRAMES && (id != "APIC" || artwork != null)) ||
                    (id == "TXXX" && isSyncedLyricsFrame(payload))
            }.toMutableList()
            addTextFrame(frames, "TIT2", metadata.title)
            addTextFrame(frames, "TPE1", metadata.artist)
            addTextFrame(frames, "TALB", metadata.album)
            addTextFrame(frames, "TDRC", metadata.year)
            if (metadata.plainLyrics.isNotBlank()) {
                frames += "USLT" to (byteArrayOf(3, 'e'.code.toByte(), 'n'.code.toByte(), 'g'.code.toByte(), 0) +
                    metadata.plainLyrics.toByteArray(Charsets.UTF_8))
            }
            if (metadata.syncedLyrics.isNotBlank()) {
                // Keep synchronized LRC in a named user text frame until full SYLT timestamp
                // conversion is implemented; this avoids writing a malformed SYLT structure.
                frames += "TXXX" to (byteArrayOf(3) +
                    "LYRICS_SYNCED".toByteArray(Charsets.UTF_8) + byteArrayOf(0) +
                    metadata.syncedLyrics.toByteArray(Charsets.UTF_8))
            }
            if (artwork != null && artwork.isNotEmpty()) {
                val mime = when {
                    artwork.size >= 8 && artwork[0] == 0x89.toByte() &&
                        artwork[1] == 0x50.toByte() && artwork[2] == 0x4e.toByte() && artwork[3] == 0x47.toByte() -> "image/png"
                    artwork.size >= 3 && artwork[0] == 0xff.toByte() && artwork[1] == 0xd8.toByte() -> "image/jpeg"
                    else -> throw IllegalArgumentException("Обложка должна быть в формате JPEG или PNG.")
                }
                frames += "APIC" to (byteArrayOf(3) + mime.toByteArray(latin1) + byteArrayOf(0, 3, 0) + artwork)
            }

            destination.parentFile?.mkdirs()
            RandomAccessFile(destination, "rw").use { output ->
                output.setLength(0)
                val tagBody = frames.fold(0L) { sum, frame -> sum + 10L + frame.second.size }
                require(tagBody <= MAX_TAG_SIZE) { "Новый ID3-тег слишком большой." }
                val header = byteArrayOf(
                    'I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte(),
                    4, 0, 0
                ) + encodeSynchsafe(tagBody.toInt())
                output.write(header)
                for ((id, payload) in frames) {
                    require(id.length == 4 && id.all { it in 'A'..'Z' || it in '0'..'9' }) {
                        "Некорректный идентификатор ID3-кадра."
                    }
                    output.write(id.toByteArray(latin1))
                    output.write(encodeSynchsafe(payload.size))
                    output.write(byteArrayOf(0, 0))
                    output.write(payload)
                }

                input.seek(audioOffset)
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }
        require(destination.length() > HEADER_SIZE) { "Не удалось сформировать MP3-файл." }
    }

    private fun isSyncedLyricsFrame(payload: ByteArray): Boolean {
        if (payload.size < 2) return false
        val encoding = payload[0].toInt() and 0xff
        val charset = when (encoding) {
            0 -> Charsets.ISO_8859_1
            1 -> Charsets.UTF_16
            2 -> Charsets.UTF_16BE
            3 -> Charsets.UTF_8
            else -> return false
        }
        val terminator = if (encoding == 1 || encoding == 2) 2 else 1
        var end = 1
        while (end + terminator <= payload.size) {
            val ended = if (terminator == 2) {
                payload[end] == 0.toByte() && payload[end + 1] == 0.toByte()
            } else payload[end] == 0.toByte()
            if (ended) break
            end += terminator
        }
        if (end + terminator > payload.size) return false
        return String(payload, 1, end - 1, charset).equals("LYRICS_SYNCED", ignoreCase = true)
    }

    private fun addTextFrame(frames: MutableList<Pair<String, ByteArray>>, id: String, value: String) {
        if (value.isNotBlank()) frames += id to (byteArrayOf(3) + value.toByteArray(Charsets.UTF_8))
    }

    private fun parseFrames(tag: ByteArray, major: Int): List<Pair<String, ByteArray>> {
        val result = mutableListOf<Pair<String, ByteArray>>()
        var offset = 0
        while (offset + 10 <= tag.size) {
            if (tag.sliceArray(offset until minOf(offset + 4, tag.size)).all { it == 0.toByte() }) break
            val id = String(tag, offset, 4, latin1)
            require(id.all { it in 'A'..'Z' || it in '0'..'9' }) { "Обнаружен повреждённый ID3-кадр." }
            val size = if (major == 4) synchsafe(tag, offset + 4) else {
                ((tag[offset + 4].toInt() and 0xff) shl 24) or
                    ((tag[offset + 5].toInt() and 0xff) shl 16) or
                    ((tag[offset + 6].toInt() and 0xff) shl 8) or
                    (tag[offset + 7].toInt() and 0xff)
            }
            require(size >= 0 && offset + 10L + size <= tag.size.toLong()) { "Размер ID3-кадра повреждён." }
            val frameFlags = ((tag[offset + 8].toInt() and 0xff) shl 8) or (tag[offset + 9].toInt() and 0xff)
            require(frameFlags == 0) { "ID3-кадр содержит специальные флаги; безопасная перезапись невозможна." }
            result += id to tag.copyOfRange(offset + 10, offset + 10 + size)
            offset += 10 + size
        }
        return result
    }

    private fun synchsafe(bytes: ByteArray, offset: Int): Int {
        require(offset >= 0 && offset + 4 <= bytes.size) { "Повреждённый synchsafe-размер ID3." }
        for (i in 0..3) require((bytes[offset + i].toInt() and 0x80) == 0) {
            "Недопустимый synchsafe-размер ID3."
        }
        return ((bytes[offset].toInt() and 0x7f) shl 21) or
            ((bytes[offset + 1].toInt() and 0x7f) shl 14) or
            ((bytes[offset + 2].toInt() and 0x7f) shl 7) or
            (bytes[offset + 3].toInt() and 0x7f)
    }

    private fun encodeSynchsafe(value: Int): ByteArray {
        require(value in 0..0x0fffffff)
        return byteArrayOf(
            ((value shr 21) and 0x7f).toByte(),
            ((value shr 14) and 0x7f).toByte(),
            ((value shr 7) and 0x7f).toByte(),
            (value and 0x7f).toByte()
        )
    }

    private val REPLACED_FRAMES = setOf("TIT2", "TPE1", "TALB", "TDRC", "TYER", "USLT", "APIC")
}
