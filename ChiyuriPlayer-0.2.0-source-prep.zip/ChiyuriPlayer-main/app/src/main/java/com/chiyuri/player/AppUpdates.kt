package com.chiyuri.player

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import kotlinx.coroutines.launch
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

internal data class UpdateInfo(
    val version: String,
    val versionCode: Int,
    val notes: String,
    val apkUrl: String,
    val checksumUrl: String,
    val sizeBytes: Long
)

internal object AppUpdates {
    private const val RELEASE_API = "https://api.github.com/repos/jugg037/ChiyuriPlayer-Releases/releases/latest"
    private const val PREFS = "app_updates"
    private const val KEY_ENABLED = "auto_enabled"
    private const val KEY_WIFI_ONLY = "wifi_only"
    private const val KEY_INTERVAL = "interval_hours"
    const val CURRENT_VERSION = "0.2.1"
    const val CURRENT_VERSION_CODE = 201

    fun autoEnabled(context: Context) = context.getSharedPreferences(PREFS, 0).getBoolean(KEY_ENABLED, false)
    fun wifiOnly(context: Context) = context.getSharedPreferences(PREFS, 0).getBoolean(KEY_WIFI_ONLY, true)
    fun intervalHours(context: Context) = context.getSharedPreferences(PREFS, 0).getInt(KEY_INTERVAL, 24)

    fun saveAutoSettings(context: Context, enabled: Boolean, wifiOnly: Boolean, intervalHours: Int) {
        context.getSharedPreferences(PREFS, 0).edit()
            .putBoolean(KEY_ENABLED, enabled).putBoolean(KEY_WIFI_ONLY, wifiOnly)
            .putInt(KEY_INTERVAL, intervalHours).apply()
        schedule(context)
    }

    fun schedule(context: Context) {
        val wm = WorkManager.getInstance(context)
        if (!autoEnabled(context)) {
            wm.cancelUniqueWork("chiyuri_auto_update")
            return
        }
        val network = if (wifiOnly(context)) NetworkType.UNMETERED else NetworkType.CONNECTED
        val request = PeriodicWorkRequestBuilder<UpdateCheckWorker>(intervalHours(context).toLong(), TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(network).build())
            .build()
        wm.enqueueUniquePeriodicWork("chiyuri_auto_update", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    suspend fun checkLatest(): UpdateInfo? = withContext(Dispatchers.IO) {
        val connection = URL(RELEASE_API).openConnection() as HttpURLConnection
        connection.connectTimeout = 10000
        connection.readTimeout = 15000
        connection.setRequestProperty("Accept", "application/vnd.github+json")
        connection.setRequestProperty("User-Agent", "ChiyuriPlayer-Android")
        try {
            if (connection.responseCode !in 200..299) error("GitHub вернул HTTP ${connection.responseCode}")
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val tag = json.optString("tag_name").removePrefix("v")
            val versionCode = tag.split('.').mapNotNull { it.toIntOrNull() }.let { parts ->
                if (parts.size >= 3) parts[0] * 10000 + parts[1] * 100 + parts[2] else 0
            }
            val assets = json.getJSONArray("assets")
            var apk: JSONObject? = null
            var checksum: JSONObject? = null
            for (i in 0 until assets.length()) {
                val asset = assets.getJSONObject(i)
                when (asset.optString("name")) {
                    "app-release.apk" -> apk = asset
                    else -> if (asset.optString("name").startsWith("ChiyuriPlayer-") && asset.optString("name").endsWith(".sha256")) checksum = asset
                }
            }
            val latestCode = if (tag == CURRENT_VERSION) CURRENT_VERSION_CODE else versionCode
            if (apk == null || checksum == null || latestCode <= CURRENT_VERSION_CODE) return@withContext null
            UpdateInfo(tag, latestCode, json.optString("body"), apk!!.getString("browser_download_url"), checksum!!.getString("browser_download_url"), apk!!.optLong("size"))
        } finally { connection.disconnect() }
    }

    suspend fun downloadAndVerify(context: Context, info: UpdateInfo, onProgress: (Long, Long) -> Unit): File = withContext(Dispatchers.IO) {
        val apk = File(context.cacheDir, "chiyuriplayer-update.apk")
        val connection = URL(info.apkUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.instanceFollowRedirects = true
        try {
            if (connection.responseCode !in 200..299) error("Не удалось скачать APK: HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong.takeIf { it > 0 } ?: info.sizeBytes
            connection.inputStream.use { input -> apk.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024); var count: Int; var done = 0L
                while (input.read(buffer).also { count = it } >= 0) {
                    if (count == 0) continue
                    output.write(buffer, 0, count); done += count; onProgress(done, total)
                }
            } }
        } finally { connection.disconnect() }
        val checksumConnection = URL(info.checksumUrl).openConnection() as HttpURLConnection
        val expected = try { checksumConnection.getInputStream().bufferedReader().use { it.readText().trim().substringBefore(' ').lowercase() } }
            finally { checksumConnection.disconnect() }
        val actual = MessageDigest.getInstance("SHA-256").digest(apk.readBytes()).joinToString("") { "%02x".format(it) }
        check(expected.length == 64 && actual.equals(expected, true)) { "Контрольная сумма SHA-256 не совпадает" }
        verifySigner(context, apk)
        apk
    }

    @Suppress("DEPRECATION")
    private fun verifySigner(context: Context, apk: File) {
        val flags = if (Build.VERSION.SDK_INT >= P) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val installed = context.packageManager.getPackageInfo(context.packageName, flags)
        val archive = context.packageManager.getPackageArchiveInfo(apk.absolutePath, flags) ?: error("Android не распознал APK")
        val installedSignatures = if (Build.VERSION.SDK_INT >= P) installed.signingInfo.apkContentsSigners else installed.signatures
        val archiveSignatures = if (Build.VERSION.SDK_INT >= P) archive.signingInfo?.apkContentsSigners else archive.signatures
        val installedHashes = installedSignatures.orEmpty().map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).contentToString() }.toSet()
        val archiveHashes = archiveSignatures.orEmpty().map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).contentToString() }.toSet()
        check(installedHashes.isNotEmpty() && installedHashes.intersect(archiveHashes).isNotEmpty()) { "Подпись APK не совпадает с установленной версией" }
    }

    fun install(context: Context, apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            val settings = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settings)
            error("Разрешите установку неизвестных приложений для ChiyuriPlayer и повторите установку")
        }
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.updates", apk)
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private const val P = Build.VERSION_CODES.P
}

class UpdateCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val update = AppUpdates.checkLatest()
        if (update != null) UpdateNotifications.show(applicationContext, update)
        Result.success()
    } catch (_: Exception) { Result.retry() }
}

internal object UpdateNotifications {
    private const val CHANNEL = "app_updates"
    fun show(context: Context, update: UpdateInfo) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            android.app.NotificationChannel(CHANNEL, "Обновления приложения", android.app.NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("open_updates", true)
        val pending = android.app.PendingIntent.getActivity(context, 200, open,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, CHANNEL) else android.app.Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Доступно обновление ChiyuriPlayer")
            .setContentText("Версия ${update.version} — нажмите, чтобы открыть обновления")
            .setContentIntent(pending).setAutoCancel(true)
        manager.notify(200, notification.build())
    }
}

@Composable
internal fun UpdateCenterScreen(modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var update by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<UpdateInfo?>(null) }
    var checking by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var downloading by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var progress by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    var status by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("Проверьте наличие новой версии") }
    var error by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var downloadJob by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<kotlinx.coroutines.Job?>(null) }
    androidx.compose.foundation.layout.Column(modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        androidx.compose.material3.Card(colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            androidx.compose.foundation.layout.Column(Modifier.padding(18.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
                androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Default.SystemUpdate, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
                androidx.compose.material3.Text("Центр обновлений", style = MaterialTheme.typography.titleLarge)
                androidx.compose.material3.Text("Установлена версия ${AppUpdates.CURRENT_VERSION}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.material3.Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (checking) androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth())
                if (downloading) {
                    androidx.compose.material3.LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    androidx.compose.material3.Text("Загрузка ${(progress * 100).toInt()}%")
                }
                error?.let { androidx.compose.material3.Text(it, color = MaterialTheme.colorScheme.error) }
                update?.let { info ->
                    androidx.compose.material3.HorizontalDivider()
                    androidx.compose.material3.Text("Доступна версия ${info.version}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    androidx.compose.material3.Text(info.notes.ifBlank { "Исправления ошибок и улучшения стабильности." }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    androidx.compose.material3.Text("Размер: ${if (info.sizeBytes > 0) "%.1f МБ".format(info.sizeBytes / 1048576f) else "неизвестен"}", style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.Button(enabled = !downloading, onClick = {
                        downloadJob = scope.launch {
                            downloading = true; error = null; progress = 0f
                            try {
                                val file = AppUpdates.downloadAndVerify(context, info) { done, total ->
                                    progress = if (total > 0) done.toFloat() / total else 0f
                                }
                                status = "Проверка SHA-256 и подписи пройдена. Открываем установщик Android…"
                                AppUpdates.install(context, file)
                            } catch (e: kotlinx.coroutines.CancellationException) { status = "Загрузка отменена"; throw e }
                            catch (e: Exception) { error = e.message ?: "Не удалось установить обновление" }
                            finally { downloading = false }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Default.Download, null); androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp)); androidx.compose.material3.Text("Скачать и установить") }
                }
                if (downloading) androidx.compose.material3.OutlinedButton(onClick = { downloadJob?.cancel() }, modifier = Modifier.fillMaxWidth()) { androidx.compose.material3.Text("Отменить загрузку") }
                androidx.compose.material3.OutlinedButton(enabled = !checking && !downloading, onClick = {
                    scope.launch {
                        checking = true; error = null; status = "Проверяем GitHub…"
                        try {
                            update = AppUpdates.checkLatest()
                            status = if (update == null) "У вас установлена последняя версия." else "Найдено обновление."
                        } catch (e: Exception) { error = e.message ?: "Ошибка проверки обновлений"; status = "Проверка не завершена" }
                        finally { checking = false }
                    }
                }, modifier = Modifier.fillMaxWidth()) { androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Default.Refresh, null); androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp)); androidx.compose.material3.Text("Проверить обновления") }
            }
        }
        androidx.compose.material3.Text("Перед запуском установщика приложение проверяет контрольную сумму и сертификат подписи. Последнее подтверждение установки выполняется Android.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun AutoUpdateSettingsScreen(modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var enabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(AppUpdates.autoEnabled(context)) }
    var wifiOnly by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(AppUpdates.wifiOnly(context)) }
    var interval by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(AppUpdates.intervalHours(context)) }
    androidx.compose.runtime.LaunchedEffect(Unit) { AppUpdates.schedule(context) }
    androidx.compose.foundation.layout.Column(modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        androidx.compose.material3.Card(colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            androidx.compose.foundation.layout.Column(Modifier.padding(18.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                        androidx.compose.material3.Text("Автоматическая проверка", style = MaterialTheme.typography.titleMedium)
                        androidx.compose.material3.Text("Проверять новые версии в фоне", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    androidx.compose.material3.Switch(checked = enabled, onCheckedChange = { enabled = it; AppUpdates.saveAutoSettings(context, enabled, wifiOnly, interval) })
                }
                androidx.compose.material3.HorizontalDivider()
                androidx.compose.material3.Text("Периодичность", style = MaterialTheme.typography.titleSmall)
                listOf(12, 24, 48, 168).forEach { hours ->
                    androidx.compose.material3.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { interval = hours; AppUpdates.saveAutoSettings(context, enabled, wifiOnly, interval) }) {
                        androidx.compose.material3.RadioButton(selected = interval == hours, onClick = { interval = hours; AppUpdates.saveAutoSettings(context, enabled, wifiOnly, interval) })
                        androidx.compose.material3.Text(when (hours) { 12 -> "Каждые 12 часов"; 24 -> "Каждый день"; 48 -> "Каждые 2 дня"; else -> "Раз в неделю" })
                    }
                }
                androidx.compose.material3.HorizontalDivider()
                androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                        androidx.compose.material3.Text("Только Wi‑Fi", style = MaterialTheme.typography.titleSmall)
                        androidx.compose.material3.Text("Не использовать мобильный интернет", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    androidx.compose.material3.Switch(checked = wifiOnly, onCheckedChange = { wifiOnly = it; AppUpdates.saveAutoSettings(context, enabled, wifiOnly, interval) })
                }
            }
        }
        androidx.compose.material3.Text("При обнаружении новой версии появится уведомление. Android не разрешает приложению устанавливать APK полностью без участия пользователя: подтверждение установки будет показано системой.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}
