package com.chiyuri.player

import android.os.Handler
import android.os.Looper
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the player independently from the Activity so audio can continue
 * while the UI is backgrounded or the screen is turned off.
 */
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var audioEffectsController: AudioEffectsController? = null
    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressSaver = object : Runnable {
        override fun run() {
            mediaSession?.player?.let { player ->
                if (player.isPlaying) PlaybackQueueStore.save(this@PlaybackService, player)
            }
            progressHandler.postDelayed(this, SAVE_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this).build()
        audioEffectsController = AudioEffectsController(this, player)
        AudioVisualizerBridge.bind(this, player)
        PlaybackQueueStore.restore(this, player)
        player.addListener(object : Player.Listener {
            override fun onTimelineChanged(
                timeline: androidx.media3.common.Timeline,
                reason: Int
            ) {
                PlaybackQueueStore.save(this@PlaybackService, player)
            }

            override fun onMediaItemTransition(
                mediaItem: androidx.media3.common.MediaItem?,
                reason: Int
            ) {
                PlaybackQueueStore.save(this@PlaybackService, player)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                PlaybackQueueStore.save(this@PlaybackService, player)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) {
                    PlaybackQueueStore.save(this@PlaybackService, player)
                }
            }
        })
        mediaSession = MediaSession.Builder(this, player).build()
        progressHandler.postDelayed(progressSaver, SAVE_INTERVAL_MS)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        progressHandler.removeCallbacks(progressSaver)
        AudioVisualizerBridge.unbind()
        audioEffectsController?.release()
        audioEffectsController = null
        mediaSession?.run {
            PlaybackQueueStore.save(this@PlaybackService, player)
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    private companion object {
        const val SAVE_INTERVAL_MS = 5_000L
    }
}