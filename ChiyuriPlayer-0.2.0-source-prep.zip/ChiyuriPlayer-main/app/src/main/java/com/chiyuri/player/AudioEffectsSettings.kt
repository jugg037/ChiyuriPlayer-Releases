package com.chiyuri.player

import android.content.Context
import android.content.SharedPreferences

data class AudioEffectsConfig(
    val equalizerEnabled: Boolean = false,
    val bandsDb: List<Float> = List(5) { 0f },
    val bassBoostStrength: Float = 0f,
    val playerVolume: Float = 1f
)

fun normalizeAudioEffectsConfig(config: AudioEffectsConfig): AudioEffectsConfig {
    fun bounded(value: Float, min: Float, max: Float, fallback: Float): Float =
        if (value.isFinite()) value.coerceIn(min, max) else fallback

    return config.copy(
        bandsDb = List(5) { index ->
            bounded(config.bandsDb.getOrElse(index) { 0f }, -12f, 12f, 0f)
        },
        bassBoostStrength = bounded(config.bassBoostStrength, 0f, 1000f, 0f),
        // Values below 100% belonged to the old app-only volume control.
        // Base volume is now Android's media stream; this value stores boost only.
        playerVolume = bounded(config.playerVolume, 1f, 2f, 1f)
    )
}

object AudioEffectsSettings {
    internal const val PREFERENCES_NAME = "audio_effects"
    private const val KEY_EQUALIZER_ENABLED = "equalizer_enabled"
    private const val KEY_BASS_STRENGTH = "bass_strength"
    private const val KEY_PLAYER_VOLUME = "player_volume"
    private const val KEY_BAND_PREFIX = "equalizer_band_"

    fun load(context: Context): AudioEffectsConfig {
        val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
        return load(preferences)
    }

    internal fun load(preferences: SharedPreferences): AudioEffectsConfig {
        val bands = (0 until 5).map { index ->
            preferences.getFloat(KEY_BAND_PREFIX + index, 0f)
        }
        return normalizeAudioEffectsConfig(
            AudioEffectsConfig(
                equalizerEnabled = preferences.getBoolean(KEY_EQUALIZER_ENABLED, false),
                bandsDb = bands,
                bassBoostStrength = preferences.getFloat(KEY_BASS_STRENGTH, 0f),
                playerVolume = preferences.getFloat(KEY_PLAYER_VOLUME, 1f)
            )
        )
    }

    fun save(context: Context, config: AudioEffectsConfig) {
        val normalized = normalizeAudioEffectsConfig(config)
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EQUALIZER_ENABLED, normalized.equalizerEnabled)
            .putFloat(KEY_BASS_STRENGTH, normalized.bassBoostStrength)
            .putFloat(KEY_PLAYER_VOLUME, normalized.playerVolume)
            .apply {
                normalized.bandsDb.forEachIndexed { index, value ->
                    putFloat(KEY_BAND_PREFIX + index, value)
                }
            }
            .apply()
    }
}
