package com.chiyuri.player

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder
import androidx.lifecycle.lifecycleScope
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

private val Night = Color(0xFF101116)
private val Panel = Color(0xFF1C1E27)
private val Accent = Color(0xFFB7A0FF)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch(Dispatchers.IO) {
            filesDir.resolve("whisper-tiny-multilingual").deleteRecursively()
        }
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                controller = future.get()
                setContent {
                    ChiyuriTheme {
                        PlayerHome(
                            player = controller!!,
                            onPickAudio = { uri -> play(uri) },
                            onPickVideo = { uri -> play(uri) }
                        )
                    }
                }
            } catch (error: Exception) {
                setContent {
                    ChiyuriTheme {
                        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                            Text(
                                "Не удалось подключиться к аудиодвижку. Перезапустите приложение.",
                                color = Color.White,
                                modifier = Modifier.padding(24.dp)
                            )
                        }
                    }
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val maximum = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val config = AudioEffectsSettings.load(this)
                if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                    if (current < maximum) {
                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    } else {
                        val boost = (config.playerVolume + 0.1f).coerceAtMost(2f)
                        if (boost != config.playerVolume) AudioEffectsSettings.save(this, config.copy(playerVolume = boost))
                    }
                } else if (config.playerVolume > 1f) {
                    AudioEffectsSettings.save(this, config.copy(playerVolume = (config.playerVolume - 0.1f).coerceAtLeast(1f)))
                } else {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                }
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun play(uri: Uri) {
        lifecycleScope.launch {
            val metadata = withContext(Dispatchers.IO) {
                TrackMetadataRepository.readLocal(this@MainActivity, uri)
            }
            val artwork = withContext(Dispatchers.IO) {
                TrackMetadataRepository.loadEmbeddedArtwork(this@MainActivity, uri)
            }
            val metadataBuilder = MediaMetadata.Builder()
                .setTitle(metadata.title)
                .setArtist(metadata.artist.takeIf { it.isNotBlank() })
                .setAlbumTitle(metadata.album.takeIf { it.isNotBlank() })
                .setReleaseYear(metadata.year.toIntOrNull())
            if (artwork != null) {
                metadataBuilder.setArtworkData(artwork, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
            }
            controller?.setMediaItem(
                MediaItem.Builder().setUri(uri).setMediaMetadata(metadataBuilder.build()).build()
            )
            controller?.prepare()
            controller?.play()
        }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let(MediaController::releaseFuture)
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun ChiyuriTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    var appearance by remember(context) { mutableStateOf(AppearanceSettings.load(context)) }
    DisposableEffect(context) {
        val preferences = context.getSharedPreferences("appearance_settings", Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            appearance = AppearanceSettings.load(context)
        }
        preferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose { preferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    var trackPalette by remember(context) { mutableStateOf(TrackPaletteStore.load(context)) }
    DisposableEffect(context) {
        val prefs = context.getSharedPreferences("track_palette", Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            trackPalette = TrackPaletteStore.load(context)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val dark = when (appearance.themeMode) {
        AppThemeMode.SYSTEM -> systemDark
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
    }
    val baseColors = if (appearance.dynamicColors && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (dark) {
        darkColorScheme(
            primary = Accent,
            secondary = Color(0xFF82D8C8),
            background = Night,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF6650A4),
            secondary = Color(0xFF356B62),
            background = Color(0xFFF8F7FC),
            surface = Color.White,
            onBackground = Color(0xFF1B1B22),
            onSurface = Color(0xFF1B1B22)
        )
    }
    val useArtworkPalette = appearance.dynamicColors
    val adaptiveAccent = if (useArtworkPalette) {
        if (dark) trackPalette.primary else Color(trackPalette.primary.red * 0.62f, trackPalette.primary.green * 0.62f, trackPalette.primary.blue * 0.62f)
    } else baseColors.primary
    val adaptiveSecondary = if (useArtworkPalette) {
        if (dark) trackPalette.secondary else Color(trackPalette.secondary.red * 0.58f, trackPalette.secondary.green * 0.58f, trackPalette.secondary.blue * 0.58f)
    } else baseColors.secondary
    val adaptiveBackground = if (useArtworkPalette) {
        if (dark) trackPalette.background else androidx.compose.ui.graphics.lerp(trackPalette.background, Color.White, 0.94f)
    } else baseColors.background
    val adaptiveSurface = if (useArtworkPalette) {
        if (dark) trackPalette.surface else androidx.compose.ui.graphics.lerp(trackPalette.surface, Color.White, 0.97f)
    } else baseColors.surface
    val colors = baseColors.copy(
        primary = adaptiveAccent,
        secondary = adaptiveSecondary,
        background = adaptiveBackground,
        surface = adaptiveSurface,
        onPrimary = Color.White,
        onBackground = if (dark) Color.White else Color(0xFF1B1B22),
        onSurface = if (dark) Color.White else Color(0xFF1B1B22)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun PlayerHome(
    player: Player,
    onPickAudio: (Uri) -> Unit,
    onPickVideo: (Uri) -> Unit
) {
    val context = LocalContext.current
    var queueVersion by remember { mutableStateOf(0) }
    var tab by remember { mutableStateOf("Музыка") }
    var morePage by remember { mutableStateOf("Главное") }
    LaunchedEffect(context) {
        AppUpdates.schedule(context)
        val activity = context as? MainActivity
        if (activity?.intent?.getBooleanExtra("open_updates", false) == true) {
            tab = "Ещё"
            morePage = "Обновления"
            activity.intent.removeExtra("open_updates")
        }
    }
    var title by remember {
        mutableStateOf(player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Ничего не воспроизводится")
    }
    var artist by remember { mutableStateOf(player.currentMediaItem?.mediaMetadata?.artist?.toString().orEmpty()) }
    var expandedMiniPlayer by remember { mutableStateOf(false) }
    var isVideoFullscreen by remember { mutableStateOf(false) }
    val hostActivity = context as? ComponentActivity
    val videoPlayerView = remember(context, player) {
        PlayerView(context).apply {
            this.player = player
            useController = true
        }
    }
    var showMetadataEditor by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(player.isPlaying) }
    var playbackPosition by remember { mutableLongStateOf(0L) }
    var playbackDuration by remember { mutableLongStateOf(0L) }
    var seekPosition by remember { mutableFloatStateOf(0f) }
    var isSeeking by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showSleepTimer by remember { mutableStateOf(false) }
    var sleepRemainingSeconds by remember { mutableIntStateOf(0) }
    var sleepAfterCurrentTrack by remember { mutableStateOf(false) }
    var sleepTimerJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var shuffleEnabled by remember { mutableStateOf(player.shuffleModeEnabled) }
    var repeatMode by remember { mutableIntStateOf(player.repeatMode) }
    var playbackSpeed by remember { mutableFloatStateOf(player.playbackParameters.speed) }
    val coroutineScope = rememberCoroutineScope()
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // MediaStore and some providers do not support persistable grants.
            }
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Read-only providers remain playable; the editor will report that writes are unavailable.
            }
            title = uri.lastPathSegment?.substringAfterLast('/') ?: "Аудиофайл"
            onPickAudio(uri)
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // MediaStore and some providers do not support persistable grants.
            }
            title = uri.lastPathSegment?.substringAfterLast('/') ?: "Видеофайл"
            onPickVideo(uri)
        }
    }
    DisposableEffect(isVideoFullscreen, hostActivity) {
        val window = hostActivity?.window
        if (window != null) {
            WindowCompat.setDecorFitsSystemWindows(window, !isVideoFullscreen)
            val insetsController = WindowInsetsControllerCompat(window, window.decorView)
            if (isVideoFullscreen) {
                insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                insetsController.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                insetsController.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (window != null) {
                WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(window, true)
            }
        }
    }

    BackHandler(enabled = isVideoFullscreen) {
        isVideoFullscreen = false
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffleEnabled = shuffleModeEnabled
            }
            override fun onRepeatModeChanged(repeatModeValue: Int) {
                repeatMode = repeatModeValue
            }
            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                playbackSpeed = playbackParameters.speed
            }
            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                queueVersion++
                playbackDuration = player.duration.takeIf { it > 0L } ?: 0L
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (sleepAfterCurrentTrack) {
                    sleepAfterCurrentTrack = false
                    player.pause()
                }
                val uri = mediaItem?.localConfiguration?.uri
                title = mediaItem?.mediaMetadata?.title?.toString()
                    ?.takeIf { it.isNotBlank() }
                    ?: uri?.let { TrackMetadataRepository.displayName(context, it) }
                    ?: "Медиафайл"
                artist = mediaItem?.mediaMetadata?.artist?.toString().orEmpty()
                expandedMiniPlayer = false
                queueVersion++
                playbackPosition = 0L
                seekPosition = 0f
                playbackDuration = player.duration.takeIf { it > 0L } ?: 0L
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(player) {
        while (true) {
            if (!isSeeking) {
                playbackPosition = player.currentPosition.coerceAtLeast(0L)
                playbackDuration = player.duration.takeIf { it > 0L } ?: 0L
                seekPosition = playbackPosition.toFloat()
            }
            kotlinx.coroutines.delay(500L)
        }
    }

    Box(Modifier.fillMaxSize()) {
    if (isVideoFullscreen) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { videoPlayerView },
                update = { it.player = player },
                modifier = Modifier.fillMaxSize()
            )
            IconButton(
                onClick = { isVideoFullscreen = false },
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
            ) {
                Icon(Icons.Default.FullscreenExit, contentDescription = "Выйти из полноэкранного режима", tint = Color.White)
            }
        }
    } else {
    TrackArtworkBackdrop(player, Modifier.matchParentSize())
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            Column(Modifier.fillMaxWidth().background(Color.Transparent)) {
                if (tab != "Ещё") MiniPlayerBar(
                    player = player,
                    title = title,
                    artist = artist,
                    expanded = expandedMiniPlayer,
                    onExpand = { expandedMiniPlayer = !expandedMiniPlayer },
                    onEditMetadata = { showMetadataEditor = true },
                    playing = playing,
                    playbackPosition = playbackPosition,
                    playbackDuration = playbackDuration,
                    seekPosition = seekPosition,
                    isSeeking = isSeeking,
                    onSeekChange = {
                        isSeeking = true
                        seekPosition = it
                    },
                    onSeekFinished = {
                        if (playbackDuration > 0L) {
                            player.seekTo(seekPosition.toLong().coerceIn(0L, playbackDuration))
                        }
                        isSeeking = false
                    },
                    onQueueClick = { showQueue = true },
                    sleepRemainingSeconds = sleepRemainingSeconds,
                    sleepAfterCurrentTrack = sleepAfterCurrentTrack,
                    onSleepTimerClick = { showSleepTimer = true },
                    shuffleEnabled = shuffleEnabled,
                    onToggleShuffle = { player.shuffleModeEnabled = !player.shuffleModeEnabled },
                    repeatMode = repeatMode,
                    onCycleRepeat = {
                        player.repeatMode = when (player.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                    },
                    playbackSpeed = playbackSpeed,
                    onPlaybackSpeedChange = { player.setPlaybackParameters(PlaybackParameters(it)) }
                )
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    listOf("Музыка", "Видео", "Плейлисты", "Текст", "Ещё").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Музыка" -> Icons.Default.MusicNote
                                        "Видео" -> Icons.Default.Movie
                                        "Плейлисты" -> Icons.Default.QueueMusic
                                        "Текст" -> Icons.Default.MusicNote
                                        else -> Icons.Default.Tune
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().background(Color.Transparent).padding(padding).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(18.dp))
            Text("CHIYURI", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, letterSpacing = 4.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (tab == "Ещё" && morePage != "Главное") {
                        IconButton(onClick = { morePage = "Главное" }) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад") }
                    }
                    Text(if (tab == "Ещё" && morePage != "Главное") morePage else tab, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onSurface)
                }
                when (tab) {
                    "Музыка" -> OutlinedButton(
                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.LibraryMusic, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("Открыть аудио", fontSize = 12.sp)
                    }
                    "Видео" -> OutlinedButton(
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("Выбрать видео", fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            when (tab) {
                "Музыка" -> {
                    Column(Modifier.weight(1f).fillMaxWidth()) {
                        LocalMediaBrowser(
                            isVideo = false,
                            onPlay = onPickAudio,
                            onPlayQueue = { items, selectedIndex ->
                                val queued = items.drop(selectedIndex).map { item ->
                                    MediaItem.Builder()
                                        .setUri(item.uri)
                                        .setMediaMetadata(
                                            MediaMetadata.Builder()
                                                .setTitle(item.title)
                                                .setArtist(item.artist?.takeIf { it.isNotBlank() })
                                                .setAlbumTitle(item.album?.takeIf { it.isNotBlank() })
                                                .build()
                                        )
                                        .build()
                                }
                                if (queued.isNotEmpty()) {
                                    player.setMediaItems(queued, 0, 0L)
                                    player.prepare()
                                    player.play()
                                    expandedMiniPlayer = false
                                }
                            }
                        )
                    }
                }
                "Видео" -> {
                    Column(
                        Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        LocalMediaBrowser(isVideo = true, onPlay = onPickVideo)
                        Box(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                            AndroidView(
                                factory = { videoPlayerView },
                                update = { it.player = player },
                                modifier = Modifier.fillMaxWidth().height(230.dp)
                            )
                            IconButton(
                                onClick = { isVideoFullscreen = true },
                                modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
                            ) {
                                Icon(Icons.Default.Fullscreen, contentDescription = "Полноэкранный режим", tint = Color.White)
                            }
                        }
                        TextButton(
                            onClick = {
                                TrackSelectionDialogBuilder(context, "Выбор субтитров", player, C.TRACK_TYPE_TEXT)
                                    .setShowDisableOption(true)
                                    .build()
                                    .show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Subtitles, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Выбрать дорожку субтитров")
                        }
                    }
                }
                "Плейлисты" -> PlaylistScreen(player = player, modifier = Modifier.weight(1f))
                "Текст" -> LyricsScreen(player = player, modifier = Modifier.weight(1f))
                else -> {
                    when (morePage) {
                        "Обновления" -> UpdateCenterScreen(Modifier.weight(1f))
                        "Автообновление" -> AutoUpdateSettingsScreen(Modifier.weight(1f))
                        else -> {
                            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionCard("Обновления", "Проверка, загрузка и установка новой версии", Icons.Default.SystemUpdate) { morePage = "Обновления" }
                                ActionCard("Автообновление", "Фоновая проверка новых версий", Icons.Default.Update) { morePage = "Автообновление" }
                                ActionCard("Открыть аудиофайл", "Быстрый выбор файла", Icons.Default.FolderOpen) { audioPicker.launch(arrayOf("audio/*")) }
                                AudioEffectsScreen(player = player)
                            }
                        }
                    }
                }
            }

        }
    }
    }
    }

    if (showMetadataEditor) {
        TrackMetadataEditorDialog(
            player = player,
            onDismiss = { showMetadataEditor = false },
            onApply = { metadata ->
                val current = player.currentMediaItem
                val uri = current?.localConfiguration?.uri
                if (uri != null) {
                    TrackMetadataRepository.saveOverride(context, uri, metadata)
                    val index = player.currentMediaItemIndex
                    val position = player.currentPosition
                    val wasPlaying = player.isPlaying
                    player.replaceMediaItem(index, TrackMetadataRepository.toMediaItem(uri, metadata))
                    player.seekTo(index, position)
                    if (wasPlaying) player.play()
                    title = metadata.title
                    artist = metadata.artist
                }
                showMetadataEditor = false
            }
        )
    }

    if (showSleepTimer) {
        AlertDialog(
            onDismissRequest = { showSleepTimer = false },
            title = { Text("Таймер сна") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Остановить воспроизведение через:")
                    listOf(5, 10, 15, 30, 45, 60, 90).forEach { minutes ->
                        TextButton(
                            onClick = {
                                sleepTimerJob?.cancel()
                                sleepTimerJob = coroutineScope.launch {
                                    sleepAfterCurrentTrack = false
                                    sleepRemainingSeconds = minutes * 60
                                    while (sleepRemainingSeconds > 0) {
                                        kotlinx.coroutines.delay(1000L)
                                        sleepRemainingSeconds = (sleepRemainingSeconds - 1).coerceAtLeast(0)
                                    }
                                    player.pause()
                                    sleepTimerJob = null
                                }
                                showSleepTimer = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(minutes.toString() + " минут") }
                    }
                    TextButton(
                        onClick = {
                            sleepTimerJob?.cancel()
                            sleepTimerJob = null
                            sleepRemainingSeconds = 0
                            sleepAfterCurrentTrack = true
                            showSleepTimer = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("После текущего трека") }
                    TextButton(
                        onClick = {
                            sleepTimerJob?.cancel()
                            sleepTimerJob = null
                            sleepRemainingSeconds = 0
                            sleepAfterCurrentTrack = false
                            showSleepTimer = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Отключить таймер") }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSleepTimer = false }) { Text("Закрыть") }
            }
        )
    }

    if (showQueue) {
        val queuedItems = remember(showQueue, queueVersion) {
            (0 until player.mediaItemCount).map { index -> player.getMediaItemAt(index) }
        }
        AlertDialog(
            onDismissRequest = { showQueue = false },
            title = { Text("Очередь воспроизведения (${queuedItems.size})") },
            text = {
                if (queuedItems.isEmpty()) {
                    Text("Очередь пуста. Запусти плейлист, чтобы добавить несколько треков.")
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(queuedItems.size) { index ->
                            val queuedItem = queuedItems[index]
                            val itemTitle = queuedItem.mediaMetadata.title?.toString()
                                ?: queuedItem.localConfiguration?.uri?.lastPathSegment
                                ?: "Медиафайл ${index + 1}"
                            Surface(
                                color = if (index == player.currentMediaItemIndex) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(start = 10.dp, end = 2.dp, top = 4.dp, bottom = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f).clickable {
                                            player.seekToDefaultPosition(index)
                                            player.play()
                                            showQueue = false
                                        },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${index + 1}.", color = MaterialTheme.colorScheme.primary)
                                        Spacer(Modifier.width(8.dp))
                                        Text(itemTitle, color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
                                    }
                                    IconButton(
                                        onClick = {
                                            player.removeMediaItem(index)
                                            queueVersion++
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Удалить из очереди", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        enabled = index > 0,
                                        onClick = {
                                            player.moveMediaItem(index, index - 1)
                                            queueVersion++
                                        }
                                    ) {
                                        Icon(Icons.Default.ArrowUpward, contentDescription = "Переместить выше", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        enabled = index < queuedItems.lastIndex,
                                        onClick = {
                                            player.moveMediaItem(index, index + 1)
                                            queueVersion++
                                        }
                                    ) {
                                        Icon(Icons.Default.ArrowDownward, contentDescription = "Переместить ниже", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        player.clearMediaItems()
                        queueVersion++
                        showQueue = false
                    },
                    enabled = queuedItems.isNotEmpty()
                ) { Text("Очистить очередь") }
            },
            dismissButton = {
                TextButton(onClick = { showQueue = false }) { Text("Закрыть") }
            }
        )
    }
}

@Composable
private fun MiniPlayerBar(
    player: Player,
    title: String,
    artist: String,
    expanded: Boolean,
    onExpand: () -> Unit,
    onEditMetadata: () -> Unit,
    playing: Boolean,
    playbackPosition: Long,
    playbackDuration: Long,
    seekPosition: Float,
    isSeeking: Boolean,
    onSeekChange: (Float) -> Unit,
    onSeekFinished: () -> Unit,
    onQueueClick: () -> Unit,
    sleepRemainingSeconds: Int,
    sleepAfterCurrentTrack: Boolean,
    onSleepTimerClick: () -> Unit,
    shuffleEnabled: Boolean,
    onToggleShuffle: () -> Unit,
    repeatMode: Int,
    onCycleRepeat: () -> Unit,
    playbackSpeed: Float,
    onPlaybackSpeedChange: (Float) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onExpand),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TrackArtwork(
                    uri = player.currentMediaItem?.localConfiguration?.uri,
                    artworkUrl = player.currentMediaItem?.mediaMetadata?.artworkUri?.toString(),
                    modifier = Modifier.size(42.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, maxLines = 1, color = MaterialTheme.colorScheme.onSurface)
                    Text(artist.ifBlank { if (playing) "Воспроизводится" else "Пауза" }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1)
                }
                Icon(Icons.Default.ExpandLess.takeIf { expanded } ?: Icons.Default.ExpandMore, contentDescription = if (expanded) "Свернуть плеер" else "Развернуть плеер", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!expanded) {
                AudioVisualizerMiniDisplay(player, Modifier.fillMaxWidth().height(22.dp))
            }
            if (expanded) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TrackArtwork(
                            uri = player.currentMediaItem?.localConfiguration?.uri,
                            artworkUrl = player.currentMediaItem?.mediaMetadata?.artworkUri?.toString(),
                            modifier = Modifier.size(112.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                            Text(artist.ifBlank { "Исполнитель не указан" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(player.currentMediaItem?.mediaMetadata?.albumTitle?.toString().orEmpty().ifBlank { "Альбом не указан" }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                    }
                    AudioVisualizerMiniDisplay(player)
                    TrackLyricsPreview(player)
                    TextButton(onClick = onEditMetadata, modifier = Modifier.align(Alignment.End)) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Найти и изменить информацию")
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { player.seekToPreviousMediaItem() }, enabled = player.currentMediaItemIndex > 0) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Предыдущий трек", tint = MaterialTheme.colorScheme.onSurface)
                }
                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Воспроизвести или приостановить", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { player.seekToNextMediaItem() }, enabled = player.hasNextMediaItem()) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Следующий трек", tint = MaterialTheme.colorScheme.onSurface)
                }
                IconButton(onClick = onQueueClick) {
                    Icon(Icons.Default.QueueMusic, contentDescription = "Очередь воспроизведения", tint = MaterialTheme.colorScheme.onSurface)
                }
            }
            if (expanded) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onToggleShuffle) {
                    Icon(Icons.Default.Shuffle, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (shuffleEnabled) "Перемешивание: вкл." else "Перемешивание")
                }
                TextButton(onClick = onCycleRepeat) {
                    Icon(
                        if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        when (repeatMode) {
                            Player.REPEAT_MODE_ALL -> "Повтор: все"
                            Player.REPEAT_MODE_ONE -> "Повтор: 1"
                            else -> "Повтор: выкл."
                        }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                var speedMenuExpanded by remember { mutableStateOf(false) }
                Box {
                    TextButton(onClick = { speedMenuExpanded = true }) {
                        Icon(Icons.Default.Speed, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text(String.format(Locale.getDefault(), "%.2fx", playbackSpeed))
                    }
                    DropdownMenu(
                        expanded = speedMenuExpanded,
                        onDismissRequest = { speedMenuExpanded = false }
                    ) {
                        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f).forEach { speed ->
                            DropdownMenuItem(
                                text = { Text(String.format(Locale.getDefault(), "%.2fx", speed)) },
                                onClick = {
                                    onPlaybackSpeedChange(speed)
                                    speedMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                TextButton(onClick = onSleepTimerClick) {
                    Icon(Icons.Default.Bedtime, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        when {
                            sleepAfterCurrentTrack -> "После трека"
                            sleepRemainingSeconds > 0 -> "Сон " + (sleepRemainingSeconds / 60) + ":" + (sleepRemainingSeconds % 60).toString().padStart(2, '0')
                            else -> "Таймер сна"
                        }
                    )
                }
            }
            }
            if (expanded) VolumeIndicator()
            Slider(
                value = seekPosition.coerceIn(0f, playbackDuration.coerceAtLeast(1L).toFloat()),
                onValueChange = onSeekChange,
                onValueChangeFinished = onSeekFinished,
                valueRange = 0f..playbackDuration.coerceAtLeast(1L).toFloat(),
                enabled = playbackDuration > 0L && player.mediaItemCount > 0,
                modifier = Modifier.fillMaxWidth().height(28.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatPlaybackTime(if (isSeeking) seekPosition.toLong() else playbackPosition), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                Text(formatPlaybackTime(playbackDuration), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AudioEffectsScreen(player: Player, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    val maxSystemVolume = remember(audioManager) {
        audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    }
    var systemVolume by remember(audioManager) {
        mutableIntStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, maxSystemVolume))
    }
    var config by remember(context) { mutableStateOf(AudioEffectsSettings.load(context)) }
    val bandLabels = listOf("Низкие", "Ниже средних", "Средние", "Выше средних", "Высокие")

    DisposableEffect(context) {
        val preferences = context.getSharedPreferences(AudioEffectsSettings.PREFERENCES_NAME, Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            config = AudioEffectsSettings.load(context)
        }
        preferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose { preferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    LaunchedEffect(audioManager) {
        while (true) {
            val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                .coerceIn(0, maxSystemVolume)
            if (systemVolume != current) systemVolume = current
            kotlinx.coroutines.delay(250L)
        }
    }

    fun updateConfig(updated: AudioEffectsConfig) {
        val normalized = normalizeAudioEffectsConfig(updated)
        config = normalized
        AudioEffectsSettings.save(context, normalized)
    }

    Column(
        modifier = modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Эквалайзер", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                        Text("Пять полос настройки частот", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = config.equalizerEnabled,
                        onCheckedChange = { updateConfig(config.copy(equalizerEnabled = it)) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EqualizerPresets.all.forEach { preset ->
                        FilterChip(
                            selected = EqualizerPresets.selectedPreset(config) == preset.id,
                            onClick = { updateConfig(EqualizerPresets.apply(config, preset)) },
                            label = { Text(preset.title) }
                        )
                    }
                }
                if (config.equalizerEnabled) {
                    Spacer(Modifier.height(8.dp))
                    bandLabels.forEachIndexed { index, label ->
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(label, color = MaterialTheme.colorScheme.onSurface)
                                Text(
                                    String.format(Locale.getDefault(), "%.1f дБ", config.bandsDb[index]),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = config.bandsDb[index],
                                onValueChange = { value ->
                                    updateConfig(config.copy(bandsDb = config.bandsDb.toMutableList().also {
                                        it[index] = value
                                    }))
                                },
                                valueRange = -12f..12f,
                                steps = 47
                            )
                        }
                    }
                } else {
                    Text(
                        "Включи переключатель, чтобы настроить частоты.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Усиление басов", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                    Text("${(config.bassBoostStrength / 10f).toInt()}%", color = MaterialTheme.colorScheme.primary)
                }
                Text(
                    "Работает через аудиоэффект Android, если его поддерживает устройство.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = config.bassBoostStrength,
                    onValueChange = { updateConfig(config.copy(bassBoostStrength = it)) },
                    valueRange = 0f..1000f,
                    steps = 19
                )
            }
        }

        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Громкость Android", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                    Text("${(systemVolume * 100f / maxSystemVolume).roundToInt()}%", color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = systemVolume.toFloat(),
                    onValueChange = { value ->
                        val level = value.roundToInt().coerceIn(0, maxSystemVolume)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, level, 0)
                        systemVolume = level
                    },
                    valueRange = 0f..maxSystemVolume.toFloat(),
                    steps = (maxSystemVolume - 1).coerceAtLeast(0)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Доп. усиление", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleSmall)
                    Text("+${((config.playerVolume - 1f) * 100f).roundToInt()}%", color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = (config.playerVolume - 1f).coerceIn(0f, 1f),
                    onValueChange = { boost -> updateConfig(config.copy(playerVolume = 1f + boost)) },
                    valueRange = 0f..1f,
                    steps = 9
                )
                Text(
                    "Единая шкала: сначала системная громкость до 100%, затем усиление плеера от 0 до +100%. Кнопки громкости телефона управляют обоими уровнями.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        TextButton(
            onClick = { updateConfig(AudioEffectsConfig()) },
            modifier = Modifier.align(Alignment.End)
        ) {
            Icon(Icons.Default.RestartAlt, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Сбросить настройки звука")
        }
        Text(
            "Доступность эквалайзера и усиления басов зависит от аудиодрайвера телефона. Регулятор громкости плеера работает независимо от них.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
        AppearanceSettingsCard()
        AudioVisualizerScreen(player)
        NetworkStreamCard(player)
    }
}

@Composable
private fun AppearanceSettingsCard() {
    val context = LocalContext.current
    var config by remember(context) { mutableStateOf(AppearanceSettings.load(context)) }
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Оформление", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
            Text("Выбери режим интерфейса", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            AppThemeMode.entries.forEach { mode ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable {
                        config = config.copy(themeMode = mode)
                        AppearanceSettings.save(context, config)
                    },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = config.themeMode == mode,
                        onClick = {
                            config = config.copy(themeMode = mode)
                            AppearanceSettings.save(context, config)
                        }
                    )
                    Text(mode.label, color = MaterialTheme.colorScheme.onSurface)
                }
            }
            HorizontalDivider(color = Color(0xFF343641))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Цвета из обложки", color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        "Акцент, фон и карточки подстраиваются под обложку текущего трека",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(
                    checked = config.dynamicColors,
                    onCheckedChange = {
                        config = config.copy(dynamicColors = it)
                        AppearanceSettings.save(context, config)
                    }
                )
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun EmptyFeature(title: String, message: String) {
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


@Composable
private fun PlaylistScreen(
    player: Player,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember(context) { PlaylistRepository(context) }

    var playlists by remember { mutableStateOf<List<Playlist>>(emptyList()) }
    var selectedPlaylist by remember { mutableStateOf<Playlist?>(null) }
    var tracks by remember { mutableStateOf<List<PlaylistTrack>>(emptyList()) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<Playlist?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Playlist?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshPlaylists() {
        scope.launch {
            playlists = withContext(Dispatchers.IO) { repository.getPlaylists() }
            selectedPlaylist = selectedPlaylist?.let { selected ->
                playlists.firstOrNull { it.id == selected.id }
            }
        }
    }

    fun refreshTracks(playlistId: Long) {
        scope.launch {
            tracks = withContext(Dispatchers.IO) { repository.getTracks(playlistId) }
        }
    }

    LaunchedEffect(repository) {
        refreshPlaylists()
    }

    DisposableEffect(repository) {
        onDispose { repository.close() }
    }

    val addAudioLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val target = selectedPlaylist
        if (uri != null && target != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers do not grant persistable access.
            }

            var displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "Аудиофайл"
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) {
                        displayName = cursor.getString(nameIndex) ?: displayName
                    }
                }
            }

            val mimeType = context.contentResolver.getType(uri)
            scope.launch {
                val added = withContext(Dispatchers.IO) {
                    repository.addTrack(
                        playlistId = target.id,
                        uri = uri,
                        title = displayName,
                        artist = null,
                        durationMs = 0L,
                        mimeType = mimeType
                    )
                }
                message = if (added) "Файл добавлен в плейлист" else "Этот файл уже есть в плейлисте"
                refreshTracks(target.id)
                refreshPlaylists()
            }
        }
    }

    val exportM3uLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/x-mpegurl")
    ) { destination ->
        val target = selectedPlaylist
        if (destination != null && target != null) {
            scope.launch {
                try {
                    val content = withContext(Dispatchers.IO) {
                        val exportTracks = repository.getTracks(target.id)
                        M3uPlaylistCodec.format(
                            exportTracks.map { track ->
                                M3uEntry(
                                    location = track.uri,
                                    title = track.title,
                                    durationSeconds = track.durationMs.takeIf { it > 0L }?.div(1000L)
                                )
                            }
                        )
                    }
                    val written = withContext(Dispatchers.IO) {
                        val output = context.contentResolver.openOutputStream(destination, "wt")
                            ?: return@withContext false
                        output.bufferedWriter(Charsets.UTF_8).use { writer ->
                            writer.write(content)
                        }
                        true
                    }
                    message = if (written) "Плейлист экспортирован в M3U8" else "Не удалось записать файл"
                } catch (error: Exception) {
                    message = "Ошибка экспорта: ${error.localizedMessage ?: "неизвестная ошибка"}"
                }
            }
        }
    }

    val importM3uLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { source ->
        val target = selectedPlaylist
        if (source != null && target != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    source,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Import is still attempted while the temporary picker grant is active.
            }
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        val content = context.contentResolver.openInputStream(source)
                            ?.bufferedReader(Charsets.UTF_8)
                            ?.use { it.readText() }
                            ?: throw IllegalStateException("Не удалось прочитать выбранный файл")
                        val entries = M3uPlaylistCodec.parse(content)
                        var added = 0
                        var skipped = 0
                        entries.forEach { entry ->
                            val uri = Uri.parse(entry.location)
                            val scheme = uri.scheme?.lowercase()
                            val accessible = when (scheme) {
                                "http", "https" -> true
                                "content", "file" -> try {
                                    context.contentResolver.openInputStream(uri)?.use { true } == true
                                } catch (_: Exception) {
                                    false
                                }
                                else -> false
                            }
                            if (!accessible) {
                                skipped++
                                return@forEach
                            }
                            val durationMs = entry.durationSeconds
                                ?.takeIf { it in 1L..(Long.MAX_VALUE / 1000L) }
                                ?.times(1000L) ?: 0L
                            val mimeType = runCatching {
                                context.contentResolver.getType(uri)
                            }.getOrNull()
                            if (repository.addTrack(
                                    playlistId = target.id,
                                    uri = uri,
                                    title = entry.title,
                                    artist = null,
                                    durationMs = durationMs,
                                    mimeType = mimeType
                                )
                            ) {
                                added++
                            } else {
                                skipped++
                            }
                        }
                        added to skipped
                    }
                    message = "Импортировано: ${result.first}; пропущено или уже есть: ${result.second}. Относительные пути без доступа Android пропускаются."
                    refreshTracks(target.id)
                    refreshPlaylists()
                } catch (error: Exception) {
                    message = "Ошибка импорта: ${error.localizedMessage ?: "неизвестная ошибка"}"
                }
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        if (selectedPlaylist == null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Ваши плейлисты", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                Button(onClick = { newPlaylistName = ""; showCreateDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Создать")
                }
            }

            if (playlists.isEmpty()) {
                EmptyFeature("Пока нет плейлистов", "Создай плейлист и добавляй в него аудиофайлы с устройства.")
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(playlists, key = { it.id }) { playlist ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().clickable {
                                selectedPlaylist = playlist
                                refreshTracks(playlist.id)
                                message = null
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.QueueMusic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(playlist.name, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                    Text(
                                        "${playlist.trackCount} трек(ов)",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                IconButton(onClick = {
                                    renameTarget = playlist
                                    renameValue = playlist.name
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Переименовать", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { deleteTarget = playlist }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val activePlaylist = selectedPlaylist!!
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    selectedPlaylist = null
                    tracks = emptyList()
                    refreshPlaylists()
                }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = MaterialTheme.colorScheme.onSurface)
                }
                Column(Modifier.weight(1f)) {
                    Text(activePlaylist.name, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text("${tracks.size} трек(ов)", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(
                    onClick = {
                        if (tracks.isNotEmpty()) {
                            val items = tracks.map { track ->
                                MediaItem.Builder()
                                    .setUri(Uri.parse(track.uri))
                                    .setMediaMetadata(
                                        MediaMetadata.Builder()
                                            .setTitle(track.title)
                                            .setArtist(track.artist)
                                            .build()
                                    )
                                    .build()
                            }
                            player.setMediaItems(items, 0, 0L)
                            player.prepare()
                            player.play()
                        }
                    },
                    enabled = tracks.isNotEmpty()
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Играть всё", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { addAudioLauncher.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Default.Add, contentDescription = "Добавить аудио", tint = MaterialTheme.colorScheme.primary)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { importM3uLauncher.launch(arrayOf("*/*")) }) {
                    Text("Импорт M3U8")
                }
                OutlinedButton(
                    onClick = { exportM3uLauncher.launch("${activePlaylist.name}.m3u8") },
                    enabled = tracks.isNotEmpty()
                ) {
                    Text("Экспорт M3U8")
                }
            }

            if (tracks.isEmpty()) {
                EmptyFeature("Плейлист пуст", "Нажми «+», чтобы добавить аудиофайлы. Доступ к ним сохранится для следующих запусков, если его поддерживает поставщик документов.")
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(tracks, key = { it.id }) { track ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().clickable {
                                val items = tracks.map { entry ->
                                    MediaItem.Builder()
                                        .setUri(Uri.parse(entry.uri))
                                        .setMediaMetadata(
                                            MediaMetadata.Builder()
                                                .setTitle(entry.title)
                                                .setArtist(entry.artist)
                                                .build()
                                        )
                                        .build()
                                }
                                val index = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
                                player.setMediaItems(items, index, 0L)
                                player.prepare()
                                player.play()
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                    Text(
                                        track.artist ?: track.mimeType ?: "Аудиофайл",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1
                                    )
                                }
                                IconButton(onClick = {
                                    scope.launch {
                                        withContext(Dispatchers.IO) { repository.removeTrack(track.id) }
                                        refreshTracks(activePlaylist.id)
                                        refreshPlaylists()
                                    }
                                }) {
                                    Icon(Icons.Default.Close, contentDescription = "Убрать из плейлиста", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }

        message?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Новый плейлист") },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Название") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val requestedName = newPlaylistName
                    scope.launch {
                        val createdId = withContext(Dispatchers.IO) { repository.createPlaylist(requestedName) }
                        if (createdId != null) {
                            showCreateDialog = false
                            newPlaylistName = ""
                            message = "Плейлист создан"
                            refreshPlaylists()
                        } else {
                            message = "Проверь название: оно не должно быть пустым, длиннее 80 символов или повторять существующее"
                        }
                    }
                }) { Text("Создать") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Отмена") }
            }
        )
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Переименовать плейлист") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it },
                    label = { Text("Название") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val renamed = withContext(Dispatchers.IO) {
                            repository.renamePlaylist(target.id, renameValue)
                        }
                        message = if (renamed) "Название изменено" else "Не удалось изменить название: проверь его уникальность и длину"
                        renameTarget = null
                        refreshPlaylists()
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Отмена") }
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить плейлист?") },
            text = { Text("«${target.name}» и все записи внутри него будут удалены.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { repository.deletePlaylist(target.id) }
                        deleteTarget = null
                        message = "Плейлист удалён"
                        refreshPlaylists()
                    }
                }) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Отмена") }
            }
        )
    }
}


@Composable
private fun LocalMediaBrowser(
    isVideo: Boolean,
    onPlay: (Uri) -> Unit,
    onPlayQueue: ((List<LocalMedia>, Int) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var mediaItems by remember(isVideo, context) { mutableStateOf(LocalMediaRepository.loadCached(context, isVideo)) }
    var isLoading by remember { mutableStateOf(false) }
    var permissionDenied by remember { mutableStateOf(false) }
    var searchQuery by remember(isVideo) { mutableStateOf("") }
    var selectedFolder by remember(isVideo) { mutableStateOf<String?>(null) }
    var sortOrder by remember(isVideo) { mutableStateOf(MediaSortOrder.TITLE) }
    var sortDescending by remember(isVideo) { mutableStateOf(false) }
    var filtersMenuExpanded by remember(isVideo) { mutableStateOf(false) }
    var favorites by remember(isVideo, context) {
        mutableStateOf(if (isVideo) emptySet() else FavoriteTracksStore.load(context))
    }
    var favoritesOnly by remember(isVideo) { mutableStateOf(false) }

    val folders = remember(mediaItems) {
        mediaItems.mapNotNull { item ->
            item.relativePath?.trim('/')?.takeIf { it.isNotBlank() }
        }.distinct().sorted()
    }
    val visibleItems = remember(mediaItems, searchQuery, selectedFolder, favorites, favoritesOnly) {
        mediaItems.filter { item ->
            val matchesQuery = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.artist.orEmpty().contains(searchQuery, ignoreCase = true) ||
                item.album.orEmpty().contains(searchQuery, ignoreCase = true) ||
                item.relativePath.orEmpty().contains(searchQuery, ignoreCase = true)
            val itemFolder = item.relativePath?.trim('/')
            val matchesFavorite = isVideo || !favoritesOnly || item.uri.toString() in favorites
            matchesQuery && matchesFavorite && (selectedFolder == null || itemFolder == selectedFolder)
        }
    }

    val sortedItems = remember(visibleItems, sortOrder, sortDescending) {
        sortLocalMedia(visibleItems, sortOrder, sortDescending)
    }

    val permission = when {
        Build.VERSION.SDK_INT >= 33 && isVideo -> Manifest.permission.READ_MEDIA_VIDEO
        Build.VERSION.SDK_INT >= 33 -> Manifest.permission.READ_MEDIA_AUDIO
        else -> Manifest.permission.READ_EXTERNAL_STORAGE
    }

    fun scanMedia() {
        scope.launch {
            isLoading = true
            permissionDenied = false
            try {
                val scannedItems = withContext(Dispatchers.IO) {
                    if (isVideo) LocalMediaRepository.loadVideos(context)
                    else LocalMediaRepository.loadAudio(context)
                }
                mediaItems = scannedItems
                withContext(Dispatchers.IO) {
                    LocalMediaRepository.saveScan(context, isVideo, scannedItems)
                }
            } finally {
                isLoading = false
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted || ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            scanMedia()
        } else {
            permissionDenied = true
        }
    }

    LaunchedEffect(isVideo, permission) {
        if (LocalMediaRepository.shouldAutoScan(context, isVideo)) {
            if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                scanMedia()
            } else if (mediaItems.isEmpty()) {
                permissionLauncher.launch(permission)
            }
        }
    }

    Column(Modifier.fillMaxWidth().then(if (onPlayQueue != null) Modifier.fillMaxHeight() else Modifier)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                if (isVideo) "Видео на устройстве" else "Музыкальная библиотека",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!isVideo) {
                    IconButton(onClick = { favoritesOnly = !favoritesOnly }) {
                        Icon(
                            if (favoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = if (favoritesOnly) "Показать всю музыку" else "Показать избранное",
                            tint = if (favoritesOnly) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Box {
                    IconButton(onClick = { filtersMenuExpanded = true }) {
                        Icon(Icons.Default.Tune, contentDescription = "Сортировка и фильтры", tint = MaterialTheme.colorScheme.primary)
                    }
                    DropdownMenu(expanded = filtersMenuExpanded, onDismissRequest = { filtersMenuExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text("Название" + if (sortOrder == MediaSortOrder.TITLE) " ✓" else "") },
                            onClick = { sortOrder = MediaSortOrder.TITLE; filtersMenuExpanded = false }
                        )
                        if (!isVideo) {
                            DropdownMenuItem(
                                text = { Text("Исполнитель" + if (sortOrder == MediaSortOrder.ARTIST) " ✓" else "") },
                                onClick = { sortOrder = MediaSortOrder.ARTIST; filtersMenuExpanded = false }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Длительность" + if (sortOrder == MediaSortOrder.DURATION) " ✓" else "") },
                            onClick = { sortOrder = MediaSortOrder.DURATION; filtersMenuExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text(if (sortDescending) "По убыванию" else "По возрастанию") },
                            trailingIcon = { Icon(if (sortDescending) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, contentDescription = null) },
                            onClick = { sortDescending = !sortDescending }
                        )
                        if (folders.isNotEmpty()) {
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text(if (selectedFolder == null) "Все папки ✓" else "Все папки") },
                                onClick = { selectedFolder = null; filtersMenuExpanded = false }
                            )
                            folders.forEach { folder ->
                                DropdownMenuItem(
                                    text = { Text(folder.substringAfterLast('/') + if (selectedFolder == folder) " ✓" else "") },
                                    onClick = { selectedFolder = if (selectedFolder == folder) null else folder; filtersMenuExpanded = false }
                                )
                            }
                        }
                    }
                }
                IconButton(
                    enabled = !isLoading,
                    onClick = {
                        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) scanMedia()
                        else permissionLauncher.launch(permission)
                    }
                ) {
                    Icon(if (isLoading) Icons.Default.Sync else Icons.Default.Refresh,
                        contentDescription = if (isLoading) "Сканирование" else "Обновить библиотеку",
                        tint = if (isLoading) Color.Gray else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(42.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    decorationBox = { innerTextField ->
                        Box {
                            if (searchQuery.isEmpty()) {
                                Text(
                                    "Поиск по названию, исполнителю или папке",
                                    color = Color.Gray,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            }
                            innerTextField()
                        }
                    }
                )
            }
        }

        if (permissionDenied) {
            Text(
                "Нет доступа к этой категории файлов. Разреши доступ в системном окне Android.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        } else if (!isLoading && mediaItems.isEmpty()) {
            Text(
                "Локальные файлы пока не найдены. Нажми «Обновить», чтобы повторить поиск.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (visibleItems.isEmpty() && mediaItems.isNotEmpty()) {
            Text(
                if (favoritesOnly) "В избранном пока нет композиций." else "Ничего не найдено в выбранной папке или по этому запросу.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().then(if (onPlayQueue != null) Modifier.weight(1f) else Modifier.heightIn(max = 280.dp)),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(sortedItems, key = { "${if (isVideo) "video" else "audio"}-${it.id}" }) { item ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().clickable {
                        val selectedIndex = sortedItems.indexOfFirst { it.id == item.id }
                        if (!isVideo && onPlayQueue != null && selectedIndex >= 0) {
                            onPlayQueue(sortedItems, selectedIndex)
                        } else onPlay(item.uri)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (isVideo) Icons.Default.Movie else Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                            val details = listOfNotNull(
                                item.artist?.takeIf { it.isNotBlank() },
                                if (isVideo) formatMediaDuration(item.durationMs) else formatMediaDuration(item.durationMs),
                                item.relativePath?.trim('/')?.takeIf { it.isNotBlank() }
                            ).joinToString(" • ")
                            Text(
                                details,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1
                            )
                        }
                        if (!isVideo) {
                            IconButton(onClick = { favorites = FavoriteTracksStore.toggle(context, item.uri) }) {
                                Icon(
                                    if (item.uri.toString() in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = if (item.uri.toString() in favorites) "Убрать из избранного" else "Добавить в избранное",
                                    tint = if (item.uri.toString() in favorites) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(Icons.Default.PlayArrow, contentDescription = "Воспроизвести", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

private fun formatMediaDuration(durationMs: Long): String = formatPlaybackTime(durationMs)
