#!/usr/bin/env bash
set -euo pipefail

KEYSTORE_PATH="${1:-chiyuri-release.jks}"
ALIAS="${2:-chiyuri}"

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool not found. Install JDK 17 or newer." >&2
  exit 1
fi

umask 077
keytool -genkeypair -v \
  -keystore "$KEYSTORE_PATH" \
  -storetype JKS \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 3072 \
  -validity 10000 \
  -dname "CN=ChiyuriPlayer Release, OU=Android, O=ChiyuriPlayer, C=GB"

printf '\nBase64 value for GitHub secret ANDROID_SIGNING_KEY_BASE64:\n'
base64 < "$KEYSTORE_PATH" | tr -d '\n'
printf '\n\nSave the keystore securely. Never commit it or share it publicly.\n'
printf 'GitHub Actions secrets to configure:\n'
printf '  ANDROID_SIGNING_KEY_BASE64 = the Base64 value printed above\n'
printf '  ANDROID_KEYSTORE_PASSWORD  = the keystore password you entered\n'
printf '  ANDROID_KEY_ALIAS          = %s\n' "$ALIAS"
printf '  ANDROID_KEY_PASSWORD       = the key password you entered\n'
